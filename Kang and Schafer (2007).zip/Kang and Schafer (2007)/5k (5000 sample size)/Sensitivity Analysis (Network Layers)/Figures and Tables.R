library(ggplot2)
library(dplyr)
library(tidyr)

source('Methods.R')

## load ck_h
s <- 1005
file_ck <- paste0("ck_h_true", s, ".csv")
ck_values <- read.csv(file_ck, header = TRUE)

## load propensity score
ps3 <- read.csv('KSlayers3.csv', header = FALSE)
ps3 <- ps3[,1]
ps4 <- read.csv('KSlayers4.csv', header = FALSE)
ps4 <- ps4[,1]
ps5 <- read.csv('KSlayers5.csv', header = FALSE)
ps5 <- ps5[,1]
ps6 <- read.csv('KSlayers6.csv', header = FALSE)
ps6 <- ps6[,1]

## ATE and Balance Estimation
n <- length(s)
p <- length(ck_values$ck)
M <- rep(NA, n)
N <- list(global = matrix(NA, nrow = n, ncol = 4), local = M)
L <- matrix(nrow = n, ncol = p)
Lm <- list(Z1 = L, Z2 = L, Z3 = L, Z4 = L)

Balance <- list(l3 = N, l4 = N, l5 = N, l6 = N)

## Whole LSD values
TLSD <- list(l3 = Lm, l4 = Lm, l5 = Lm, l6 = Lm)

KS <- Kang_Schafer_Simulation(n = 5000, seeds = s)

## balance 
ck <- ck_values$ck
h <- ck_values$h

l3 <- apply(KS$Data[,3:6], 2, function(x) LSD(x, KS$Data[,2], ps3, 
                                              ck, h, gaussian_kernel)) 
TLSD$l3$Z1 <- l3$Z1$LSD
TLSD$l3$Z2 <- l3$Z2$LSD
TLSD$l3$Z3 <- l3$Z3$LSD
TLSD$l3$Z4 <- l3$Z4$LSD

mean_LSD <- unlist(lapply(l3, function(x) x$LSD_mean))
Balance$l3$global <- unlist(lapply(l3, function(x) x$GSD))
Balance$l3$local <- mean(mean_LSD)


l4 <- apply(KS$Data[,3:6], 2, function(x) LSD(x, KS$Data[,2], ps4, 
                                              ck, h, gaussian_kernel)) 
TLSD$l4$Z1 <- l4$Z1$LSD
TLSD$l4$Z2 <- l4$Z2$LSD
TLSD$l4$Z3 <- l4$Z3$LSD
TLSD$l4$Z4 <- l4$Z4$LSD

mean_LSD <- unlist(lapply(l4, function(x) x$LSD_mean))
Balance$l4$global <- unlist(lapply(l4, function(x) x$GSD))
Balance$l4$local <- mean(mean_LSD)

l5 <- apply(KS$Data[,3:6], 2, function(x) LSD(x, KS$Data[,2], ps5, 
                                              ck, h, gaussian_kernel)) 
TLSD$l5$Z1 <- l5$Z1$LSD
TLSD$l5$Z2 <- l5$Z2$LSD
TLSD$l5$Z3 <- l5$Z3$LSD
TLSD$l5$Z4 <- l5$Z4$LSD

mean_LSD <- unlist(lapply(l5, function(x) x$LSD_mean))
Balance$l5$global <- unlist(lapply(l5, function(x) x$GSD))
Balance$l5$local <- mean(mean_LSD)

l6 <- apply(KS$Data[,3:6], 2, function(x) LSD(x, KS$Data[,2], ps6, 
                                              ck, h, gaussian_kernel)) 
TLSD$l6$Z1 <- l6$Z1$LSD
TLSD$l6$Z2 <- l6$Z2$LSD
TLSD$l6$Z3 <- l6$Z3$LSD
TLSD$l6$Z4 <- l6$Z4$LSD

mean_LSD <- unlist(lapply(l6, function(x) x$LSD_mean))
Balance$l6$global <- unlist(lapply(l6, function(x) x$GSD))
Balance$l6$local <- mean(mean_LSD)


ggsave("KS network layer Figure.pdf", plot = LSD_plot_true(TLSD), width = 8, height = 8, device = "pdf", family = "Times")
