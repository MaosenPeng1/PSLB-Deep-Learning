## LBC_Net
library(dplyr)
source("functions.R")

## load data

s <- 1:500
file <- paste0("data", s, ".csv")
data_list <- lapply(file, read.csv, header = TRUE)
file_ck <- paste0("ck_h", s, ".csv")
ck_list <- lapply(file_ck, read.csv, header = TRUE)
p <- 84
delta <- 1
n <- length(s)

file_ps <- paste0("ps_lbc_net", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_lbc_net <- do.call(cbind, ps_list)

file_ps <- paste0("ps_nn", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_nn <- do.call(cbind, ps_list)

file_wt <- paste0("wt_cbipm", s, ".csv")
wt_list <- lapply(file_wt, read.csv, header = FALSE, skip = 1)
wt_cbipm <- do.call(cbind, wt_list)

file_wt <- paste0("wt_sbw", s, ".csv")
wt_list <- lapply(file_wt, read.csv, header = FALSE, skip = 1)
wt_sbw <- do.call(cbind, wt_list)

ps_true <- readRDS("ps_true_matrix.rds")
logistic <- readRDS("other_methods_res_log.rds")
other_methods <- readRDS("other_methods_res_eb_cbps.rds")
osqp <- readRDS("osqp_res.rds")

true <- Model_based_estimates_sim(ps_true, delta)
lbc_net <- Model_based_estimates_sim(ps_lbc_net, delta)
nn <- Model_based_estimates_sim(ps_nn, delta)
cbipm <- Weight_based_estimates_sim(wt_cbipm, 1, delta)
sbw <- Weight_based_estimates_sim(wt_sbw, 1, delta)

res <- list(true = true,
              logistic = logistic,
                  osqp = osqp,
                  cbipm = cbipm,
                  sbw = sbw,
                  eb = other_methods$eb,
                  cbps = other_methods$cbps,
                  nn = nn,
                  lbc_net = lbc_net)

saveRDS(res, "m3.rds")

