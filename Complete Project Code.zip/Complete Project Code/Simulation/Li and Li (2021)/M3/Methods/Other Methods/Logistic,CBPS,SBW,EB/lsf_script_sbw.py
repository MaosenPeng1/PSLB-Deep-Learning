import os

def create_lsf_content(seed, queue_name):
    content = f"""#BSUB -J sbw_jobm3t{seed}
#BSUB -W 24:00
#BSUB -o /path/to/log/sbw_jobm3t{seed}.out
#BSUB -e /path/to/log/sbw_jobm3t{seed}.err
#BSUB -cwd /path/to/working_directory
#BSUB -q {queue_name}
#BSUB -u your_email@example.com
#BSUB -n 1
#BSUB -M 40
#BSUB -R rusage[mem=40]

module load R

Rscript /path/to/working_directory/sbw.R {seed}
"""
    return content

# Set the paths
output_dir = '/path/to/working_directory'
queue_names = ["e40medium", "medium", "e80medium"]

seed_values = range(1, 501) 

for seed in seed_values:
    lsf_content = create_lsf_content(seed, queue_names[seed % 3])
    with open(os.path.join(output_dir, f'sbw_job{seed}.lsf'), 'w') as lsf_file:
        lsf_file.write(lsf_content)