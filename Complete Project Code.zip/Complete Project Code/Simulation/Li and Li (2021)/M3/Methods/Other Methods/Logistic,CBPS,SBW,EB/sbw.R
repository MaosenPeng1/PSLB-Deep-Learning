library(sbw)
library(dplyr)
source("functions.R")

# Read command line argument for seed
args <- commandArgs(trailingOnly = TRUE)
s <- as.integer(args[1])

set.seed(100)
file <- paste0("data", s, ".csv")
data <- read.csv(file, header = TRUE)
p <- 84

bal <- list()
bal$bal_cov <- colnames(data[,3:86])
bal$bal_tol <- 0.02
bal$bal_std <- "group"

sbw.fit <- sbw(data,
               ind = "Tr",
               out = "Y",
               bal = bal,
               sol = list(sol_nam = "quadprog"),
               par = list(par_est = "ate"),
               mes = FALSE)
wt <- sbw.fit$dat_weights$sbw_weights

output_file <- paste0("wt_sbw", s, ".csv")
write.csv(wt, file = output_file, row.names = FALSE)