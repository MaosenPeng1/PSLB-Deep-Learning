library(CBPS)
library(ebal)
library(sbw)
library(dplyr)
library(foreach)
library(doParallel)
source("functions.R")

s <- 1:500
set.seed(100)
file <- paste0("data", s, ".csv")
data_list <- lapply(file, read.csv, header = TRUE)
file_ck <- paste0("ck_h", s, ".csv")
ck_list <- lapply(file_ck, read.csv, header = TRUE)
p <- 20
n <- length(s)
# model <- "true" ## or "mis" for propensity score model
model <- "mis" ## or "mis" for propensity score model
if (model == "true"){
  delta <- c(1, 1.96, 1.69)
} else if (model == "mis"){
  delta <- c(1, 2.28, 1.66)
}
registerDoParallel(cores = detectCores())

###################################
## Logistic regression
###################################
logistic_model <- function(data){
  
  logistic.fit <- glm(Tr~., data = data[,4:24], family = 'binomial')
  return(logistic.fit$fitted.values)
  
}

ps_log <- foreach(data = data_list, .combine = cbind) %dopar% {
  
  logistic_model(data)
  
}

logistic_res <- Model_based_estimates_sim(ps_log, delta)

#####################################
## CBPS
#####################################
CBPS_model <- function(data){

  cbps.fit <- CBPS(Tr~., data = data[,4:24], method = 'exact', ATT = 0, twostep = FALSE)
  return(cbps.fit$fitted.values)

}

# Run the CBPS models in parallel
ps_cbps <- foreach(data = data_list, .combine = cbind) %dopar% {

  CBPS_model(data)

}

cbps_res <- Model_based_estimates_sim(ps_cbps, delta)

#####################################
## EB
#####################################
eb_model_att <- function(data, Y){
  
  X <- data[,5:24]
  Z <- data[,4]
  wt_att <- rep(NA, nrow(data))
  
  eb.att.fit <- ebalance(Treatment=Z,
                         X=X)
  wt_att[Z==1] <- rep(1, sum(Z))
  wt_att[Z==0] <- eb.att.fit$w
  
  return(wt_att)
  
}

wt_att <- foreach(data = data_list, .combine = cbind) %dopar% {
  
  eb_model_att(data, data[,1])
  
}

eb_model_atc <- function(data, Y){
  
  X <- data[,5:24]
  Z <- data[,4]
  wt_atc <- rep(NA, nrow(data))
  
  eb.atc.fit <- ebalance(Treatment=1-Z,
                         X=X)
  wt_atc[Z==0] <- rep(1, sum(1-Z))
  wt_atc[Z==1] <- eb.atc.fit$w
  
  return(wt_atc)
  
}

wt_atc <- foreach(data = data_list, .combine = cbind) %dopar% {
  
  eb_model_atc(data, data[,1])
  
}

wt_eb <- list(wt_att = wt_att, wt_atc = wt_atc)

eb_res <- Weight_based_estimates_sim(wt_eb, 2, delta)

#####################################
## SBW
#####################################
sbw_model <- function(data){

  bal <- list()
  bal$bal_cov <- colnames(data[,5:24])
  bal$bal_tol <- 0.02
  bal$bal_std <- "group"

  sbw.fit <- sbw(data,
                 ind = "Tr",
                 out = "Y",
                 bal = bal,
                 sol = list(sol_nam = "quadprog"),
                 par = list(par_est = "ate"),
                 mes = FALSE)
  return(sbw.fit$dat_weights$sbw_weights)

}

wt_sbw <- foreach(data = data_list, .combine = cbind, .packages = c('dplyr', 'sbw')) %dopar% {

  sbw_model(data)

}

sbw_res <- Weight_based_estimates_sim(wt_sbw, 1, delta)

res <- list(logistic = logistic_res,
            cbps = cbps_res,
            eb = eb_res,
            sbw = sbw_res)

saveRDS(res, "other_methods_res.rds")


























