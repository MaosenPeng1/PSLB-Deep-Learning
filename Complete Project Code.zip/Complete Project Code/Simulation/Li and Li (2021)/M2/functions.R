ipw <- function(Z, p){
  ## Purpose: inverse probability function
  ## Input: 
  ##    Z -- treatment variable
  ##    p -- propensity score
  ## Output:
  ##    single value or a vector under gaussian kernel
  weight <- Z/p + (1-Z)/(1-p)
  return(weight)
  
}

Y_infer = function(Y, wt, Z) {
  ## Purpose: calculate estimated average outcome
  ## Input: 
  ##    Y -- observed outcome
  ##    Z -- treatment variable
  ##    wt -- inverse probability weights
  ## Output:
  ##    a vector of estimated average outcome
  mu_ipw = sum(Z * wt * Y) / sum(Z * wt)
  
  return(mu_ipw)
}

ATE_infer <-  function(Y, wt, Z) {
  ## Purpose: calculate estimated average treatment effect (ATE)
  ## Input: 
  ##    Y -- observed outcome
  ##    Z -- treatment variable
  ##    wt -- inverse probability weights
  ## Output:
  ##    a vector of estimated ATE
  ATE_case = sum(Z * wt * Y) / sum(Z * wt)
  ATE_control = sum((1-Z) * wt * Y) / sum((1-Z) * wt)
  
  ATE_after = ATE_case - ATE_control
  return(ATE_after)
  
}

gaussian_kernel <- function(x){
  ## Purpose: gaussian kernel function
  ## Input: 
  ##    x -- single value or a vector
  ## Output:
  ##    single value or a vector under gaussian kernel
  K_x <- 1/sqrt(2*pi) * exp(-x^2/2)
  
  return(K_x)
  
}


GSD_wt <- function(X, Z, wt){
  ## Purpose: GSD estimation for methods that estimate weight directly
  ## Input: 
  ##    X -- covariate 
  ##    Z -- treatment variable
  ##    p -- propensity score
  ##    ck -- pre-specified points range from 0 to 1
  ##    h -- a vector of bandwidths 
  ##    kernel_function -- kernel function
  ## Output:
  ##    values of GSD for a covariate
  
  ## Estimating Global Standardized Differences (GSD)
  mu1 <- sum(Z * wt * X) / sum(Z * wt)
  mu0 <- sum((1-Z) * wt * X) / sum((1-Z) * wt)
  v1 <- sum(Z * wt * (X - mu1)^2) / sum(Z * wt)
  v0 <- sum((1-Z) * wt * (X - mu0)^2) / sum((1-Z) * wt)
  ess1 <- (sum(Z * wt))^2 / sum(Z * wt^2)
  ess0 <- (sum((1-Z) * wt))^2 / sum((1-Z) * wt^2)
  
  GSD <- 100 * (mu1 - mu0) / sqrt((ess1 * v1 + ess0 * v0) / (ess1 + ess0))
  
  return(GSD)
  
}

GSD <- function(X, Z, p){
  ## Purpose: GSD estimation
  ## Input: 
  ##    X -- covariate 
  ##    Z -- treatment variable
  ##    p -- propensity score
  ##    ck -- pre-specified points range from 0 to 1
  ##    h -- a vector of bandwidths 
  ##    kernel_function -- kernel function
  ## Output:
  ##    values of GSD for a covariate
  
  ## Estimating Global Standardized Differences (GSD)
  w <- 1
  W <- w / (Z * p + (1-Z) * (1-p))
  mu1 <- sum(Z * W * X) / sum(Z * W)
  mu0 <- sum((1-Z) * W * X) / sum((1-Z) * W)
  v1 <- sum(Z * W * (X - mu1)^2) / sum(Z * W)
  v0 <- sum((1-Z) * W * (X - mu0)^2) / sum((1-Z) * W)
  ess1 <- (sum(Z * W))^2 / sum(Z * W^2)
  ess0 <- (sum((1-Z) * W))^2 / sum((1-Z) * W^2)
  
  GSD <- 100 * (mu1 - mu0) / sqrt((ess1 * v1 + ess0 * v0) / (ess1 + ess0))
  
  return(GSD)
  
}

LSD <- function(X, Z, p, ck, h, kernel_function){
  ## Purpose: LSD and GSD estimation
  ## Input: 
  ##    X -- covariate 
  ##    Z -- treatment variable
  ##    p -- propensity score
  ##    ck -- pre-specified points range from 0 to 1
  ##    h -- a vector of bandwidths 
  ##    kernel_function -- kernel function
  ## Output:
  ##    a list containing LSD, mean of LSD, and GSD
  N <- length(p)
  LSD <- numeric(length(ck))
  
  for (i in seq_along(ck)){
    
    ## Estimating Local Standardized Differences (LSD)
    w <- 1/h[i] * kernel_function( (ck[i] - p) / h[i])
    
    W <- w / (Z * p + (1-Z) * (1-p))
    
    mu1 <- sum(Z * W * X) / sum(Z * W)
    mu0 <- sum((1-Z) * W * X) / sum((1-Z) * W)
    v1 <- sum(Z * W * (X - mu1)^2) / sum(Z * W)
    v0 <- sum((1-Z) * W * (X - mu0)^2) / sum((1-Z) * W)
    
    ess1 <- (sum(Z * W))^2 / sum(Z * W^2)
    ess0 <- (sum((1-Z) * W))^2 / sum((1-Z) * W^2)
    LSD[i] <- 100 * (mu1 - mu0) / sqrt((ess1 * v1 + ess0 * v0) / (ess1 + ess0))
    
    
  }
  
  LSD_mean <- mean(abs(LSD))
  
  return(list(LSD=abs(LSD), LSD_mean = LSD_mean))
  
}

span_to_bandwidth <- function(rho, ck, p){
  ## Purpose: transform span to bandwidth
  ## Input: 
  ##    rho -- span
  ##    ck -- pre-specified points range from 0 to 1
  ##    p -- propensity score
  ## Output:
  ##    a vector of bandwidth for each ck
  N <- length(p)
  h <- numeric(length(ck))
  
  for (i in seq_along(ck)){
    
    d <- abs(ck[i] - p)
    d_sort <- sort(d)
    h[i] <- d_sort[ceiling(N * rho)]
    
  }
  
  return(h)
  
}

Col_bias_variance_rmse <-  function(Est, True) {
  ## Purpose: calculate estimated outcome measures
  ## Input: 
  ##    Y -- observed outcome
  ##    Z -- treatment variable
  ##    wt -- inverse probability weights
  ## Output:
  ##    a vector of estimated average outcome
  percent_bias <- 100*(mean(Est) - True)/True
  variance <- var(Est)
  rmse <- sqrt(mean((Est - True)^2))
  
  out <- data.frame(pbias = percent_bias, var = variance, rmse = rmse)
  
  return(out)
  
}

mirror_plot <- function(ps, Z){
  ## Purpose: mirror histogram
  ## Input: 
  ##    ps -- propensity score
  ##    Z -- treatment variable
  ## Output:
  ##    mirror histogram 
  data <- data.frame(ps=ps, Z=Z)
  plot <- data %>%
    ggplot(aes(x = ps)) +
    geom_histogram(aes(y = after_stat(count)), 
                   fill = "white",
                   color = 'black',
                   data = ~ subset(., Z == 0), 
                   bins = 70) +
    geom_histogram(aes(y = -after_stat(count)), 
                   data = ~ subset(., Z == 1),
                   bins = 70,
                   fill = "white",
                   color = 'black') +
    geom_hline(yintercept = 0) +
    labs(x = "Propensity Score",
         y = "Frequency") +
    theme(
      panel.background = element_blank(),
      axis.line = element_line(colour = "black"),
      axis.title = element_text(size = 20),      # Axis title font size
      axis.text = element_text(size = 20),       # Axis text font size
      plot.title = element_text(size = 20),      # Title font size
      legend.text = element_text(size = 20),     # Legend text font size
      legend.title = element_text(size = 20)     # Legend title font size
    ) +
    scale_y_continuous(breaks = c(-2000, -1000, -500, 0, 500, 1000, 2000, 3000),
                       label = c(2000, 1000, 500, 0, 500, 1000, 2000, 3000)) +
    annotate("text", 
             label = "Z=0",
             x = 0.75,
             y = 1500,
             size = unit(6, "pt")) +
    annotate("text", 
             label = "Z=1",
             x = 0.75,
             y = -1500,
             size = unit(6, "pt"))
  
  return(plot)
  
}

LSD_balance_plot <- function(ds){
  ## Purpose: Figure 3
  ## Input: 
  ##    ds -- Balance Results
  ## Output:
  ##    Figure 3
  
  # Calculate column means
  f1_colmean <- function(mat){
    mean_list <- lapply(mat, colMeans)
    mean_matrix <- do.call(rbind, mean_list)
    return(colMeans(mean_matrix))
  }
  
  ds <- lapply(ds, f1_colmean)
  
  # Combine into a new data frame
  ds_new <- do.call(rbind, lapply(1:length(ds), function(i){
    data.frame(CK = 1:length(ds[[i]]),
               Mean = ds[[i]],
               Method = names(ds)[i])
  }))
  
  # Generate numeric labels for CK
  numeric_labels <- rep(sprintf("%.2f", seq(0.01, 0.99, by = 0.01)), length(ds))
  ds_new$CK <- numeric_labels
  
  # Define line types, shapes, and colors for each method
  # line_types <- c("TRUE PS" = "twodash", "LOGISTIC" = "dotdash", "CBPS" = "dashed", "NN" = "dotted", "LBC-NET" = "solid")
  # point_shapes <- c("TRUE PS" = 18, "LOGISTIC" = 15, "CBPS" = 17, "NN" = 16, "LBC-NET" = 1)
  custom_colors <- c("TRUE PS" = "#ff7f0e", "LOGISTIC" = "#d62728", "CBPS" = "#2ca02c", "NN" = "#1f77b4", "LBC-NET" = "#9467bd")
  
  # Plot with both points and boxplots having the same shape for consistency
  pt <- ggplot(ds_new, aes(x = CK, y = Mean, color = Method)) +
    geom_line(size = 1) +  # Increased line width
    geom_point(size = 0.9) +  # Smaller point size for the line plot
    scale_x_discrete(breaks = c(0.01, 0.11, 0.21, 0.31, 0.41, 0.51, 0.61, 0.71, 0.81, 0.91, 0.99), labels = c(0.01, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.99)) +
    theme_bw(base_size = 20) + 
    theme(legend.position = "bottom",
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          axis.title = element_text(size = 20),
          axis.text = element_text(size = 20),
          legend.text = element_text(size = 20),
          legend.title = element_text(size = 20)) +
    labs(x = "Propensity Score", y = "LSD(%)") +
    # scale_linetype_manual(values = line_types) +
    # scale_shape_manual(values = point_shapes) +
    scale_color_manual(values = custom_colors) +
    guides(
      shape = guide_legend(override.aes = list(size = 1.7))  # Custom size for the legend points
    )
  
  # Add boxplots for each method, sharing the same shapes and fill
  for (i in unique(ds_new$Method)){
    ds_sub <- subset(vdata, Method == i)
    pt <- pt + geom_boxplot(data = ds_sub, 
                            aes(x = CK, y = LSD, color = Method), outlier.shape = 4, outlier.size = 1,
                            width = 0.5, 
                            position = position_dodge(width = 0.5)) +
      geom_point(data = ds_sub, aes(x = CK, y = LSD), size = 0, position = position_dodge(width = 0.5)) +
      stat_boxplot(data = ds_sub,
                   aes(x = CK, y = LSD, color = Method, group = interaction(CK, Method)),
                   geom = "errorbar",
                   width = 1.5,
                   position = position_dodge(width = 0.5))
  }
  
  # Restrain y-axis to (0, 35)
  pt <- pt + scale_y_continuous(limits = c(0, 20))
  
  return(pt)
}

Model_based_estimates_sim <- function(ps_list, delta) {
  ## Purpose: Calculate the estimates for model-based methods in simulation settings
  ## Input: 
  ##    ps -- list of propensity score
  ## Output:
  ##    list of estimates
  
  # Initialize variables for GSD and LSD
  L <- matrix(nrow = n, ncol = 99)
  gsd = matrix(NA, nrow = n, ncol = p)
  variable_names <- paste("X", 1:p, sep = "")
  TLSD <- setNames(lapply(variable_names, function(x) L), variable_names)
  ATE <- list(h0=rep(NA, n), h1=rep(NA, n), h2=rep(NA, n))
  
  for (i in 1:n){
    
    ds <- data_list[[i]]
    X <- ds[,5:24]
    Z <- ds[,4]
    Y0 <- ds[,1]
    Y1 <- ds[,2]
    Y2 <- ds[,3]      
    
    ## ATE estimation
    wt <- ipw(Z, ps_list[,i])
    ## ATE estimation
    ATE$h0[i] <- ATE_infer(Y0, wt, Z)
    ATE$h1[i] <- ATE_infer(Y1, wt, Z)
    ATE$h2[i] <- ATE_infer(Y2, wt, Z)
    
    ## GSD estimation
    GSD_res <- apply(X, 2, function(x) GSD(x, Z, ps_list[,i])) 
    gsd[i,] <- unlist(lapply(GSD_res, function(x) abs(x)))
    
    ## LSD estimation
    ck <- ck_list[[i]]$ck
    h <- ck_list[[i]]$h
    LSD_res <- apply(X, 2, function(x) LSD(x, Z, ps_list[,i], ck, h, gaussian_kernel)) 
    for (j in 1:p) {
      
      var_name <- paste("X", j, sep = "")
      TLSD[[var_name]][i, ] <- LSD_res[[var_name]]$LSD
      
    }
    
  }
  
  out_measures0 <- Col_bias_variance_rmse(ATE$h0, delta[1])
  out_measures1 <- Col_bias_variance_rmse(ATE$h1, delta[2])
  out_measures2 <- Col_bias_variance_rmse(ATE$h2, delta[3])
  
  pbias <- list(h0=NA, h1=NA, h2=NA)
  pbias$h0 <- out_measures0$pbias
  pbias$h1 <- out_measures1$pbias
  pbias$h2 <- out_measures2$pbias 
  
  rmse <- list(h0=NA, h1=NA, h2=NA)
  rmse$h0 <- out_measures0$rmse
  rmse$h1 <- out_measures1$rmse
  rmse$h2 <- out_measures2$rmse
  
  var <- list(h0=NA, h1=NA, h2=NA)
  var$h0 <- out_measures0$var
  var$h1 <- out_measures1$var
  var$h2 <- out_measures2$var
  
  ## Result summary
  res <- list(
    pbias = pbias,
    rmse = rmse,
    var = var,
    gsd = gsd,
    lsd = TLSD
  )
  
  return(res)
  
}

Weight_based_estimates_sim <- function(wt_list, type = 1, delta) {
  ## Purpose: Calculate the estimates for model-based methods for simulation results
  ## Input: 
  ##    wt -- list of weights
  ##    type -- type of weights, 1 is ate weight, 2 is att and atc weights.
  ## Output:
  ##    list of estimates
  
  # Initialize variables for GSD
  ATE <- list(h0=rep(NA, n), h1=rep(NA, n), h2=rep(NA, n))
  gsd <- matrix(NA, nrow = n, ncol = p)
  
  if (type == 1){
    
    for (i in 1:n){
      
      ds <- data_list[[i]]
      X <- ds[,5:24]
      Z <- ds[,4]
      Y0 <- ds[,1]
      Y1 <- ds[,2]
      Y2 <- ds[,3]  
      
      ## ATE estimation
      ATE$h0[i] <- ATE_infer(Y0, wt_list[,i], Z)
      ATE$h1[i] <- ATE_infer(Y1, wt_list[,i], Z)
      ATE$h2[i] <- ATE_infer(Y2, wt_list[,i], Z)
      
      ## GSD estimation
      GSD_res <- apply(X, 2, function(x) GSD_wt(x, Z, wt_list[,i])) 
      gsd[i,] <- unlist(lapply(GSD_res, function(x) abs(x)))
      
    }
    
  } else if(type == 2){
    
    wt_att <- wt_list$wt_att
    wt_atc <- wt_list$wt_atc
    
    for (i in 1:n){
      
      ds <- data_list[[i]]
      X <- ds[,5:24]
      Z <- ds[,4]
      Y0 <- ds[,1]
      Y1 <- ds[,2]
      Y2 <- ds[,3]  
      pi <- sum(Z)/length(Z)
      
      ## ATE estimation
      ATT <- ATE_infer(Y0, wt_att[,i], Z)
      ATC <- ATE_infer(Y0, wt_atc[,i], Z)
      ATE$h0[i] <- pi*ATT + (1-pi)*ATC
      
      ATT <- ATE_infer(Y1, wt_att[,i], Z)
      ATC <- ATE_infer(Y1, wt_atc[,i], Z)
      ATE$h1[i] <- pi*ATT + (1-pi)*ATC
      
      ATT <- ATE_infer(Y2, wt_att[,i], Z)
      ATC <- ATE_infer(Y2, wt_atc[,i], Z)
      ATE$h2[i] <- pi*ATT + (1-pi)*ATC
      
      ## GSD
      GSD_res <- apply(X, 2, function(x) GSD_wt(x, Z, wt_att[,i])) 
      gsd[i,] <- unlist(lapply(GSD_res, function(x) abs(x)))
      
    }
    
  }
  
  out_measures0 <- Col_bias_variance_rmse(ATE$h0, delta[1])
  out_measures1 <- Col_bias_variance_rmse(ATE$h1, delta[2])
  out_measures2 <- Col_bias_variance_rmse(ATE$h2, delta[3])
  
  pbias <- list(h0=NA, h1=NA, h2=NA)
  pbias$h0 <- out_measures0$pbias
  pbias$h1 <- out_measures1$pbias
  pbias$h2 <- out_measures2$pbias 
  
  rmse <- list(h0=NA, h1=NA, h2=NA)
  rmse$h0 <- out_measures0$rmse
  rmse$h1 <- out_measures1$rmse
  rmse$h2 <- out_measures2$rmse
  
  var <- list(h0=NA, h1=NA, h2=NA)
  var$h0 <- out_measures0$var
  var$h1 <- out_measures1$var
  var$h2 <- out_measures2$var
  
  ## Result summary
  res <- list(
    pbias = pbias,
    rmse = rmse,
    var = var,
    gsd = gsd
  )
  
  return(res)
  
}

Find_true_delta_new = function(n, p1, K, beta,delta_function) {
  # n: sample size
  # p1: probability of X4
  # K: number of additional covariates 
  # beta: coefficients
  # delta_function: heterogeneous effect function
  require(MASS)
  X0 = rep(1, n)
  X4 = rbinom(n, size = 1, prob = p1)
  X4_p = 0.6*X4 + 0.4*(1-X4)
  X3 = c()
  for (i in 1:length(X4_p)) {
    X3[i] = rbinom(1, size = 1, prob = X4_p[i])
  }
  mean_X1 = -X3 + X4 + 0.5*X3*X4
  mean_X2 = X3 - X4 + X3*X4
  M1 = matrix(c(1,0.5,0.5,1), nrow = 2, ncol = 2)
  M2 = matrix(c(2,0.25,0.25,2), nrow = 2, ncol = 2)
  X1_X2 = matrix(nrow = n, ncol = 2, byrow = T)
  for (i in 1:n) {
    X1_X2[i,] = mvrnorm(1, mu = c(mean_X1[i], mean_X2[i]), Sigma = X3[i]*M1 + (1-X3[i])*M2)
  }
  if(K == 0) {
    X_1to4 = cbind(X1_X2, X3, X4)
    Data_X = cbind(X0, X_1to4, X_1to4[,1]*X_1to4[,2], 
                   X_1to4[,1]*X_1to4[,3], X_1to4[,1]*X_1to4[,4],
                   X_1to4[,2]*X_1to4[,3], X_1to4[,2]*X_1to4[,4],
                   X_1to4[,3]*X_1to4[,4], X_1to4^2, log(abs(X_1to4[,1:2])))
  } else if (K != 0) {
    X_normal = matrix(nrow = n, ncol = round(K/2), byrow = T)
    for(i in 1:n) {
      X_normal[i,] = mvrnorm(1, mu = rep(0, round(K/2)), 
                             Sigma = diag(x = 1.6, round(K/2))+matrix(rep(0.4,round(K/2)*round(K/2)), round(K/2)))
    }
    X_binary = matrix(nrow = n, ncol = round(K/2), byrow = T)
    for (i in 1:round(K/2)) {
      X_binary[,i] = rbinom(n, size = 1, prob = p1)
    }
    X_1to4 = cbind(X1_X2, X3, X4)
    Data_X = cbind(X0, X_1to4, X_1to4[,1]*X_1to4[,2], 
                   X_1to4[,1]*X_1to4[,3], X_1to4[,1]*X_1to4[,4],
                   X_1to4[,2]*X_1to4[,3], X_1to4[,2]*X_1to4[,4],
                   X_1to4[,3]*X_1to4[,4], X_1to4^2, log(abs(X_1to4[,1:2])), X_normal, X_binary)
  }
  e_0 = exp(Data_X%*%beta)
  PS = c()
  for (i in 1:n) {
    PS[i] = (e_0[i])/(1+e_0[i])
  }
  Z = c()
  for (i in 1:n) {
    Z[i] = rbinom(1, size = 1, prob = PS[i])
  }
  delta = delta_function(PS)
  DM_good = cbind(Z, PS, delta, Data_X)
  W_good = ipw(DM_good[,1], PS) 
  TrueDelta_ipw = mean(W_good*delta)/mean(W_good)
  return(True_delta_ipw = TrueDelta_ipw)
}
