## LBC_Net
library(dplyr)
source("functions.R")

## load data
s <- 1:500
file <- paste0("data", s, ".csv")
data_list <- lapply(file, read.csv, header = TRUE)
file_ck <- paste0("ck_h", s, ".csv")
ck_list <- lapply(file_ck, read.csv, header = TRUE)
p <- 20
delta <- c(1, 2.28, 1.66)
n <- length(s)

file_ps <- paste0("ps_lbc_net_no_vae", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_lbc_net_no_vae <- do.call(cbind, ps_list)

file_ps <- paste0("ps_lbc_net_bal_only", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_lbc_net_bal_only <- do.call(cbind, ps_list)

file_ps <- paste0("ps_lbc_net_bce", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_lbc_net_bce <- do.call(cbind, ps_list)

file_ps <- paste0("ps_lbc_net", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_lbc_net <- do.call(cbind, ps_list)

lbc_net_no_vae <- Model_based_estimates_sim(ps_lbc_net_no_vae, delta)
lbc_net_bal_only <- Model_based_estimates_sim(ps_lbc_net_bal_only, delta)
lbc_net_bce <- Model_based_estimates_sim(ps_lbc_net_bce, delta)
lbc_net <- Model_based_estimates_sim(ps_lbc_net, delta)

res <- list(lbc_net_no_vae = lbc_net_no_vae,
            lbc_net_bal_only = lbc_net_bal_only,
            lbc_net_bce = lbc_net_bce,
            lbc_net = lbc_net)

saveRDS(res, "ablation_mis.rds")


