###################################################################################################
##################################################################################################
############################## Results ########################################################
####################################################################################################
#####################################################################################################
res_t <- readRDS("ablation.rds")
res_m <- readRDS("ablation_mis.rds")

ate_table_true <- data.frame(
  Methods = c(rep("lbc_net_no_vae", 3), rep("lbc_net_bal_only", 3), rep("lbc_net_bce", 3), rep("lbc_net", 3)),
  Outcome = rep(c("h0", "h1", "h2"), 4),
  Bias = c(res_t$lbc_net_no_vae$pbias$h0, res_t$lbc_net_no_vae$pbias$h1, res_t$lbc_net_no_vae$pbias$h2,
            res_t$lbc_net_bal_only$pbias$h0, res_t$lbc_net_bal_only$pbias$h1, res_t$lbc_net_bal_only$pbias$h2,
            res_t$lbc_net_bce$pbias$h0, res_t$lbc_net_bce$pbias$h1, res_t$lbc_net_bce$pbias$h2,
            res_t$lbc_net$pbias$h0, res_t$lbc_net$pbias$h1, res_t$lbc_net$pbias$h2),
  RMSE = c(res_t$lbc_net_no_vae$rmse$h0, res_t$lbc_net_no_vae$rmse$h1, res_t$lbc_net_no_vae$rmse$h2,
           res_t$lbc_net_bal_only$rmse$h0, res_t$lbc_net_bal_only$rmse$h1, res_t$lbc_net_bal_only$rmse$h2,
           res_t$lbc_net_bce$rmse$h0, res_t$lbc_net_bce$rmse$h1, res_t$lbc_net_bce$rmse$h2,
           res_t$lbc_net$rmse$h0, res_t$lbc_net$rmse$h1, res_t$lbc_net$rmse$h2),
  Variance = c(res_t$lbc_net_no_vae$var$h0, res_t$lbc_net_no_vae$var$h1, res_t$lbc_net_no_vae$var$h2,
               res_t$lbc_net_bal_only$var$h0, res_t$lbc_net_bal_only$var$h1, res_t$lbc_net_bal_only$var$h2,
               res_t$lbc_net_bce$var$h0, res_t$lbc_net_bce$var$h1, res_t$lbc_net_bce$var$h2,
               res_t$lbc_net$var$h0, res_t$lbc_net$var$h1, res_t$lbc_net$var$h2),
  model = rep("Standard", 4)
)

ate_table_mis <- data.frame(
  Methods = c(rep("lbc_net_no_vae", 3), rep("lbc_net_bal_only", 3), rep("lbc_net_bce", 3), rep("lbc_net", 3)),
  Outcome = rep(c("h0", "h1", "h2"), 4),
  Bias = c(res_m$lbc_net_no_vae$pbias$h0, res_m$lbc_net_no_vae$pbias$h1, res_m$lbc_net_no_vae$pbias$h2,
           res_m$lbc_net_bal_only$pbias$h0, res_m$lbc_net_bal_only$pbias$h1, res_m$lbc_net_bal_only$pbias$h2,
           res_m$lbc_net_bce$pbias$h0, res_m$lbc_net_bce$pbias$h1, res_m$lbc_net_bce$pbias$h2,
           res_m$lbc_net$pbias$h0, res_m$lbc_net$pbias$h1, res_m$lbc_net$pbias$h2),
  RMSE = c(res_m$lbc_net_no_vae$rmse$h0, res_m$lbc_net_no_vae$rmse$h1, res_m$lbc_net_no_vae$rmse$h2,
           res_m$lbc_net_bal_only$rmse$h0, res_m$lbc_net_bal_only$rmse$h1, res_m$lbc_net_bal_only$rmse$h2,
           res_m$lbc_net_bce$rmse$h0, res_m$lbc_net_bce$rmse$h1, res_m$lbc_net_bce$rmse$h2,
           res_m$lbc_net$rmse$h0, res_m$lbc_net$rmse$h1, res_m$lbc_net$rmse$h2),
  Variance = c(res_m$lbc_net_no_vae$var$h0, res_m$lbc_net_no_vae$var$h1, res_m$lbc_net_no_vae$var$h2,
               res_m$lbc_net_bal_only$var$h0, res_m$lbc_net_bal_only$var$h1, res_m$lbc_net_bal_only$var$h2,
               res_m$lbc_net_bce$var$h0, res_m$lbc_net_bce$var$h1, res_m$lbc_net_bce$var$h2,
               res_m$lbc_net$var$h0, res_m$lbc_net$var$h1, res_m$lbc_net$var$h2),
  model = rep("extended", 4)
)


## create tables
library(dplyr)
library(tidyr)
library(textables)

ate_table <- rbind(ate_table_true, ate_table_mis) 
ate_table <- ate_table %>%
  mutate(Methods_Outcome = paste(Methods, Outcome, sep = ".")) %>%
  dplyr::select(-c("Methods", "Outcome"))

ate_table_new <- ate_table %>% pivot_longer(
  cols = Bias:Variance, # Columns to pivot
  names_to = "measure", # Name of the new column that will contain the names of the pivoted columns
  values_to = "value" # Name of the new column that will contain the values of the pivoted columns
) %>%
  pivot_wider(
    names_from = c(Methods_Outcome, model), # Column to use as column names
    values_from = value # Column to use as values
  ) %>%
  mutate(measure = ifelse(measure=="Bias", "% Bias", measure)) %>%
  mutate(
    across(
      c(2:25), # Columns to format
      ~ ifelse(
        abs(.x) < 0.005, 
        format(.x, scientific = TRUE, digits = 1), # Scientific format for values < 0.005
        sprintf("%.2f", .x) # Two decimal places otherwise
      )
    )
  )


tab <- TR("DGP") %:% TR("Methods") %:% TR("Outcome Model") %:% with(ate_table_new, TR(measure)) +
  midrule() +
  TR("") %:% TR("") %:% TR("h0") %:% with(ate_table_new, TR(lbc_net.h0_Standard)) +
  TR("") %:% TR("Standard LBC-Net") %:% TR("h1") %:% with(ate_table_new, TR(lbc_net.h1_Standard)) +
  TR("") %:% TR("") %:% TR("h2") %:% with(ate_table_new, TR(lbc_net.h2_Standard)) +
  midrulep(list(c(2,6))) +
  TR("") %:% TR("") %:% TR("h0") %:% with(ate_table_new, TR(lbc_net_no_vae.h0_Standard)) +
  TR("") %:% TR("Without VAE") %:% TR("h1") %:% with(ate_table_new, TR(lbc_net_no_vae.h1_Standard)) +
  TR("Standard") %:% TR("") %:% TR("h2") %:% with(ate_table_new, TR(lbc_net_no_vae.h2_Standard)) +
  midrulep(list(c(2,6))) +
  TR("") %:% TR("") %:% TR("h0") %:% with(ate_table_new, TR(lbc_net_bal_only.h0_Standard)) +
  TR("") %:% TR("Balance Loss Only") %:% TR("h1") %:% with(ate_table_new, TR(lbc_net_bal_only.h1_Standard)) +
  TR("") %:% TR("") %:% TR("h2") %:% with(ate_table_new, TR(lbc_net_bal_only.h2_Standard)) +
  midrulep(list(c(2,6))) +
  TR("") %:% TR("") %:% TR("h0") %:% with(ate_table_new, TR(lbc_net_bce.h0_Standard)) +
  TR("") %:% TR("BCE Loss Only") %:% TR("h1") %:% with(ate_table_new, TR(lbc_net_bce.h1_Standard)) +
  TR("") %:% TR("") %:% TR("h2") %:% with(ate_table_new, TR(lbc_net_bce.h2_Standard)) +

  midrule() +
    
  TR("") %:% TR("") %:% TR("h0") %:% with(ate_table_new, TR(lbc_net.h0_extended)) +
  TR("") %:% TR("Standard LBC-Net") %:% TR("h1") %:% with(ate_table_new, TR(lbc_net.h1_extended)) +
  TR("") %:% TR("") %:% TR("h2") %:% with(ate_table_new, TR(lbc_net.h2_extended)) +
  midrulep(list(c(2,6))) +
  TR("") %:% TR("") %:% TR("h0") %:% with(ate_table_new, TR(lbc_net_no_vae.h0_extended)) +
  TR("") %:% TR("Without VAE") %:% TR("h1") %:% with(ate_table_new, TR(lbc_net_no_vae.h1_extended)) +
  TR("Extended") %:% TR("") %:% TR("h2") %:% with(ate_table_new, TR(lbc_net_no_vae.h2_extended)) +
  midrulep(list(c(2,6))) +
  TR("") %:% TR("") %:% TR("h0") %:% with(ate_table_new, TR(lbc_net_bal_only.h0_extended)) +
  TR("") %:% TR("Balance Loss Only") %:% TR("h1") %:% with(ate_table_new, TR(lbc_net_bal_only.h1_extended)) +
  TR("") %:% TR("") %:% TR("h2") %:% with(ate_table_new, TR(lbc_net_bal_only.h2_extended)) +
  midrulep(list(c(2,6))) +
  TR("") %:% TR("") %:% TR("h0") %:% with(ate_table_new, TR(lbc_net_bce.h0_extended)) +
  TR("") %:% TR("BCE Loss Only") %:% TR("h1") %:% with(ate_table_new, TR(lbc_net_bce.h1_extended)) +
  TR("") %:% TR("") %:% TR("h2") %:% with(ate_table_new, TR(lbc_net_bce.h2_extended)) 
  
# Print the table to a text variable
text_output <- capture.output(print(tab))

# Write the text output to a file
writeLines(text_output, "table_output.txt")

## LSD
LSD_balance_plot <- function(ds){
  ## Purpose: Figure 3
  ## Input: 
  ##    ds -- Balance Results
  ## Output:
  ##    Figure 3
  
  # Calculate column means
  f1_colmean <- function(mat){
    mean_list <- lapply(mat, colMeans)
    mean_matrix <- do.call(rbind, mean_list)
    return(colMeans(mean_matrix))
  }
  
  ds <- lapply(ds, f1_colmean)
  
  # Combine into a new data frame
  ds_new <- do.call(rbind, lapply(1:length(ds), function(i){
    data.frame(CK = 1:length(ds[[i]]),
               Mean = ds[[i]],
               Method = names(ds)[i])
  }))
  
  # Generate numeric labels for CK
  numeric_labels <- rep(sprintf("%.2f", seq(0.01, 0.99, by = 0.01)), length(ds))
  ds_new$CK <- numeric_labels
  
  # Define line types, shapes, and colors for each method
  line_types <- c("Standard" = "twodash", "No VAE" = "dotdash", "Balance Only" = "dashed", "BCE" = "dotted")
  point_shapes <- c("Standard" = 18, "No VAE" = 15, "Balance Only" = 17, "BCE" = 16)
  custom_colors <- c("Standard" = "#ff7f0e", "No VAE" = "#d62728", "Balance Only" = "#2ca02c", "BCE" = "#1f77b4")

  # Plot with both points and boxplots having the same shape for consistency
  pt <- ggplot(ds_new, aes(x = CK, y = Mean, linetype = Method, shape = Method, color = Method)) +
    geom_line(size = 1.2) +  # Increased line width
    geom_point(size = 0.8) +  # Smaller point size for the line plot
    scale_x_discrete(breaks = c(0.01, 0.11, 0.21, 0.31, 0.41, 0.51, 0.61, 0.71, 0.81, 0.91, 0.99), labels = c(0.01, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.99)) +
    theme_bw(base_size = 20) + 
    theme(legend.position = "bottom",
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          axis.title = element_text(size = 20),
          axis.text = element_text(size = 20),
          legend.text = element_text(size = 20),
          legend.title = element_text(size = 20)) +
    labs(x = "Propensity Score", y = "LSD(%)") +
    scale_linetype_manual(values = line_types) +
    scale_shape_manual(values = point_shapes) +
    scale_color_manual(values = custom_colors) +
    guides(
      shape = guide_legend(override.aes = list(size = 1.7))  # Custom size for the legend points
    )
  
  # Add boxplots for each method, sharing the same shapes and fill
  for (i in unique(ds_new$Method)){
    ds_sub <- subset(vdata, Method == i)
    pt <- pt + geom_boxplot(data = ds_sub, 
                            aes(x = CK, y = LSD, shape = Method, color = Method), outlier.shape = NA, 
                            width = 0.5, 
                            position = position_dodge(width = 0.5)) +
      geom_point(data = ds_sub, aes(x = CK, y = LSD, shape = Method), size = 0, position = position_dodge(width = 0.5)) +
      stat_boxplot(data = ds_sub,
                   aes(x = CK, y = LSD, color = Method, group = interaction(CK, Method)),
                   geom = "errorbar",
                   width = 1.5,
                   position = position_dodge(width = 0.5))
  }
  
  # Restrain y-axis to (0, 35)
  pt <- pt + scale_y_continuous(limits = c(0, 11))
  
  return(pt)
}

library(ggplot2)
TLSD <- list(res_t$lbc_net$lsd, res_t$lbc_net_no_vae$lsd, res_t$lbc_net_bal_only$lsd, res_t$lbc_net_bce$lsd)
names(TLSD) <- c("Standard", "No VAE", "Balance Only", "BCE")

vdata <- lapply(TLSD, f1_colmean <- function(mat){
  
  mean_list <- lapply(mat, colMeans)
  mean_matrix <- do.call(rbind, mean_list)
  
  return(mean_matrix)
  
})

violin_points_list <- list(
  Standard = seq(0.03, 0.87, by = 0.2),
  'No VAE' = seq(0.05, 0.89, by = 0.2),
  'Balance Only' = seq(0.07, 0.91, by = 0.2),
  BCE = seq(0.09, 0.93, by = 0.2)
)

vdata_long <- data.frame()
for (i in names(vdata)) {
  mat <- vdata[[i]]
  mat_long <- as.data.frame(mat) %>%
    pivot_longer(cols = everything(), names_to = "CK", values_to = "LSD") %>%
    mutate(Method = i,
           CK = rep(sprintf("%.2f", seq(0.01, 0.99, by = 0.01)), 20)) %>%
    filter(CK %in% violin_points_list[[i]])
  
  vdata_long <- rbind(vdata_long, mat_long)
  
}

vdata <- vdata_long

ggsave("m2_ablation_lsd_figure.pdf", plot = LSD_balance_plot(TLSD), width = 10, height = 8, device = "pdf", family = "Times")

