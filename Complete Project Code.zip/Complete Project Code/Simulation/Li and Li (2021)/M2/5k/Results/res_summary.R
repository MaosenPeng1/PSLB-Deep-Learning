# ----------------------------------------------------- 
# M2 
# -----------------------------------------------------

res_true <- readRDS("m2_true.rds")
res_mis <- readRDS("m2_mis.rds")
source("functions.R")

library(dplyr)
library(tidyr)
library(textables)
library(ggplot2)

ate_table_true <- data.frame(Methods = c(rep("true", 3), rep("logistic", 3), rep("SBW", 3), rep("CBIPM", 3), rep("CBPS", 3), rep("NN", 3), rep("LBC_net", 3)),
                             Outcome = rep(c("h0", "h1", "h2"), 7),
                             PBIAS = c(res_true$true$pbias$h0, res_true$true$pbias$h1, res_true$true$pbias$h2,
                                       res_true$logistic$pbias$h0, res_true$logistic$pbias$h1, res_true$logistic$pbias$h2, 
                                      res_true$sbw$pbias$h0, res_true$sbw$pbias$h1, res_true$sbw$pbias$h2, 
                                      res_true$cbipm$pbias$h0, res_true$cbipm$pbias$h1, res_true$cbipm$pbias$h2, res_true$cbps$pbias$h0, res_true$cbps$pbias$h1, res_true$cbps$pbias$h2,
                                      res_true$nn$pbias$h0, res_true$nn$pbias$h1, res_true$nn$pbias$h2, res_true$lbc_net$pbias$h0, res_true$lbc_net$pbias$h1, res_true$lbc_net$pbias$h2),
                             RMSE = c(res_true$true$rmse$h0, res_true$true$rmse$h1, res_true$true$rmse$h2,
                                      res_true$logistic$rmse$h0, res_true$logistic$rmse$h1, res_true$logistic$rmse$h2,
                                      res_true$sbw$rmse$h0, res_true$sbw$rmse$h1, res_true$sbw$rmse$h2,
                                      res_true$cbipm$rmse$h0, res_true$cbipm$rmse$h1, res_true$cbipm$rmse$h2, res_true$cbps$rmse$h0, res_true$cbps$rmse$h1, res_true$cbps$rmse$h2,
                                      res_true$nn$rmse$h0, res_true$nn$rmse$h1, res_true$nn$rmse$h2, res_true$lbc_net$rmse$h0, res_true$lbc_net$rmse$h1, res_true$lbc_net$rmse$h2),
                             Variance = c(res_true$true$var$h0, res_true$true$var$h1, res_true$true$var$h2,
                                          res_true$logistic$var$h0, res_true$logistic$var$h1, res_true$logistic$var$h2, 
                                          res_true$sbw$var$h0, res_true$sbw$var$h1, res_true$sbw$var$h2,
                                          res_true$cbipm$var$h0, res_true$cbipm$var$h1, res_true$cbipm$var$h2, res_true$cbps$var$h0, res_true$cbps$var$h1, res_true$cbps$var$h2,
                                          res_true$nn$var$h0, res_true$nn$var$h1, res_true$nn$var$h2, res_true$lbc_net$var$h0, res_true$lbc_net$var$h1, res_true$lbc_net$var$h2),
                             model = rep("Standard DGP", 21))



ate_table_mis <- data.frame(Methods = c(rep("true", 3), rep("logistic", 3), rep("SBW", 3), rep("CBIPM", 3), rep("CBPS", 3), rep("NN", 3), rep("LBC_net", 3)),
                             Outcome = rep(c("h0", "h1", "h2"), 7),
                             PBIAS = c(res_mis$true$pbias$h0, res_mis$true$pbias$h1, res_mis$true$pbias$h2,
                                       res_mis$logistic$pbias$h0, res_mis$logistic$pbias$h1, res_mis$logistic$pbias$h2, 
                                       res_mis$sbw$pbias$h0, res_mis$sbw$pbias$h1, res_mis$sbw$pbias$h2, 
                                       res_mis$cbipm$pbias$h0, res_mis$cbipm$pbias$h1, res_mis$cbipm$pbias$h2, res_mis$cbps$pbias$h0, res_mis$cbps$pbias$h1, res_mis$cbps$pbias$h2,
                                       res_mis$nn$pbias$h0, res_mis$nn$pbias$h1, res_mis$nn$pbias$h2, res_mis$lbc_net$pbias$h0, res_mis$lbc_net$pbias$h1, res_mis$lbc_net$pbias$h2),
                             RMSE = c(res_mis$true$rmse$h0, res_mis$true$rmse$h1, res_mis$true$rmse$h2,
                                      res_mis$logistic$rmse$h0, res_mis$logistic$rmse$h1, res_mis$logistic$rmse$h2, 
                                      res_mis$sbw$rmse$h0, res_mis$sbw$rmse$h1, res_mis$sbw$rmse$h2,
                                      res_mis$cbipm$rmse$h0, res_mis$cbipm$rmse$h1, res_mis$cbipm$rmse$h2, res_mis$cbps$rmse$h0, res_mis$cbps$rmse$h1, res_mis$cbps$rmse$h2,
                                      res_mis$nn$rmse$h0, res_mis$nn$rmse$h1, res_mis$nn$rmse$h2, res_mis$lbc_net$rmse$h0, res_mis$lbc_net$rmse$h1, res_mis$lbc_net$rmse$h2),
                             Variance = c(res_mis$true$var$h0, res_mis$true$var$h1, res_mis$true$var$h2,
                                          res_mis$logistic$var$h0, res_mis$logistic$var$h1, res_mis$logistic$var$h2, 
                                          res_mis$sbw$var$h0, res_mis$sbw$var$h1, res_mis$sbw$var$h2,
                                          res_mis$cbipm$var$h0, res_mis$cbipm$var$h1, res_mis$cbipm$var$h2, res_mis$cbps$var$h0, res_mis$cbps$var$h1, res_mis$cbps$var$h2,
                                          res_mis$nn$var$h0, res_mis$nn$var$h1, res_mis$nn$var$h2, res_mis$lbc_net$var$h0, res_mis$lbc_net$var$h1, res_mis$lbc_net$var$h2),
                             model = rep("Extended DGP", 21))



## create tables
library(dplyr)
library(tidyr)

ate_table <- rbind(ate_table_true, ate_table_mis) 

ate_table <- ate_table %>%
  mutate(Variance = sqrt(Variance)) %>%
  rename(ESD = Variance)

ate_table <- ate_table %>%
  mutate(Methods_Outcome = paste(Methods, Outcome, sep = ".")) %>%
  dplyr::select(-c("Methods", "Outcome"))

ate_table_new <- ate_table %>% pivot_longer(
  cols = PBIAS:ESD, # Columns to pivot
  names_to = "measure", # Name of the new column that will contain the names of the pivoted columns
  values_to = "value" # Name of the new column that will contain the values of the pivoted columns
) %>%
  pivot_wider(
    names_from = Methods_Outcome, # Column to use as column names
    values_from = value # Column to use as values
  ) %>%
  mutate(measure = ifelse(measure=="Bias", "% Bias", measure)) %>%
  mutate(
    across(
      c(3:29), # Columns to format
      ~ ifelse(
        abs(.x) < 0.005, 
        format(.x, scientific = TRUE, digits = 1), # Scientific format for values < 0.005
        sprintf("%.2f", .x) # Two decimal places otherwise
      )
    )
  )


tab <- TR(c("","","Standard DGP","Extended DGP"),cspan=c(1,1,3,3)) +
  midrulep(list(c(3,5),c(6,8))) +
  TR("Methods") %:% TR("Outcome Model") %:% with(ate_table_new, TR(measure)) +
  midrule() +
  TR("") %:% TR("h0") %:% with(ate_table_new, TR(true.h0)) +
  TR("True ps") %:% TR("h1") %:% with(ate_table_new, TR(true.h1)) +
  TR("") %:% TR("h2") %:% with(ate_table_new, TR(true.h2)) +
  midrule() +
  TR("") %:% TR("h0") %:% with(ate_table_new, TR(logistic.h0)) +
  TR("Logistic") %:% TR("h1") %:% with(ate_table_new, TR(logistic.h1)) +
  TR("") %:% TR("h2") %:% with(ate_table_new, TR(logistic.h2)) +
  midrule() +
  TR("") %:% TR("h0") %:% with(ate_table_new, TR(CBPS.h0)) +
  TR("CBPS") %:% TR("h1") %:% with(ate_table_new, TR(CBPS.h1)) +
  TR("") %:% TR("h2") %:% with(ate_table_new, TR(CBPS.h2)) +
  midrule() +
  TR("") %:% TR("h0") %:% with(ate_table_new, TR(SBW.h0)) +
  TR("SBW") %:% TR("h1") %:% with(ate_table_new, TR(SBW.h1)) +
  TR("") %:% TR("h2") %:% with(ate_table_new, TR(SBW.h2)) +
  midrule() +
  TR("") %:% TR("h0") %:% with(ate_table_new, TR(CBIPM.h0)) +
  TR("CBIPM") %:% TR("h1") %:% with(ate_table_new, TR(CBIPM.h1)) +
  TR("") %:% TR("h2") %:% with(ate_table_new, TR(CBIPM.h2)) +
  midrule() +
  TR("") %:% TR("h0") %:% with(ate_table_new, TR(NN.h0)) +
  TR("NN") %:% TR("h1") %:% with(ate_table_new, TR(NN.h1)) +
  TR("") %:% TR("h2") %:% with(ate_table_new, TR(NN.h2)) +
  midrule() +
  TR("") %:% TR("h0") %:% with(ate_table_new, TR(LBC_net.h0)) +
  TR("LBC-Net") %:% TR("h1") %:% with(ate_table_new, TR(LBC_net.h1)) +
  TR("") %:% TR("h2") %:% with(ate_table_new, TR(LBC_net.h2)) 

# Print the table to a text variable
text_output <- capture.output(print(tab))

# Write the text output to a file
writeLines(text_output, "table_output.txt")

gsd_table <- cbind(colMeans(res_true$true$gsd), colMeans(res_true$logistic$gsd), colMeans(res_true$cbipm$gsd), colMeans(res_true$sbw$gsd), colMeans(res_true$cbps$gsd), colMeans(res_true$nn$gsd), colMeans(res_true$lbc_net$gsd))
colnames(gsd_table) <- c("True", "Logistic", "CBIPM", "SBW", "CBPS", "NN", "LBC-net")
gsd_table <- round(gsd_table, 3)
gsd_table

## LSD
TLSD <- list(res_true$true$lsd, res_true$logistic$lsd, res_true$cbps$lsd, res_true$nn$lsd, res_true$lbc_net$lsd)
names(TLSD) <- c("TRUE PS", "LOGISTIC", "CBPS", "NN", "LBC-NET")


vdata <- lapply(TLSD, f1_colmean <- function(mat){

  mean_list <- lapply(mat, colMeans)
  mean_matrix <- do.call(rbind, mean_list)

  return(mean_matrix)

})

violin_points_list <- list(
  'TRUE PS' = seq(0.03, 0.87, by = 0.2),
  LOGISTIC = seq(0.05, 0.89, by = 0.2),
  CBPS = seq(0.07, 0.91, by = 0.2),
  NN = seq(0.09, 0.93, by = 0.2),
  'LBC-NET' = seq(0.11, 0.95, by = 0.2)
)

vdata_long <- data.frame()
for (i in names(vdata)) {
  mat <- vdata[[i]]
  mat_long <- as.data.frame(mat) %>%
    pivot_longer(cols = everything(), names_to = "CK", values_to = "LSD") %>%
    mutate(Method = i,
           CK = rep(sprintf("%.2f", seq(0.01, 0.99, by = 0.01)), 20)) %>%
    filter(CK %in% violin_points_list[[i]])

  vdata_long <- rbind(vdata_long, mat_long)

}

vdata <- vdata_long
p1 <- LSD_balance_plot(TLSD)

ggsave("m2_true_lsd_figure.pdf", plot = LSD_balance_plot(TLSD), width = 10, height = 8, device = "pdf", family = "Times")



gsd_table <- cbind(colMeans(res_mis$true$gsd), colMeans(res_mis$logistic$gsd), colMeans(res_mis$osqp$gsd), colMeans(res_mis$cbipm$gsd), colMeans(res_mis$sbw$gsd), colMeans(res_mis$eb$gsd), colMeans(res_mis$cbps$gsd), colMeans(res_mis$nn$gsd), colMeans(res_mis$lbc_net$gsd))
colnames(gsd_table) <- c("True", "Logistic", "OSQP", "CBIPM", "SBW", "EB", "CBPS", "NN", "LBC-net")
gsd_table <- round(gsd_table, 3)
gsd_table

## LSD
TLSD <- list(res_mis$true$lsd, res_mis$logistic$lsd, res_mis$cbps$lsd, res_mis$nn$lsd, res_mis$lbc_net$lsd)
names(TLSD) <- c("TRUE PS", "LOGISTIC", "CBPS", "NN", "LBC-NET")


vdata <- lapply(TLSD, f1_colmean <- function(mat){
  
  mean_list <- lapply(mat, colMeans)
  mean_matrix <- do.call(rbind, mean_list)
  
  return(mean_matrix)
  
})

violin_points_list <- list(
  'TRUE PS' = seq(0.03, 0.87, by = 0.2),
  LOGISTIC = seq(0.05, 0.89, by = 0.2),
  CBPS = seq(0.07, 0.91, by = 0.2),
  NN = seq(0.09, 0.93, by = 0.2),
  'LBC-NET' = seq(0.11, 0.95, by = 0.2)
)

vdata_long <- data.frame()
for (i in names(vdata)) {
  mat <- vdata[[i]]
  mat_long <- as.data.frame(mat) %>%
    pivot_longer(cols = everything(), names_to = "CK", values_to = "LSD") %>%
    mutate(Method = i,
           CK = rep(sprintf("%.2f", seq(0.01, 0.99, by = 0.01)), 20)) %>%
    filter(CK %in% violin_points_list[[i]])
  
  vdata_long <- rbind(vdata_long, mat_long)
  
}

vdata <- vdata_long
p2 <- LSD_balance_plot(TLSD)

ggsave("m2_mis_lsd_figure.pdf", plot = LSD_balance_plot(TLSD), width = 10, height = 8, device = "pdf", family = "Times")

## 
library(patchwork)

p1 <- p1 + theme(legend.position = "bottom")  # Set legend position
p2 <- p2 + theme(legend.position = "none")   # Remove legend

combined_plot <- p1 + p2 +  plot_layout(ncol = 2, axis_titles = 'collect', guides = "collect") +
  plot_annotation(theme = theme(legend.position = "bottom"))  # Position shared legend
ggsave("m2_lsd_figure.pdf", plot = combined_plot, width = 13, height = 8, device = "pdf", family = "Times")
