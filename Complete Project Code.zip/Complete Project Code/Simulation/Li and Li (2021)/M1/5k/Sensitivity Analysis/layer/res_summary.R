res <- readRDS("layer_res.rds")

layer_table <- data.frame(layers = c("L1", "L2", "L3", "L4"),
                          Bias = c(res$L1$pbias, res$L2$pbias, res$L3$pbias, res$L4$pbias),
                          RMSE = c(res$L1$rmse, res$L2$rmse, res$L3$rmse, res$L4$rmse),
                          Variance = c(res$L1$var, res$L2$var, res$L3$var, res$L4$var))

layer_table <- layer_table %>%
  mutate(Variance = sqrt(Variance)) %>%
  rename(ESD = Variance)

## create tables
library(dplyr)
library(tidyr)
library(textables)

layer_table_new <- layer_table  %>% pivot_longer(
  cols = Bias:ESD, # Columns to pivot
  names_to = "measure", # Name of the new column that will contain the names of the pivoted columns
  values_to = "value" # Name of the new column that will contain the values of the pivoted columns
) %>%
  pivot_wider(
    names_from = layers, # Column to use as column names
    values_from = value # Column to use as values
  ) %>%
  mutate(measure = ifelse(measure=="Bias", "% Bias", measure)) %>%
  mutate(
    across(
      c(2:5), # Columns to format
      ~ ifelse(
        abs(.x) < 0.005, 
        format(.x, scientific = TRUE, digits = 1), # Scientific format for values < 0.005
        sprintf("%.2f", .x) # Two decimal places otherwise
      )
    )
  )


tab <- TR("Number of Hidden Layers") %:% with(layer_table_new, TR(measure)) +
  midrule() +
  TR("L1") %:% with(layer_table_new, TR(L1)) +
  TR("L2") %:% with(layer_table_new, TR(L2)) +
  TR("L3") %:% with(layer_table_new, TR(L3)) +
  TR("L4") %:% with(layer_table_new, TR(L4)) 

# Print the table to a text variable
text_output <- capture.output(print(tab))

# Write the text output to a file
writeLines(text_output, "table_output.txt")

###################################################################
######################## LSD Plot ################################
###################################################################
library(ggplot2)

LSD_balance_plot <- function(ds){
  ## Purpose: Figure 3
  ## Input: 
  ##    ds -- Balance Results
  ## Output:
  ##    Figure 3
  
  # Calculate column means
  f1_colmean <- function(mat){
    mean_list <- lapply(mat, colMeans)
    mean_matrix <- do.call(rbind, mean_list)
    return(colMeans(mean_matrix))
  }
  
  ds <- lapply(ds, f1_colmean)
  
  # Combine into a new data frame
  ds_new <- do.call(rbind, lapply(1:length(ds), function(i){
    data.frame(CK = 1:length(ds[[i]]),
               Mean = ds[[i]],
               Method = names(ds)[i])
  }))
  
  # Generate numeric labels for CK
  numeric_labels <- rep(sprintf("%.2f", seq(0.01, 0.99, by = 0.01)), length(ds))
  ds_new$CK <- numeric_labels
  
  # Define line types, shapes, and colors for each method
  # line_types <- c("L1" = "twodash", "L2" = "dotdash", "L3" = "dashed", "L4" = "dotted")
  # point_shapes <- c("L1" = 18, "L2" = 15, "L3" = 17, "L4" = 16)
  custom_colors <- c(
    "L1" = "#ff7f0e",   # Orange
    "L2" = "#d62728",  # Red
    "L3" = "#2ca02c",      # Green
    "L4" = "#17becf"
  )
  
  # Plot with both points and boxplots having the same shape for consistency
  pt <- ggplot(ds_new, aes(x = CK, y = Mean, color = Method)) +
    geom_line(size = 1) +  # Increased line width
    geom_point(size = 0.9) +  # Smaller point size for the line plot
    scale_x_discrete(breaks = c(0.01, 0.11, 0.21, 0.31, 0.41, 0.51, 0.61, 0.71, 0.81, 0.91, 0.99), labels = c(0.01, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.99)) +
    theme_bw(base_size = 20) + 
    theme(legend.position = "bottom",
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          axis.title = element_text(size = 20),
          axis.text = element_text(size = 20),
          legend.text = element_text(size = 20),
          legend.title = element_text(size = 20)) +
    labs(x = "Propensity Score", y = "LSD(%)") +
    # scale_linetype_manual(values = line_types) +
    # scale_shape_manual(values = point_shapes) +
    scale_color_manual(values = custom_colors) +
    guides(
      shape = guide_legend(override.aes = list(size = 1.7))  # Custom size for the legend points
    )
  
  # Add boxplots for each method, sharing the same shapes and fill
  for (i in unique(ds_new$Method)){
    ds_sub <- subset(vdata, Method == i)
    pt <- pt + geom_boxplot(data = ds_sub, 
                            aes(x = CK, y = LSD, shape = Method, color = Method), outlier.shape = 4, outlier.size = 1,
                            width = 0.5, 
                            position = position_dodge(width = 0.5)) +
      geom_point(data = ds_sub, aes(x = CK, y = LSD, shape = Method), size = 0, position = position_dodge(width = 0.5)) +
      stat_boxplot(data = ds_sub,
                   aes(x = CK, y = LSD, color = Method, group = interaction(CK, Method)),
                   geom = "errorbar",
                   width = 1.5,
                   position = position_dodge(width = 0.5))
  }
  
  # Restrain y-axis to (0, 35)
  pt <- pt + scale_y_continuous(limits = c(0, 2))
  
  return(pt)
}

## LSD
TLSD <- list(res$L1$lsd, res$L2$lsd, res$L3$lsd, res$L4$lsd)
names(TLSD) <- c("L1", "L2", "L3", "L4")


vdata <- lapply(TLSD, f1_colmean <- function(mat){
  
  mean_list <- lapply(mat, colMeans)
  mean_matrix <- do.call(rbind, mean_list)
  
  return(mean_matrix)
  
})

violin_points_list <- list(
  L1 = seq(0.03, 0.87, by = 0.2),
  L2 = seq(0.05, 0.89, by = 0.2),
  L3 = seq(0.07, 0.91, by = 0.2),
  L4 = seq(0.09, 0.93, by = 0.2)
)

vdata_long <- data.frame()
for (i in names(vdata)) {
  mat <- vdata[[i]]
  mat_long <- as.data.frame(mat) %>%
    pivot_longer(cols = everything(), names_to = "CK", values_to = "LSD") %>%
    mutate(Method = i,
           CK = rep(sprintf("%.2f", seq(0.01, 0.99, by = 0.01)), 20)) %>%
    filter(CK %in% violin_points_list[[i]])
  
  vdata_long <- rbind(vdata_long, mat_long)
  
}

vdata <- vdata_long

ggsave("m1_tune_layer_figure.pdf", plot = LSD_balance_plot(TLSD), width = 10, height = 8, device = "pdf", family = "Times")

