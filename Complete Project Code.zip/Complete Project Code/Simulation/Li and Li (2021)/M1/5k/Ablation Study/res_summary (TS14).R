## This file contains code generating Table S14.

res_t <- readRDS("ablation.rds")
res_m <- readRDS("ablation_mis.rds")

lbc_net_no_vae <- res_t[[1]]
lbc_net_bal_only <- res_t[[2]]
lbc_net_bce <- res_t[[3]]
lbc_net <- res_t[[4]]

lbc_net_no_vae_m <- res_m[[1]]
lbc_net_bal_only_m <- res_m[[2]]
lbc_net_bce_m <- res_m[[3]]
lbc_net_m <- res_m[[4]]

ATE_table_true <- data.frame(methods = c("Standard", "No_VAE", "Balance_Only", "BCE_Only"),
                           Bias = c(lbc_net$pbias, lbc_net_no_vae$pbias, lbc_net_bal_only$pbias, lbc_net_bce$pbias),
                           RMSE = c(lbc_net$rmse, lbc_net_no_vae$rmse, lbc_net_bal_only$rmse, lbc_net_bce$rmse),
                           Var = c(lbc_net$var, lbc_net_no_vae$var, lbc_net_bal_only$var, lbc_net_bce$var),
                           LSD = c(mean(sapply(lapply(lbc_net$lsd, function(x) mean(x)), identity)), 
                                   mean(sapply(lapply(lbc_net_no_vae$lsd, function(x) mean(x)), identity)), 
                                   mean(sapply(lapply(lbc_net_bal_only$lsd, function(x) mean(x)), identity)), 
                                   mean(sapply(lapply(lbc_net_bce$lsd, function(x) mean(x)), identity))),
                           GSD = c(mean(sapply(lapply(lbc_net$gsd, function(x) mean(x)), identity)), 
                                   mean(sapply(lapply(lbc_net_no_vae$gsd, function(x) mean(x)), identity)), 
                                   mean(sapply(lapply(lbc_net_bal_only$gsd, function(x) mean(x)), identity)), 
                                   mean(sapply(lapply(lbc_net_bce$gsd, function(x) mean(x)), identity))),
                           model = rep("Standard", 4))

ATE_table_mis <- data.frame(methods = c("Standard", "No_VAE", "Balance_Only", "BCE_Only"),
                          Bias = c(lbc_net_m$pbias, lbc_net_no_vae_m$pbias, lbc_net_bal_only_m$pbias, lbc_net_bce_m$pbias),
                          RMSE = c(lbc_net_m$rmse, lbc_net_no_vae_m$rmse, lbc_net_bal_only_m$rmse, lbc_net_bce_m$rmse),
                          Var = c(lbc_net_m$var, lbc_net_no_vae_m$var, lbc_net_bal_only_m$var, lbc_net_bce_m$var),
                          LSD = c(mean(sapply(lapply(lbc_net_m$lsd, function(x) mean(x)), identity)), 
                                  mean(sapply(lapply(lbc_net_no_vae_m$lsd, function(x) mean(x)), identity)), 
                                  mean(sapply(lapply(lbc_net_bal_only_m$lsd, function(x) mean(x)), identity)), 
                                  mean(sapply(lapply(lbc_net_bce_m$lsd, function(x) mean(x)), identity))),
                          GSD = c(mean(sapply(lapply(lbc_net_m$gsd, function(x) mean(x)), identity)), 
                                  mean(sapply(lapply(lbc_net_no_vae_m$gsd, function(x) mean(x)), identity)), 
                                  mean(sapply(lapply(lbc_net_bal_only_m$gsd, function(x) mean(x)), identity)), 
                                  mean(sapply(lapply(lbc_net_bce_m$gsd, function(x) mean(x)), identity))),
                          model = rep("Extended", 4))


## create tables
library(dplyr)
library(tidyr)
library(textables)

ATE_table <- rbind(ATE_table_true, ATE_table_mis) 

ATE_table <- ATE_table %>%
  mutate(Var = sqrt(Var)) %>%
  rename(ESD = Var)

ATE_table_new <- ATE_table %>% pivot_longer(
  cols = Bias:GSD, # Columns to pivot
  names_to = "measure", # Name of the new column that will contain the names of the pivoted columns
  values_to = "value" # Name of the new column that will contain the values of the pivoted columns
) %>%
  pivot_wider(
    names_from = c(methods, model), # Columns to use as column names
    values_from = value, # Column to use as values
    names_sep = "_" # Separator for the new column names
  ) %>%
  mutate(measure = ifelse(measure=="Bias", "% Bias", measure)) %>%
  mutate(
    across(
      c(2:9), # Columns to format
      ~ ifelse(
        abs(.x) < 0.005, 
        format(.x, scientific = TRUE, digits = 1), # Scientific format for values < 0.005
        sprintf("%.2f", .x) # Two decimal places otherwise
      )
    )
  )


tab <- TR("DGP") %:% TR("Ablation Study") %:% with(ATE_table_new, TR(measure)) +
  midrule() +
  TR("") %:% TR("Standard LBC-Net") %:% with(ATE_table_new, TR(Standard_Standard)) +
  TR("") %:% TR("Without VAE Initialization") %:% with(ATE_table_new, TR(No_VAE_Standard)) +
  TR("Standard") %:% TR("Balance Loss Only") %:% with(ATE_table_new, TR(Balance_Only_Standard)) +
  TR("") %:% TR("BCE Loss Only") %:% with(ATE_table_new, TR(BCE_Only_Standard)) +
  midrule() +
  TR("") %:% TR("Standard LBC-Net") %:% with(ATE_table_new, TR(Standard_Extended)) +
  TR("") %:% TR("Without VAE Initialization") %:% with(ATE_table_new, TR(No_VAE_Extended)) +
  TR("Extended") %:% TR("Balance Loss Only") %:% with(ATE_table_new, TR(Balance_Only_Extended)) +
  TR("") %:% TR("BCE Loss Only") %:% with(ATE_table_new, TR(BCE_Only_Extended)) 

# Print the table to a text variable
text_output <- capture.output(print(tab))

# Write the text output to a file
writeLines(text_output, "table_output.txt")



