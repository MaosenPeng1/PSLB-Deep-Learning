PS_simulation_new <- function(n, p1, K, beta, alpha, delta, Homo, delta_function, seeds) {
  ## Purpose: SSMR Data Simulation
  ## Input: 
  ##    n -- sample size
  ##    p1 -- probability of binary covariates
  ##    K -- number of covariates - 4
  ##    beta -- propensity score model coefficients
  ##    alpha -- outcome model coefficients
  ##    delta -- treatment effect
  ##    seeds -- seed 
  ## Output:
  ##    a list of data and true propensity score
  require(MASS)
  set.seed(seeds)
  X0 <- rep(1, n)
  X4 <- rbinom(n, size = 1, prob = p1)
  X4_p <- 0.6*X4 + 0.4*(1-X4)
  X3 <- c()
  for (i in 1:length(X4_p)) {
    X3[i] <- rbinom(1, size = 1, prob = X4_p[i])
  }
  mean_X1 <- -X3 + X4 + 0.5*X3*X4
  mean_X2 <- X3 - X4 + X3*X4
  M1 <- matrix(c(1,0.5,0.5,1), nrow = 2, ncol = 2)
  M2 <- matrix(c(2,0.25,0.25,2), nrow = 2, ncol = 2)
  X1_X2 <- matrix(nrow = n, ncol = 2, byrow = T)
  for (i in 1:n) {
    X1_X2[i,] <- mvrnorm(1, mu = c(mean_X1[i], mean_X2[i]), Sigma = X3[i]*M1 + (1-X3[i])*M2)
  }
  if(K == 0) {
    X_1to4 <- cbind(X1_X2, X3, X4)
    Data_X <- cbind(X0, X_1to4, X_1to4[,1]*X_1to4[,2], 
                   X_1to4[,1]*X_1to4[,3], X_1to4[,1]*X_1to4[,4],
                   X_1to4[,2]*X_1to4[,3], X_1to4[,2]*X_1to4[,4],
                   X_1to4[,3]*X_1to4[,4], X_1to4^2, log(abs(X_1to4[,1:2])))
  } else if (K != 0) {
    X_normal <- matrix(nrow = n, ncol = round(K/2), byrow = T)
    for(i in 1:n) {
      X_normal[i,] <- mvrnorm(1, mu = rep(0, round(K/2)), 
                             Sigma = diag(x = 1.6, round(K/2))+matrix(rep(0.4,round(K/2)*round(K/2)), round(K/2)))
    }
    X_binary <- matrix(nrow = n, ncol = round(K/2), byrow = T)
    for (i in 1:round(K/2)) {
      X_binary[,i] <- rbinom(n, size = 1, prob = p1)
    }
    X_1to4 <- cbind(X1_X2, X3, X4)
    Data_X <- cbind(X0, X_1to4, X_1to4[,1]*X_1to4[,2], 
                   X_1to4[,1]*X_1to4[,3], X_1to4[,1]*X_1to4[,4],
                   X_1to4[,2]*X_1to4[,3], X_1to4[,2]*X_1to4[,4],
                   X_1to4[,3]*X_1to4[,4], X_1to4^2, log(abs(X_1to4[,1:2])), X_normal, X_binary)
  }
  e_0 <- exp(Data_X%*%beta)
  PS <- c()
  for (i in 1:n) {
    PS[i] <- (e_0[i])/(1+e_0[i])
  }
  Z <- c()
  for (i in 1:n) {
    Z[i] <- rbinom(1, size = 1, prob = PS[i])
  }
  epsilon <- rnorm(n)
  if ( Homo == 0) {
    delta <- rep(1*delta, n)
  } else if (Homo == 1) {
    delta <- delta_function(PS)
  } 
  Y <- delta*Z + Data_X%*%alpha + epsilon
  Data_final <- cbind(Y, Z, Data_X)
  if (K==0) {
    colnames(Data_final) <- c("Y", "Z", "X0", "X1", "X2","X3","X4", 
                             "X1*X2", "X1*X3", "X1*X4", "X2*X3", 
                             "X2*X4", "X3*X4", "X1^2", "X2^2", "X3^2",
                             "X4^2","logX1","logX2")
  } else if (K!=0) {
    colnames(Data_final) <- c("Y", "Z", "X0", "X1", "X2","X3","X4", 
                             "X1*X2", "X1*X3", "X1*X4", "X2*X3", 
                             "X2*X4", "X3*X4", "X1^2", "X2^2", "X3^2",
                             "X4^2", "logX1","logX2", paste0("Norm", seq(1, round(K/2))),
                             paste0("Bin", seq(1, round(K/2))))
  }
  return(list(Data=Data_final, propensity_score = PS))
}

# Het 1
Hetero_f1 <-  function(e) {
  D <- e^2 + 2*e + 1
  return(D)
}
# Het 2
Hetero_f2 <- function(e) {
  D <- 10*(e-0.5)^2 + 0.5
  return(D)
}

## propensity score model coefficient
source("functions.R")
K <- 16
n <- 5000
## M1: Good overlap
bg <- c(-1.5,0.5,-0.75,2,-0.5, rep(0,12)) # standard model
bg_mis <- c(-1.5,0.5,-0.75,2,-0.5, 0.15, rep(0,5), 0.2, 0.2,rep(0,4)) # extended model: X1*X2 + X1^2 + X2^2
bgK <- rep(c(rep(-0.3,K/8),rep(0.5,K/8),rep(0,K/4)),2)
beta <- matrix(c(bg, bgK), ncol = 1)
beta_mis <- matrix(c(bg_mis, bgK), ncol = 1)

## outcome model coefficient
a <- c(0.5,1,0.6,2.2,-1.2, rep(0,12))
alphaK <- rep(c(rep(1,K/8),rep(0,K/8),rep(-1,K/8),rep(0,K/8)),2)
alpha <- matrix(c(a, alphaK), ncol = 1)

## mirror histogram
library(dplyr)
library(ggplot2)
DM <- PS_simulation_new(n = 100000, 0.5, K = K, beta = beta,
                        alpha = alpha, delta = 1, Homo = 0, delta_function = NA, seeds = 1)
ds <- DM$Data[,c(1,2,4:7, 20:35)]
N <- c("Y", "Tr", paste0("X",seq(1,20)))
colnames(ds) <- N
p <- mirror_plot(DM$propensity_score, ds[,2])
ggsave("m1_true_mh_figure.pdf", plot = p, width = 10, height = 8, device = "pdf", family = "Times")

## simulation
seed_values <- 1:500
rho <- 0.15
ck <- seq(0.01, 0.99, 0.01)
ps_true <- matrix(NA, ncol = length(seed_values), nrow = n)

for (i in seq_along(seed_values)){
  
  seed <- seed_values[i]
  DM <- PS_simulation_new(n = n, 0.5, K = K, beta = beta, 
                          alpha = alpha, delta = 1, Homo = 0, delta_function = NA, seeds = i)
  ds <- DM$Data[,c(1,2,4:7, 20:35)]
  N = c("Y", "Tr", paste0("X",seq(1,20)))
  colnames(ds) = N
  ps_true[,i] <- DM$propensity_score
  
  ## data simulation
  X <- ds[,3:22]
  treatment <- ds[,2]
  log.fit <- glm(treatment~X, family = binomial) 
  ps <- log.fit$fitted.values
  write.csv(ds, paste0("data", seed, ".csv"), row.names = FALSE)
  
  ## ck and adaptive h
  h <- span_to_bandwidth(rho, ck, ps)
  input <- data.frame(ck=ck, h=h)
  write.csv(input, paste0("ck_h", seed, ".csv"), row.names = FALSE)
  
}

## write true propensity scores
saveRDS(ps_true, "ps_true_matrix.rds")

