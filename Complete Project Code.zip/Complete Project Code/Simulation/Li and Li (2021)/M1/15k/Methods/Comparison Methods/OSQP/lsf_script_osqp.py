import os

def create_lsf_content():
    content = f"""#BSUB -J osqp_job
#BSUB -W 3:00
#BSUB -o /rsrch6/home/biostatistics/mpeng1/log/osqp.out
#BSUB -e /rsrch6/home/biostatistics/mpeng1/log/osqp.err
#BSUB -cwd /rsrch6/home/biostatistics/mpeng1/PSLB/python/smmr/m1/mis15k
#BSUB -q e80short
#BSUB -u mpeng1@mdanderson.org
#BSUB -n 10
#BSUB -M 40
#BSUB -R rusage[mem=40]

module load R 

Rscript /rsrch6/home/biostatistics/mpeng1/PSLB/python/smmr/m1/mis15k/osqp.R 
"""
    return content

output_dir = '/rsrch6/home/biostatistics/mpeng1/PSLB/python/smmr/m1/mis15k'

lsf_content = create_lsf_content()
with open(os.path.join(output_dir, f'osqp.lsf'), 'w') as lsf_file:
    lsf_file.write(lsf_content)

