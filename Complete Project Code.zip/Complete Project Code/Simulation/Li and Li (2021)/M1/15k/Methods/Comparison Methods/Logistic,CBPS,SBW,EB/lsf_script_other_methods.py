import os

def create_lsf_content():
    content = f"""#BSUB -J other_methods_job
#BSUB -W 24:00
#BSUB -o /rsrch6/home/biostatistics/mpeng1/log/other_methods.out
#BSUB -e /rsrch6/home/biostatistics/mpeng1/log/other_methods.err
#BSUB -cwd /rsrch6/home/biostatistics/mpeng1/PSLB/python/smmr/m1/true15k
#BSUB -q e80medium
#BSUB -u mpeng1@mdanderson.org
#BSUB -n 40
#BSUB -M 800
#BSUB -R rusage[mem=800]

module load R 

Rscript /rsrch6/home/biostatistics/mpeng1/PSLB/python/smmr/m1/mis15k/other_methods.R 
"""
    return content

output_dir = '/rsrch6/home/biostatistics/mpeng1/PSLB/python/smmr/m1/mis15k'

lsf_content = create_lsf_content()
with open(os.path.join(output_dir, f'other_methods.lsf'), 'w') as lsf_file:
    lsf_file.write(lsf_content)

