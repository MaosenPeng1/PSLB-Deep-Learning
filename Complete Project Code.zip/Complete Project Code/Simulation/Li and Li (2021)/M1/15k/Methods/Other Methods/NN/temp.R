library(ggplot2)
library(dplyr)

ds <- read.csv("data1.csv")
ps <- read.csv("ps_nn1.csv", header = FALSE)
osqp <- readRDS("osqp_res.rds")
osqp$rmse
mirror_plot(ps[,1],ds$Tr)