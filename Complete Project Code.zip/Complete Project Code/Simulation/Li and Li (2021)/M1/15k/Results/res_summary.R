# ----------------------------------------------------- 
# M1 true
# -----------------------------------------------------

res <- readRDS("m1_true.rds")
source("functions.R")

library(dplyr)
library(tidyr)
library(textables)
library(ggplot2)

ate_table_true <- data.frame(methods = c("True", "Logistic", "OSQP", "CBIPM", "SBW", "EB", "CBPS", "NN", "LBC-net"),
                             Bias = c(res$true$pbias, res$logistic$pbias, res$osqp$pbias, res$cbipm$pbias, res$sbw$pbias, res$eb$pbias, res$cbps$pbias, res$nn$pbias, res$lbc_net$pbias),
                             RMSE = c(res$true$rmse, res$logistic$rmse, res$osqp$rmse, res$cbipm$rmse, res$sbw$rmse, res$eb$rmse, res$cbps$rmse, res$nn$rmse, res$lbc_net$rmse),
                             Variance = c(res$true$var, res$logistic$var, res$osqp$var, res$cbipm$var, res$sbw$var, res$eb$var, res$cbps$var, res$nn$var, res$lbc_net$var),
                             model = rep("Standard DGP", 9))
ate_table_true


gsd_table <- cbind(colMeans(res$true$gsd), colMeans(res$logistic$gsd), colMeans(res$osqp$gsd), colMeans(res$cbipm$gsd), colMeans(res$sbw$gsd), colMeans(res$eb$gsd), colMeans(res$cbps$gsd), colMeans(res$nn$gsd), colMeans(res$lbc_net$gsd))
colnames(gsd_table) <- c("True", "Logistic", "OSQP", "CBIPM", "SBW", "EB", "CBPS", "NN", "LBC-net")
gsd_table <- round(gsd_table, 3)
gsd_table

## LSD
TLSD <- list(res$true$lsd, res$logistic$lsd, res$cbps$lsd, res$nn$lsd, res$lbc_net$lsd)
names(TLSD) <- c("TRUE PS", "LOGISTIC", "CBPS", "NN", "LBC-NET")

vdata <- lapply(TLSD, f1_colmean <- function(mat){

  mean_list <- lapply(mat, colMeans)
  mean_matrix <- do.call(rbind, mean_list)

  return(mean_matrix)

})

violin_points_list <- list(
  'TRUE PS' = seq(0.03, 0.87, by = 0.2),
  LOGISTIC = seq(0.05, 0.89, by = 0.2),
  CBPS = seq(0.07, 0.91, by = 0.2),
  NN = seq(0.09, 0.93, by = 0.2),
  'LBC-NET' = seq(0.11, 0.95, by = 0.2)
)

vdata_long <- data.frame()
for (i in names(vdata)) {
  mat <- vdata[[i]]
  mat_long <- as.data.frame(mat) %>%
    pivot_longer(cols = everything(), names_to = "CK", values_to = "LSD") %>%
    mutate(Method = i,
           CK = rep(sprintf("%.2f", seq(0.01, 0.99, by = 0.01)), 20)) %>%
    filter(CK %in% violin_points_list[[i]])

  vdata_long <- rbind(vdata_long, mat_long)

}

vdata_long <- rbind(vdata_long, mat_long)

vdata <- vdata_long

p1 <- LSD_balance_plot(TLSD)

ggsave("m1_15k_true_lsd_figure.pdf", plot = LSD_balance_plot(TLSD), width = 10, height = 8, device = "pdf", family = "Times")

# ----------------------------------------------------- 
# M1 mis
# -----------------------------------------------------

res <- readRDS("m1_mis.rds")
source("functions.R")
library(dplyr)
library(tidyr)
library(textables)
library(ggplot2)

ate_table_mis <- data.frame(methods = c("True", "Logistic", "OSQP", "CBIPM", "SBW", "EB", "CBPS", "NN", "LBC-net"),
                             Bias = c(res$true$pbias, res$logistic$pbias, res$osqp$pbias, res$cbipm$pbias, res$sbw$pbias, res$eb$pbias, res$cbps$pbias, res$nn$pbias, res$lbc_net$pbias),
                             RMSE = c(res$true$rmse, res$logistic$rmse, res$osqp$rmse, res$cbipm$rmse, res$sbw$rmse, res$eb$rmse, res$cbps$rmse, res$nn$rmse, res$lbc_net$rmse),
                            Variance = c(res$true$var, res$logistic$var, res$osqp$var, res$cbipm$var, res$sbw$var, res$eb$var, res$cbps$var, res$nn$var, res$lbc_net$var),
                             model = rep("Extended DGP", 9))
ate_table_mis


gsd_table <- cbind(colMeans(res$true$gsd), colMeans(res$logistic$gsd), colMeans(res$osqp$gsd), colMeans(res$cbipm$gsd), colMeans(res$sbw$gsd), colMeans(res$eb$gsd), colMeans(res$cbps$gsd), colMeans(res$nn$gsd), colMeans(res$lbc_net$gsd))
colnames(gsd_table) <- c("True", "Logistic", "OSQP", "CBIPM", "SBW", "EB", "CBPS", "NN", "LBC-net")
gsd_table <- round(gsd_table, 3)
gsd_table

## LSD
TLSD <- list(res$true$lsd, res$logistic$lsd, res$cbps$lsd, res$nn$lsd, res$lbc_net$lsd)
names(TLSD) <- c("TRUE PS", "LOGISTIC", "CBPS", "NN", "LBC-NET")


vdata <- lapply(TLSD, f1_colmean <- function(mat){
  
  mean_list <- lapply(mat, colMeans)
  mean_matrix <- do.call(rbind, mean_list)
  
  return(mean_matrix)
  
})

violin_points_list <- list(
  'TRUE PS' = seq(0.03, 0.87, by = 0.2),
  LOGISTIC = seq(0.05, 0.89, by = 0.2),
  CBPS = seq(0.07, 0.91, by = 0.2),
  NN = seq(0.09, 0.93, by = 0.2),
  'LBC-NET' = seq(0.11, 0.95, by = 0.2)
)

vdata_long <- data.frame()
for (i in names(vdata)) {
  mat <- vdata[[i]]
  mat_long <- as.data.frame(mat) %>%
    pivot_longer(cols = everything(), names_to = "CK", values_to = "LSD") %>%
    mutate(Method = i,
           CK = rep(sprintf("%.2f", seq(0.01, 0.99, by = 0.01)), 20)) %>%
    filter(CK %in% violin_points_list[[i]])
  
  vdata_long <- rbind(vdata_long, mat_long)
  
}

vdata <- vdata_long

p2 <- LSD_balance_plot(TLSD)

ggsave("m1_mis_lsd_figure.pdf", plot = LSD_balance_plot(TLSD), width = 10, height = 8, device = "pdf", family = "Times")

# ----------------------------------------------------- 
# M1 Figures and Table
# -----------------------------------------------------

library(dplyr)
library(tidyr)

ate_table <- rbind(ate_table_true, ate_table_mis) 
ate_table_new <- ate_table %>% pivot_longer(
  cols = Bias:Variance, # Columns to pivot
  names_to = "measure", # Name of the new column that will contain the names of the pivoted columns
  values_to = "value" # Name of the new column that will contain the values of the pivoted columns
) %>%
  pivot_wider(
    names_from = methods, # Column to use as column names
    values_from = value # Column to use as values
  ) %>%
  mutate(measure = ifelse(measure=="Bias", "% Bias", measure)) %>%
  mutate(
    across(
      c(3:11), # Columns to format
      ~ ifelse(
        abs(.x) < 0.005, 
        format(.x, scientific = TRUE, digits = 1), # Scientific format for values < 0.005
        sprintf("%.2f", .x) # Two decimal places otherwise
      )
    )
  )


tab <- TR(c("","Standard DGP","Extended DGP"),cspan=c(1,3,3)) +
  midrulep(list(c(2,4),c(5,7))) +
  TR("Methods") %:% with(ate_table_new, TR(measure)) +
  midrule() +
  TR("True ps") %:% with(ate_table_new, TR(True)) +
  TR("Logistic") %:% with(ate_table_new, TR(Logistic)) +
  TR("OSQP") %:% with(ate_table_new, TR(OSQP)) +
  TR("CBIPM ") %:% with(ate_table_new, TR(CBIPM)) +
  TR("SBW") %:% with(ate_table_new, TR(SBW)) +
  TR("EB") %:% with(ate_table_new, TR(EB)) +
  TR("CBPS") %:% with(ate_table_new, TR(CBPS)) +
  TR("NN") %:% with(ate_table_new, TR(NN)) +
  TR("LBC-Net") %:% with(ate_table_new, TR(`LBC-net`)) 

# Print the table to a text variable
text_output <- capture.output(print(tab))

# Write the text output to a file
writeLines(text_output, "table_output.txt")


## 
library(patchwork)

p1 <- p1 + theme(legend.position = "bottom")  # Set legend position
p2 <- p2 + theme(legend.position = "none")   # Remove legend

combined_plot <- p1 + p2 +  plot_layout(ncol = 2, axis_titles = 'collect', guides = "collect") +
  plot_annotation(theme = theme(legend.position = "bottom"))  # Position shared legend
ggsave("m1_15k_lsd_figure.pdf", plot = combined_plot, width = 12, height = 8, device = "pdf", family = "Times")