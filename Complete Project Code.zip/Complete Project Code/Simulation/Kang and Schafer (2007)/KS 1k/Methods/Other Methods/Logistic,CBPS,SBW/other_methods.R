library(CBPS)
library(ebal)
library(sbw)
library(dplyr)
library(foreach)
library(doParallel)
source("functions.R")

s <- 1:500
set.seed(100)
file <- paste0("data", s, ".csv")
data_list <- lapply(file, read.csv, header = TRUE)
file_ck <- paste0("ck_h", s, ".csv")
ck_list <- lapply(file_ck, read.csv, header = TRUE)
p <- 4
n <- length(s)
Y_true <- 210
registerDoParallel(cores = detectCores())

###################################
## Logistic regression
###################################
logistic_model <- function(data){
  
  logistic.fit <- glm(Tr~.-Y, data = data, family = 'binomial')
  return(logistic.fit$fitted.values)
  
}

ps_log <- foreach(data = data_list, .combine = cbind) %dopar% {
  
  logistic_model(data)
  
}

logistic_res <- Model_based_estimates_sim(ps_log, Y_true)

#####################################
## CBPS
#####################################
CBPS_model <- function(data){

  cbps.fit <- CBPS(Tr~.-Y, data = data, method = 'exact', ATT = 0, twostep = FALSE)
  return(cbps.fit$fitted.values)

}

# Run the CBPS models in parallel
ps_cbps <- foreach(data = data_list, .combine = cbind) %dopar% {

  CBPS_model(data)

}

cbps_res <- Model_based_estimates_sim(ps_cbps, Y_true)

#####################################
## SBW
#####################################
sbw_model <- function(data){

  bal <- list()
  bal$bal_cov <- colnames(data[,3:6])
  bal$bal_tol <- 0.02
  bal$bal_std <- "group"

  sbw.fit <- sbw(data,
                 ind = "Tr",
                 out = "Y",
                 bal = bal,
                 sol = list(sol_nam = "quadprog"),
                 par = list(par_est = "ate"),
                 mes = FALSE)
  return(sbw.fit$dat_weights$sbw_weights)

}

wt_sbw <- foreach(data = data_list, .combine = cbind, .packages = c('dplyr', 'sbw')) %dopar% {

  sbw_model(data)

}

sbw_res <- Weight_based_estimates_sim(wt_sbw, Y_true)

# Y_hat <- rep(NA, n)
# gsd <- matrix(NA, nrow = n, ncol = p)
# 
# for (i in 1:n){
# 
#   ds <- data_list[[i]]
#   X <- ds[, 3:6]
#   Z <- ds[, 2]
#   Y <- ds[, 1]
# 
#   Y_hat[i] <- sum(wt_sbw[,i] * Y) / sum(wt_sbw[,i])
# 
#   ## GSD estimation
#   GSD_res <- apply(X, 2, function(x) GSD_sbw(x, wt_sbw[,i]))
#   gsd[i,] <- unlist(lapply(GSD_res, function(x) abs(x)))
# 
# }
# 
# out_measures <- Col_bias_variance_rmse(Y_hat, Y_true)
# 
# ## Result summary
# sbw_res <- list(
#   pbias = out_measures$pbias,
#   rmse = out_measures$rmse,
#   var = out_measures$var,
#   gsd = gsd
# )
# 
res <- list(logistic = logistic_res,
            cbps = cbps_res,
            sbw = sbw_res)

saveRDS(res, "other_methods_res.rds")













