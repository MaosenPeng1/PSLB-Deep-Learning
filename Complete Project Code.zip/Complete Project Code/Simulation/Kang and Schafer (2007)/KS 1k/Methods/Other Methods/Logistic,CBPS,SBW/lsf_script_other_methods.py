import os

def create_lsf_content():
    content = f"""#BSUB -J other_methods_job
#BSUB -W 3:00
#BSUB -o /path/to/log/other_methods.out
#BSUB -e /path/to/log/other_methods.err
#BSUB -cwd /path/to/working_directory
#BSUB -q e80short
#BSUB -u your_email@example.com
#BSUB -n 40
#BSUB -M 600
#BSUB -R rusage[mem=600]

module load R 

Rscript /path/to/working_directory/other_methods.R 
"""
    return content

output_dir = '/path/to/working_directory'

lsf_content = create_lsf_content()
with open(os.path.join(output_dir, f'other_methods.lsf'), 'w') as lsf_file:
    lsf_file.write(lsf_content)

