Kang_Schafer_Simulation = function(n, beta = c(-1,0.5,-0.25,-0.1), 
                                   alpha = c(210,27.4,13.7,13.7,13.7),
                                   mu = rep(0,4), sd = diag(4), seeds){
  ## Purpose: data generation from KS simulation
  ## Input: 
  ##    n -- The number of observations to simulate.
  ##    beta -- A vector of coefficients for the propensity score model. Defaults to c(-1,0.5,-0.25,-0.1).
  ##    alpha -- A vector of coefficients for the outcome model. Defaults to c(210,27.4,13.7,13.7,13.7).
  ##    mu -- The mean vector for the multivariate normal distribution used to generate covariates. Defaults to a zero vector of length 4.
  ##    sd -- The covariance matrix for the multivariate normal distribution. Defaults to a 4x4 identity matrix.
  ##    seeds -- The seed value for random number generation to ensure reproducibility.
  ## Output:
  ##    a list of data and treatent effects
  require(MASS)
  set.seed(seeds)
  beta = matrix(beta, ncol = 1)
  alpha = matrix(alpha, ncol = 1)
  Z = mvrnorm(n, mu = mu, Sigma = sd) ## correctly specified model covariates
  Z1 = cbind(rep(1,n),Z)
  epsilon = rnorm(n, mean = 0, sd = 1)
  Y = Z1%*%alpha + epsilon
  ps = exp(Z%*%beta)/(1+exp(Z%*%beta))
  D = c()
  for(i in 1:n) {
    D[i] = rbinom(1, size = 1, prob = ps[i])
  }
  X1 = exp(Z[,1]/2)
  X2 = Z[,2]/(1+exp(Z[,1])) + 10
  X3 = (((Z[,1]*Z[,3])/25)+0.6)^3
  X4 = (Z[,2] + Z[,4] + 20)^2
  X = cbind(X1, X2, X3, X4) ## mis-specified model covariates
  XI = rnorm(n)
  out = cbind(Y, D, Z, X, ps, XI)
  colnames(out) = c("Y", "Tr", "Z1", "Z2", "Z3", "Z4", "X1", "X2", "X3", "X4","PS","XI")
  treatment = mean(out[which(D==1),1]) - mean(out[which(D==0),1])
  
  return(list(Data = out, Treat.effect = treatment))
  
}

source("functions.R")
seed_values <- 1:500
n <- 5000 ## sample size
model <- "true" ## true DGP
#model <- "mis" ## mis-specified DGP
rho <- 0.15 ## span
ck <- seq(0.01, 0.99, 0.01) ## selected local points
ps_true <- matrix(NA, ncol = length(seed_values), nrow = n)

## generation of data for mis-specified and correctly specified data (true) for each seed
for (i in seq_along(seed_values)){
  
  seed <- seed_values[i]
  DM <- Kang_Schafer_Simulation(n = n, seeds = seed)
  if (model=="true"){
    X <- DM$Data[,3:6]
    colnames(X) = c("X1", "X2", "X3", "X4")
  }else{
    X <- DM$Data[,7:10]
  }
  treatment <- DM$Data[,2]
  Y <- DM$Data[,1]
  ps_true[,i] <- DM$Data[,11]
  
  log.fit = glm(treatment~X, family = binomial) ## true model
  ps = log.fit$fitted.values ## initial propensity score used for adaptive bandwidth selection by default 
  
  data = cbind(Y, "Tr" = treatment, X)
  write.csv(data, paste0("data", seed, ".csv"), row.names = FALSE)
  
  ## ck and adaptive bandwidth h
  h <- span_to_bandwidth(rho, ck, ps)
  input <- data.frame(ck=ck, h=h)
  write.csv(input, paste0("ck_h", seed, ".csv"), row.names = FALSE)
  
}

## write true propensity scores
saveRDS(ps_true, "ps_true_matrix.rds")
