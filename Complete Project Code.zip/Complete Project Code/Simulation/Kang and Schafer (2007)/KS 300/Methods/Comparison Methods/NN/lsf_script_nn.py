import os

def create_lsf_content(seed, queue_name, lr, hidden_dim, epochs):
    content = f"""#BSUB -J nn_job{seed}
#BSUB -W 3:00
#BSUB -o /rsrch6/home/biostatistics/mpeng1/log/nn{seed}.out
#BSUB -e /rsrch6/home/biostatistics/mpeng1/log/nn{seed}.err
#BSUB -cwd /rsrch6/home/biostatistics/mpeng1/PSLB/python/KS300/mis
#BSUB -q {queue_name}
#BSUB -u mpeng1@mdanderson.org
#BSUB -n 1
#BSUB -M 6
#BSUB -R rusage[mem=6]

module load python

python /rsrch6/home/biostatistics/mpeng1/PSLB/python/KS300/mis/nn.py --seed {seed} --epochs {epochs} --lr {lr} --hidden_dim {hidden_dim}

"""
    return content

# Set the arguments for the Python script
output_dir = '/rsrch6/home/biostatistics/mpeng1/PSLB/python/KS300/mis'
epochs = 100
lr = 0.01
hidden_dim = 10
queue_names = ["e40short", "short", "e80short"]   # Specify the queue for job submission (e.g., short, medium, long)
seed_values = range(1, 501) 

for seed in seed_values:
    lsf_content = create_lsf_content(seed, queue_names[seed % 3], lr, hidden_dim, epochs)
    with open(os.path.join(output_dir, f'nn_job{seed}.lsf'), 'w') as lsf_file:
        lsf_file.write(lsf_content)
