res_true <- readRDS("ks300_true.rds")
res_mis <- readRDS("ks300_mis.rds")
source("functions.R")

library(dplyr)
library(tidyr)
library(textables)
library(ggplot2)

###################################################################
######################## ATE Table ################################
###################################################################

Y_table_true <- data.frame(methods = c("True", "Logistic", "CBIPM", "SBW", "CBPS", "NN", "LBC-net"),
                           Bias = c(res_true$true$pbias, res_true$logistic$pbias, res_true$cbipm$pbias, res_true$sbw$pbias, res_true$cbps$pbias, res_true$nn$pbias, res_true$lbc_net$pbias),
                           RMSE = c(res_true$true$rmse, res_true$logistic$rmse, res_true$cbipm$rmse, res_true$sbw$rmse, res_true$cbps$rmse, res_true$nn$rmse, res_true$lbc_net$rmse),
                           Variance = c(res_true$true$var, res_true$logistic$var, res_true$cbipm$var, res_true$sbw$var, res_true$cbps$var, res_true$nn$var, res_true$lbc_net$var),
                           X1 = c(mean(res_true$true$gsd[,1]), mean(res_true$logistic$gsd[,1]), mean(res_true$cbipm$gsd[,1]), mean(res_true$sbw$gsd[,1]), mean(res_true$cbps$gsd[,1]), mean(res_true$nn$gsd[,1]), mean(res_true$lbc_net$gsd[,1])),
                           X2 = c(mean(res_true$true$gsd[,2]), mean(res_true$logistic$gsd[,2]), mean(res_true$cbipm$gsd[,2]), mean(res_true$sbw$gsd[,2]), mean(res_true$cbps$gsd[,2]), mean(res_true$nn$gsd[,2]), mean(res_true$lbc_net$gsd[,2])),
                           X3 = c(mean(res_true$true$gsd[,3]), mean(res_true$logistic$gsd[,3]), mean(res_true$cbipm$gsd[,3]), mean(res_true$sbw$gsd[,3]), mean(res_true$cbps$gsd[,3]), mean(res_true$nn$gsd[,3]), mean(res_true$lbc_net$gsd[,3])),
                           X4 = c(mean(res_true$true$gsd[,4]), mean(res_true$logistic$gsd[,4]), mean(res_true$cbipm$gsd[,4]), mean(res_true$sbw$gsd[,4]), mean(res_true$cbps$gsd[,4]), mean(res_true$nn$gsd[,4]), mean(res_true$lbc_net$gsd[,4])),
                           model = rep("T", 7))
Y_table_true

Y_table_mis <- data.frame(methods = c("True", "Logistic", "CBIPM", "SBW", "CBPS", "NN", "LBC-net"),
                          Bias = c(res_mis$true$pbias, res_mis$logistic$pbias, res_mis$cbipm$pbias, res_mis$sbw$pbias, res_mis$cbps$pbias, res_mis$nn$pbias, res_mis$lbc_net$pbias),
                          RMSE = c(res_mis$true$rmse, res_mis$logistic$rmse, res_mis$cbipm$rmse, res_mis$sbw$rmse, res_mis$cbps$rmse, res_mis$nn$rmse, res_mis$lbc_net$rmse),
                          Variance = c(res_mis$true$var, res_mis$logistic$var, res_mis$cbipm$var, res_mis$sbw$var, res_mis$cbps$var, res_mis$nn$var, res_mis$lbc_net$var),
                          X1 = c(mean(res_mis$true$gsd[,1]), mean(res_mis$logistic$gsd[,1]), mean(res_mis$cbipm$gsd[,1]), mean(res_mis$sbw$gsd[,1]), mean(res_mis$cbps$gsd[,1]), mean(res_mis$nn$gsd[,1]), mean(res_mis$lbc_net$gsd[,1])),
                          X2 = c(mean(res_mis$true$gsd[,2]), mean(res_mis$logistic$gsd[,2]), mean(res_mis$cbipm$gsd[,2]), mean(res_mis$sbw$gsd[,2]), mean(res_mis$cbps$gsd[,2]), mean(res_mis$nn$gsd[,2]), mean(res_mis$lbc_net$gsd[,2])),
                          X3 = c(mean(res_mis$true$gsd[,3]), mean(res_mis$logistic$gsd[,3]), mean(res_mis$cbipm$gsd[,3]), mean(res_mis$sbw$gsd[,3]), mean(res_mis$cbps$gsd[,3]), mean(res_mis$nn$gsd[,3]), mean(res_mis$lbc_net$gsd[,3])),
                          X4 = c(mean(res_mis$true$gsd[,4]), mean(res_mis$logistic$gsd[,4]), mean(res_mis$cbipm$gsd[,4]), mean(res_mis$sbw$gsd[,4]), mean(res_mis$cbps$gsd[,4]), mean(res_mis$nn$gsd[,4]), mean(res_mis$lbc_net$gsd[,4])),
                          model = rep("M", 7))
Y_table_mis

## create tables
library(dplyr)
library(tidyr)
library(textables)

Y_table <- rbind(Y_table_true, Y_table_mis) 

Y_table <- Y_table %>%
  mutate(Variance = sqrt(Variance)) %>%
  rename(ESD = Variance)

Y_table_new <- Y_table %>% pivot_longer(
  cols = Bias:X4, # Columns to pivot
  names_to = "measure", # Name of the new column that will contain the names of the pivoted columns
  values_to = "value" # Name of the new column that will contain the values of the pivoted columns
) %>%
  pivot_wider(
    names_from = c(methods, model), # Columns to use as column names
    values_from = value, # Column to use as values
    names_sep = "_" # Separator for the new column names
  ) %>%
  mutate(measure = ifelse(measure=="Bias", "% Bias", measure)) %>%
  mutate(
    across(
      c(2:15), # Columns to format
      ~ ifelse(
        abs(.x) < 0.005, 
        format(.x, scientific = TRUE, digits = 1), # Scientific format for values < 0.005
        sprintf("%.2f", .x) # Two decimal places otherwise
      )
    )
  )


tab <- TR(c("","","","GSD"),cspan=c(1,1,3,4)) +
  midrulep(list(c(6,9))) +
  TR("DGP") %:% TR("Methods") %:% with(Y_table_new, TR(measure)) +
  midrule() +
  TR("") %:% TR("True PS") %:% with(Y_table_new, TR(True_T)) +
  TR("") %:% TR("Logistic") %:% with(Y_table_new, TR(Logistic_T)) +
  TR("") %:% TR("SBW") %:% with(Y_table_new, TR(SBW_T)) +
  TR("Standard") %:% TR("CBIPM") %:% with(Y_table_new, TR(CBIPM_T)) +
  TR("") %:% TR("CBPS") %:% with(Y_table_new, TR(CBPS_T)) +
  TR("") %:% TR("NN") %:% with(Y_table_new, TR(NN_T)) +
  TR("") %:% TR("LBC-Net") %:% with(Y_table_new, TR(`LBC-net_T`)) +
  
  midrule() +
  
  TR("") %:% TR("True PS") %:% with(Y_table_new, TR(True_M)) +
  TR("") %:% TR("Logistic") %:% with(Y_table_new, TR(Logistic_M)) +
  TR("") %:% TR("SBW") %:% with(Y_table_new, TR(SBW_M)) +
  TR("Extended") %:% TR("CBIPM") %:% with(Y_table_new, TR(CBIPM_M)) +
  TR("") %:% TR("CBPS") %:% with(Y_table_new, TR(CBPS_M)) +
  TR("") %:% TR("NN") %:% with(Y_table_new, TR(NN_M)) +
  TR("") %:% TR("LBC-Net") %:% with(Y_table_new, TR(`LBC-net_M`)) 

# Print the table to a text variable
text_output <- capture.output(print(tab))

# Write the text output to a file
writeLines(text_output, "table_output.txt")


###################################################################
######################## LSD Plot ################################
###################################################################
library(ggplot2)
source("functions.R")

## Standard Model
GSD_list <- list(res_true$true$gsd, res_true$logistic$gsd, res_true$cbps$gsd, res_true$nn$gsd, res_true$lbc_net$gsd)
TLSD <- list(res_true$true$lsd, res_true$logistic$lsd, res_true$cbps$lsd, res_true$nn$lsd, res_true$lbc_net$lsd)
names(TLSD) <- c("TRUE PS", "LOGISTIC", "CBPS", "NN", "LBC-NET")
names(GSD_list) <- c("TRUE PS", "LOGISTIC", "CBPS", "NN", "LBC-NET")

## GSD
gsd <- lapply(GSD_list, function(x) abs(colMeans(x)))
gsd <- stack(gsd)
names(gsd) <- c("GSD", "Method")
gsd$Covariate <- rep(c("Z1", "Z2", "Z3", "Z4"), times = 5)
gsd$CK <- c(rep('0.86', 4), rep('0.88', 4), rep('0.90', 4), rep('0.92', 4), rep('0.94', 4))
gsd$Method <- factor(gsd$Method, levels = c("TRUE PS", "LOGISTIC", "CBPS", "NN", "LBC-NET"))
scaling_factor <- 1 
gsd$ScaledGSD <- gsd$GSD * scaling_factor

ggsave("KS300_standard_dgp_figure.pdf", plot = LSD_plot_true(TLSD), width = 10, height = 8, device = "pdf", family = "Times")

## Adjusted Model
GSD_list <- list(res_mis$true$gsd, res_mis$logistic$gsd, res_mis$cbps$gsd, res_mis$nn$gsd, res_mis$lbc_net$gsd)
TLSD <- list(res_mis$true$lsd, res_mis$logistic$lsd, res_mis$cbps$lsd, res_mis$nn$lsd, res_mis$lbc_net$lsd)
names(TLSD) <- c("TRUE PS", "LOGISTIC", "CBPS", "NN", "LBC-NET")
names(GSD_list) <- c("TRUE PS", "LOGISTIC", "CBPS", "NN", "LBC-NET")

## GSD
gsd <- lapply(GSD_list, function(x) abs(colMeans(x)))
gsd <- stack(gsd)
names(gsd) <- c("GSD", "Method")
gsd$Covariate <- rep(c("X1", "X2", "X3", "X4"), times = 5)
gsd$CK <- c(rep('0.86', 4), rep('0.88', 4), rep('0.90', 4), rep('0.92', 4), rep('0.94', 4))
gsd$Method <- factor(gsd$Method, levels = c("TRUE PS", "LOGISTIC", "CBPS", "NN", "LBC-NET"))
scaling_factor <- 1 
gsd$ScaledGSD <- gsd$GSD * scaling_factor

ggsave("KS300_extended_dgp_figure.pdf", plot = LSD_plot_mis(TLSD), width = 10, height = 8, device = "pdf", family = "Times")
