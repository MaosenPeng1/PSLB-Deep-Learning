## LBC_Net
library(dplyr)
source("functions.R")

## load data
s <- 1:500
file <- paste0("data", s, ".csv")
data_list <- lapply(file, read.csv, header = TRUE)
file_ck <- paste0("ck_h", s, ".csv")
ck_list <- lapply(file_ck, read.csv, header = TRUE)
p <- 4
Y_true <- 210
n <- length(s)

file_ps <- paste0("ps_lbc_net", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_lbc_net <- do.call(cbind, ps_list)

file_ps <- paste0("ps_nn", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_nn <- do.call(cbind, ps_list)

file_wt <- paste0("wt_cbipm", s, ".csv")
wt_list <- lapply(file_wt, read.csv, header = FALSE, skip = 1)
wt_cbipm <- do.call(cbind, wt_list)

ps_true <- readRDS("ps_true_matrix.rds")
other_methods <- readRDS("other_methods_res.rds")

true <- Model_based_estimates_sim(ps_true, Y_true)
lbc_net <- Model_based_estimates_sim(ps_lbc_net, Y_true)
nn <- Model_based_estimates_sim(ps_nn, Y_true)
cbipm <- Weight_based_estimates_sim(wt_cbipm, Y_true)

res <- list(true = true,
              logistic = other_methods$logistic,
                  cbipm = cbipm,
                  sbw = other_methods$sbw,
                  cbps = other_methods$cbps,
                  nn = nn,
                  lbc_net = lbc_net)

saveRDS(res, "ks5k.rds")

