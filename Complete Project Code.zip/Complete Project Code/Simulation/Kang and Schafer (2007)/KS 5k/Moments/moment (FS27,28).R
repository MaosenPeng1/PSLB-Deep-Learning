## This file contains code generating Figures S27, S28

balance_second_moment <- function(ps_list) {
  ## Purpose: Calculate the estimates for model-based methods in simulation settings
  ## Input: 
  ##    ps -- list of propensity score
  ## Output:
  ##    list of estimates
  
  # Initialize variables for GSD and LSD
  L <- matrix(nrow = n, ncol = 99)
  gsd = matrix(NA, nrow = n, ncol = p)
  variable_names <- paste("X", 1:p, sep = "")
  TLSD <- setNames(lapply(variable_names, function(x) L), variable_names)
  
  for (i in 1:n){
    
    ds <- data_list[[i]]
    X <- ds[, 3:6]
    X <- X^2
    Z <- ds[, 2]         
    
    ## GSD estimation
    GSD_res <- apply(X, 2, function(x) GSD(x, Z, ps_list[,i])) 
    gsd[i,] <- unlist(lapply(GSD_res, function(x) abs(x)))
    
    ## LSD estimation
    ck <- ck_list[[i]]$ck
    h <- ck_list[[i]]$h
    LSD_res <- apply(X, 2, function(x) LSD(x, Z, ps_list[,i], ck, h, gaussian_kernel)) 
    for (j in 1:p) {
      
      var_name <- paste("X", j, sep = "")
      TLSD[[var_name]][i, ] <- LSD_res[[var_name]]$LSD
      
    }
    
  }
  
  ## Result summary
  res <- list(
    gsd = gsd,
    lsd = TLSD
  )
  
  return(res)
  
}

library(CBPS)
library(dplyr)
library(foreach)
library(doParallel)

source("functions.R")
registerDoParallel(cores = detectCores())

s <- 1:500
file <- paste0("data", s, ".csv")
data_list <- lapply(file, read.csv, header = TRUE)
file_ck <- paste0("ck_h", s, ".csv")
ck_list <- lapply(file_ck, read.csv, header = TRUE)
p <- 4
n <- length(s)


# ----------------------------------------------------------------------------------------
file_ps <- paste0("ps_lbc_net", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_lbc_net <- do.call(cbind, ps_list)
lbc_net <- balance_second_moment(ps_lbc_net)

# ----------------------------------------------------------------------------------------
CBPS_model <- function(data){
  
  cbps.fit <- CBPS(Tr~.-Y, data = data, method = 'exact', ATT = 0, twostep = FALSE)
  return(cbps.fit$fitted.values)
  
}

# Run the CBPS models in parallel
ps_cbps <- foreach(data = data_list, .combine = cbind) %dopar% {
  
  CBPS_model(data)
  
}

cbps <- balance_second_moment(ps_cbps)

res <- list(cbps = cbps,
            lbc_net = lbc_net)

saveRDS(res, "second_moment_res.rds") ## rename for _true/mis

# -----------------------------------------------------------------------------------------

library(ggplot2)
library(dplyr)
library(tidyr)

res_true <- readRDS("second_moment_res_true.rds")
res_mis <- readRDS("second_moment_res_mis.rds")

#########################################################
################ Figure S27, S28#########################
#########################################################

misLSD_plot_mm_true <- function(ds){
  ## Purpose: Figure 2
  ## Input: 
  ##    ds -- LSD output dataset
  ## Output:
  ##    Figure 2
  p <- length(ds)
  ds <- lapply(ds, function(x) sapply(x, function(y) colMeans(y)))
  ds <- do.call(rbind, lapply(1:p, function(i){
    
    n <- nrow(ds[[i]])
    data.frame(CK = 1:n,
               Z1 = ds[[i]][,1],
               Z2 = ds[[i]][,2],
               Z3 = ds[[i]][,3],
               Z4 = ds[[i]][,4],
               Method = names(ds)[i])
    
  }))
  
  numeric_labels <- rep(sprintf("%.2f", seq(0.01, 0.99, 0.01)), p)
  ds$CK <- numeric_labels
  
  ds_long <- pivot_longer(ds, cols = c(Z1, Z2, Z3, Z4), names_to = "Covariate", values_to = "LSD")
  ds_long$Method <- factor(ds_long$Method, levels = c("CBPS", "LBC-NET"))
  custom_colors <- c("CBPS" = "#2ca02c", "LBC-NET" = "#9467bd")
  covariate_labels <- c("Z1" = "Z1^2", "Z2" = "Z2^2", "Z3" = "Z3^2", "Z4" = "Z4^2")
  
  # Create the plot
  p <- ggplot(ds_long, aes(x = CK, y = LSD, color = Method, group = interaction(Method, Covariate))) +
    geom_point(size = 0.8) +
    geom_line(size = 0.5) +
    scale_x_discrete(breaks = c(0.01, 0.25, 0.51, 0.75, 0.99), labels = c(0.01, 0.25, 0.50, 0.75, 0.99)) + 
    facet_wrap(~ Covariate, scales = "free_y", labeller = as_labeller(covariate_labels, label_parsed)) +
    theme_bw(base_size = 20) + 
    theme(legend.position = "bottom",
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          axis.title = element_text(size = 20),
          axis.text = element_text(size = 20),
          legend.text = element_text(size = 20),
          legend.title = element_text(size = 20)) +
    labs(x = "Propensity Score", y = "LSD(%)") +
    scale_color_manual(values = custom_colors)
  
  p <- p + geom_point(data = gsd[1, ], aes(x = CK, y = GSD, color = Method), shape = 17, size = 2) 
  # Add horizontal lines for GSD values
  for (i in 2:nrow(gsd)) {
    
    p <- p + geom_point(data = gsd[i, ], aes(x = CK, y = ScaledGSD, color = Method), shape = 17, size = 2) 
    
  }
  
  p <- p + scale_y_continuous(sec.axis = sec_axis(~ . / scaling_factor, name = "GSD(%)"))
  
  return(p)
  
}

GSD_list <- list(res_true$cbps$gsd, res_true$lbc_net$gsd)
TLSD <- list(res_true$cbps$lsd, res_true$lbc_net$lsd)
names(TLSD) <- c("CBPS", "LBC-NET")
names(GSD_list) <- c("CBPS", "LBC-NET")

p <- length(TLSD)
ds <- lapply(TLSD, function(x) sapply(x, function(y) colMeans(y)))
ds <- do.call(rbind, lapply(1:p, function(i){
  
  n <- nrow(ds[[i]])
  data.frame(CK = 1:n,
             Z1 = ds[[i]][,1],
             Z2 = ds[[i]][,2],
             Z3 = ds[[i]][,3],
             Z4 = ds[[i]][,4],
             Method = names(ds)[i])
  
}))

## GSD
gsd <- lapply(GSD_list, function(x) abs(colMeans(x)))
gsd <- stack(gsd)
names(gsd) <- c("GSD", "Method")
gsd$Covariate <- rep(c("Z1", "Z2", "Z3", "Z4"), times = 2)
gsd$CK <- c(rep('0.92', 4), rep('0.94', 4))
gsd$Method <- factor(gsd$Method, levels = c("CBPS", "LBC-NET"))
scaling_factor <- 1 
gsd$ScaledGSD <- gsd$GSD * scaling_factor

ggsave("KS5k_second_mm_true_figure.pdf", plot = LSD_plot_mm_true(TLSD), width = 10, height = 8, device = "pdf", family = "Times")


LSD_plot_mm_mis <- function(ds){
  ## Purpose: Figure 2
  ## Input: 
  ##    ds -- LSD output dataset
  ## Output:
  ##    Figure 2
  p <- length(ds)
  ds <- lapply(ds, function(x) sapply(x, function(y) colMeans(y)))
  ds <- do.call(rbind, lapply(1:p, function(i){
    
    n <- nrow(ds[[i]])
    data.frame(CK = 1:n,
               X1 = ds[[i]][,1],
               X2 = ds[[i]][,2],
               X3 = ds[[i]][,3],
               X4 = ds[[i]][,4],
               Method = names(ds)[i])
    
  }))
  
  numeric_labels <- rep(sprintf("%.2f", seq(0.01, 0.99, 0.01)), p)
  ds$CK <- numeric_labels
  
  ds_long <- pivot_longer(ds, cols = c(X1, X2, X3, X4), names_to = "Covariate", values_to = "LSD")
  ds_long$Method <- factor(ds_long$Method, levels = c("CBPS", "LBC-NET"))
  custom_colors <- c("CBPS" = "#2ca02c", "LBC-NET" = "#9467bd")
  covariate_labels <- c("X1" = "X1^2", "X2" = "X2^2", "X3" = "X3^2", "X4" = "X4^2")
  
  # Create the plot
  p <- ggplot(ds_long, aes(x = CK, y = LSD, color = Method, group = interaction(Method, Covariate))) +
    geom_point(size = 0.8) +
    geom_line(size = 0.5) +
    scale_x_discrete(breaks = c(0.01, 0.25, 0.51, 0.75, 0.99), labels = c(0.01, 0.25, 0.50, 0.75, 0.99)) + 
    facet_wrap(~ Covariate, scales = "free_y", labeller = as_labeller(covariate_labels, label_parsed)) +
    theme_bw(base_size = 20) + 
    theme(legend.position = "bottom",
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          axis.title = element_text(size = 20),
          axis.text = element_text(size = 20),
          legend.text = element_text(size = 20),
          legend.title = element_text(size = 20)) +
    labs(x = "Propensity Score", y = "LSD(%)") +
    scale_color_manual(values = custom_colors)
  
  p <- p + geom_point(data = gsd[1, ], aes(x = CK, y = GSD, color = Method), shape = 17, size = 2) 
  # Add horizontal lines for GSD values
  for (i in 2:nrow(gsd)) {
    
    p <- p + geom_point(data = gsd[i, ], aes(x = CK, y = ScaledGSD, color = Method), shape = 17, size = 2) 
    
  }
  
  p <- p + scale_y_continuous(sec.axis = sec_axis(~ . / scaling_factor, name = "GSD(%)"))
  
  return(p)
  
}

GSD_list <- list(res_mis$cbps$gsd, res_mis$lbc_net$gsd)
TLSD <- list(res_mis$cbps$lsd, res_mis$lbc_net$lsd)
names(TLSD) <- c("CBPS", "LBC-NET")
names(GSD_list) <- c("CBPS", "LBC-NET")

## GSD
gsd <- lapply(GSD_list, function(x) abs(colMeans(x)))
gsd <- stack(gsd)
names(gsd) <- c("GSD", "Method")
gsd$Covariate <- rep(c("X1", "X2", "X3", "X4"), times = 2)
gsd$CK <- c(rep('0.92', 4), rep('0.94', 4))
gsd$Method <- factor(gsd$Method, levels = c("CBPS", "LBC-NET"))
scaling_factor <- 1 
gsd$ScaledGSD <- gsd$GSD * scaling_factor

ggsave("KS5k_second_mm_mis_figure.pdf", plot = LSD_plot_mm_mis(TLSD), width = 10, height = 8, device = "pdf", family = "Times")











