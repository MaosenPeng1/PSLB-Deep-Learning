## LBC_Net
library(dplyr)
source("functions.R")

## load data

s <- 1:500
file <- paste0("data", s, ".csv")
data_list <- lapply(file, read.csv, header = TRUE)
file_ck <- paste0("ck_h", s, ".csv")
ck_list <- lapply(file_ck, read.csv, header = TRUE)
p <- 4
Y_true <- 210
n <- length(s)
res <- list(L1 = NULL, L2 = NULL, L3 = NULL, L4 = NULL)

## load propensity score
for (j in 1:4){
  
  file_ps <- paste0("ps_lbc_net", s, "_",  j+1,".csv") # number of hidden layers
  ps_list <- lapply(file_ps, read.csv, header = FALSE)
  ps <- do.call(cbind, ps_list)
  
  res[[j]] <- Model_based_estimates_sim(ps, Y_true)
  
}

saveRDS(res, paste0("layer_res.rds"))




