## LBC_Net
library(dplyr)
source("functions.R")

## load data

s <- 1:500
file <- paste0("data", s, ".csv")
data_list <- lapply(file, read.csv, header = TRUE)
file_ck <- paste0("ck_h", s, ".csv")
ck_list <- lapply(file_ck, read.csv, header = TRUE)
p <- 4
Y_true <- 210
n <- length(s)
lr <- c(0.005, 0.01, 0.05, 0.1)
res <- list(lr0.005 = NULL, lr0.01 = NULL, lr0.05 = NULL, lr0.1 = NULL)

## load propensity score
for (j in 1:4){
  
  file_ps <- paste0("ps_lbc_net", s, "_",  lr[j],".csv") # number of hidden layers
  ps_list <- lapply(file_ps, read.csv, header = FALSE)
  ps <- do.call(cbind, ps_list)
  
  res[[j]] <- Model_based_estimates_sim(ps, Y_true)
  
}

saveRDS(res, paste0("lr_res.rds"))




