res <- readRDS("lr_res.rds")

layer_table <- data.frame(layers = c("lr0.005", "lr0.01", "lr0.05", "lr0.1"),
                          Bias = c(res$lr0.005$pbias, res$lr0.01$pbias, res$lr0.05$pbias, res$lr0.1$pbias),
                          RMSE = c(res$lr0.005$rmse, res$lr0.01$rmse, res$lr0.05$rmse, res$lr0.1$rmse),
                          Variance = c(res$lr0.005$var, res$lr0.01$var, res$lr0.05$var, res$lr0.1$var))

## create tables
library(dplyr)
library(tidyr)
library(textables)

layer_table_new <- layer_table  %>% pivot_longer(
  cols = Bias:Variance, # Columns to pivot
  names_to = "measure", # Name of the new column that will contain the names of the pivoted columns
  values_to = "value" # Name of the new column that will contain the values of the pivoted columns
) %>%
  pivot_wider(
    names_from = layers, # Column to use as column names
    values_from = value # Column to use as values
  ) %>%
  mutate(measure = ifelse(measure=="Bias", "% Bias", measure)) %>%
  mutate(
    across(
      c(2:5), # Columns to format
      ~ ifelse(
        abs(.x) < 0.005, 
        format(.x, scientific = TRUE, digits = 1), # Scientific format for values < 0.005
        sprintf("%.2f", .x) # Two decimal places otherwise
      )
    )
  )


tab <- midrulep(list(c(2,4))) +
  TR("Learning Rate") %:% with(layer_table_new, TR(measure)) +
  midrule() +
  TR("0.005") %:% with(layer_table_new, TR(lr0.005)) +
  TR("0.01") %:% with(layer_table_new, TR(lr0.01)) +
  TR("0.05") %:% with(layer_table_new, TR(lr0.05)) +
  TR("0.1") %:% with(layer_table_new, TR(lr0.1)) 

# Print the table to a text variable
text_output <- capture.output(print(tab))

# Write the text output to a file
writeLines(text_output, "table_output.txt")

###################################################################
######################## LSD Plot ################################
###################################################################
library(ggplot2)

LSD_balance_plot <- function(ds){
  ## Purpose: Figure 1
  ## Input: 
  ##    ds -- LSD output dataset
  ## Output:
  ##    Figure 1
  p <- length(ds)
  ds <- lapply(ds, function(x) sapply(x, function(y) colMeans(y)))
  ds <- do.call(rbind, lapply(1:p, function(i){
    
    n <- nrow(ds[[i]])
    data.frame(CK = 1:n,
               Z1 = ds[[i]][,1],
               Z2 = ds[[i]][,2],
               Z3 = ds[[i]][,3],
               Z4 = ds[[i]][,4],
               lr = names(ds)[i])
    
  }))
  
  numeric_labels <- rep(sprintf("%.2f", seq(0.01, 0.99, 0.01)), p)
  ds$CK <- numeric_labels
  
  ds_long <- pivot_longer(ds, cols = c(Z1, Z2, Z3, Z4), names_to = "Covariate", values_to = "LSD")
  ds_long$lr <- factor(ds_long$lr, levels = c("lr0.005", "lr0.01", "lr0.05", "lr0.1"))
  custom_colors <- c(
    "lr0.005" = "#ff7f0e",   # Orange
    "lr0.01" = "#d62728",  # Red
    "lr0.05" = "#2ca02c",      # Green
    "lr0.1" = "#17becf"
  )
  
  # Create the plot
  p <- ggplot(ds_long, aes(x = CK, y = LSD, color = lr, group = interaction(lr, Covariate))) +
    geom_point(size = 0.8) +
    geom_line(size = 0.5) +
    scale_x_discrete(breaks = c(0.01, 0.25, 0.51, 0.75, 0.99), labels = c(0.01, 0.25, 0.5, 0.75, 0.99)) + 
    facet_wrap(~ Covariate, scales = "free_y") +
    theme_bw(base_size = 20) + 
    theme(legend.position = "bottom",
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          axis.title = element_text(size = 20),
          axis.text = element_text(size = 20),
          legend.text = element_text(size = 20),
          legend.title = element_text(size = 20)) +
    labs(x = "Propensity Score", y = "LSD(%)") +
    scale_color_manual(values = custom_colors)
  
  p <- p + geom_point(data = gsd[1, ], aes(x = CK, y = GSD, color = lr), shape = 17, size = 2) 
  # Add horizontal lines for GSD values
  for (i in 2:nrow(gsd)) {
    
    p <- p + geom_point(data = gsd[i, ], aes(x = CK, y = ScaledGSD, color = lr), shape = 17, size = 2) 
    
  }
  
  p <- p + scale_y_continuous(sec.axis = sec_axis(~ . / scaling_factor, name = "GSD(%)"))
  
  return(p)
  
}

## LSD
GSD_list <- list(res$lr0.005$gsd, res$lr0.01$gsd, res$lr0.05$gsd, res$lr0.1$gsd)
TLSD <- list(res$lr0.005$lsd, res$lr0.01$lsd, res$lr0.05$lsd, res$lr0.1$lsd)
names(TLSD) <- c("lr0.005", "lr0.01", "lr0.05", "lr0.1")
names(GSD_list) <- c("lr0.005", "lr0.01", "lr0.05", "lr0.1")

## GSD
gsd <- lapply(GSD_list, function(x) abs(colMeans(x)))
gsd <- stack(gsd)
names(gsd) <- c("GSD", "lr")
gsd$Covariate <- rep(c("Z1", "Z2", "Z3", "Z4"), times = 4)
gsd$CK <- c(rep('0.88', 4), rep('0.90', 4), rep('0.92', 4), rep('0.94', 4))
gsd$lr <- factor(gsd$lr, levels = c("lr0.005", "lr0.01", "lr0.05", "lr0.1"))
scaling_factor <- 1 
gsd$ScaledGSD <- gsd$GSD * scaling_factor

ggsave("KS_tune_lr_figure.pdf", plot = LSD_balance_plot(TLSD), width = 10, height = 8, device = "pdf", family = "Times")

