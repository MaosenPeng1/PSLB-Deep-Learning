## LBC_Net
library(dplyr)
source("functions.R")

## load data

s <- 1:500
rhos <- c(0.05, 0.1, 0.15, 0.2, 0.25)
p <- 4
Y_true <- 210
n <- length(s)
file <- paste0("data", s, ".csv")
data_list <- lapply(file, read.csv, header = TRUE)
res <- list(rho0.05 = NULL, rho0.1 = NULL, rho0.15 = NULL, rho0.2 = NULL, rho0.25 = NULL)

for (j in 1:length(rhos)){
  
  file_ck <- paste0("ck_h", s, "_", rhos[j], ".csv")
  ck_list <- lapply(file_ck, read.csv, header = TRUE)
 
  file_ps <- paste0("ps_lbc_net", s, "_rho", rhos[j], ".csv")
  ps_list <- lapply(file_ps, read.csv, header = FALSE)
  ps_lbc_net <- do.call(cbind, ps_list)
  
  Y_est <- rep(NA, n)
  for (i in 1:n){
    
    ds <- data_list[[i]]
    X <- ds[, 3:6]       
    Z <- ds[, 2]         
    Y <- ds[, 1]      
    
    ## Y_est estimation (length of stay)
    wt <- ipw(Z, ps_lbc_net[,i])  # Inverse probability weights
    Y_est[i] <- Y_infer(Y, wt, Z)
    
    }
  
  res[[j]] <- Col_bias_variance_rmse(Y_est, Y_true)

}
  
saveRDS(res, paste0("rho_res.rds"))
