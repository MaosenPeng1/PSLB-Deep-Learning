res <- readRDS("rho_res.rds")
source("functions.R")

library(dplyr)
library(tidyr)
library(textables)

table_rho <- data.frame(methods = c("0.05", "0.1", "0.15", "0.2", "0.25"),
                             Bias = c(res$rho0.05$pbias, res$rho0.1$pbias, res$rho0.15$pbias, res$rho0.2$pbias, res$rho0.25$pbias),
                             RMSE = c(res$rho0.05$rmse, res$rho0.1$rmse, res$rho0.15$rmse, res$rho0.2$rmse, res$rho0.25$rmse),
                             Variance = c(res$rho0.05$var, res$rho0.1$var, res$rho0.15$var, res$rho0.2$var, res$rho0.25$var))

table_rho_new <- table_rho %>% pivot_longer(
  cols = Bias:Variance, # Columns to pivot
  names_to = "measure", # Name of the new column that will contain the names of the pivoted columns
  values_to = "value" # Name of the new column that will contain the values of the pivoted columns
) %>%
  pivot_wider(
    names_from = methods, # Column to use as column names
    values_from = value # Column to use as values
  ) %>%
  mutate(measure = ifelse(measure=="Bias", "% Bias", measure)) %>%
  mutate(
  across(
    c(2:6), # Columns to format
    ~ ifelse(
      abs(.x) < 0.005, 
      format(.x, scientific = TRUE, digits = 1), # Scientific format for values < 0.005
      sprintf("%.2f", .x) # Two decimal places otherwise
    )
  )
)
  


tab <- TR("Rho") %:% with(table_rho_new, TR(measure)) +
  midrule() +
  TR("0.05") %:% with(table_rho_new, TR(`0.05`)) +
  TR("0.1") %:% with(table_rho_new, TR(`0.1`)) +
  TR("0.15") %:% with(table_rho_new, TR(`0.15`)) +
  TR("0.2 ") %:% with(table_rho_new, TR(`0.2`)) +
  TR("0.25") %:% with(table_rho_new, TR(`0.25`))

# Print the table to a text variable
text_output <- capture.output(print(tab))

# Write the text output to a file
writeLines(text_output, "table_output.txt")
