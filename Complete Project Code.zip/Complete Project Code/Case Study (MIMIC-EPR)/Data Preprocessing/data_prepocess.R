## Load library
library(data.table, exclude = c("select", "filter"))
library(dplyr)
library(lubridate)
library(tidyr)
library(stringr)
library(gtsummary)

## Read file names
file_names <- readLines("datasets.txt") ## data can be downloaded via https://physionet.org/content/mimiciv/3.0/

## Function to read datasets using fread and convert to data.frame
read_and_convert <- function(file) {
  df_temp <- fread(file)
  as.data.frame(df_temp)
}

## Read all datasets
datasets <- lapply(file_names, read_and_convert)

## Assign names to datasets
names(datasets) <- gsub("\\.csv$", "", file_names)

## Extract individual datasets
admissions <- datasets[["admissions"]]
chartevents <- datasets[["chartevents"]]
diagnoses_icd <- datasets[["diagnoses_icd"]]
icustays <- datasets[["icustays"]]
inputevents <- datasets[["inputevents"]]
labevents <- datasets[["labevents"]]
patients <- datasets[["patients"]]
prescriptions <- datasets[["prescriptions"]]
procedures_icd <- datasets[["procedures_icd"]]
# for large dataset such as chartevents, labevents, and prescriptions one can read with selected used columns. 
# Runing this file takes large memory and time, suggest separate by part.

##########################################
## Step 1. Define study population
##########################################

# Regard the admission time to the ICU as a proximate the onset of spesis diagnosis. Since the pre-ICU SOFA scores are unavailable, 
# we use SOFA score within 24 hours after ICU admission. Here for Sepsis-3, we need ICD code and SOFA scores. Limitation: SOFA scores 
# calculation, admission to ICU may not primarily due to the reason of sepsis.

### Step a: Filter diagnoses for spesis patients based on specific ICD codes ("99591", "A41")
sepsis_code <- c("78552", "99592", "R6520", "R6521")

## Filter the diagnoses_icd dataset to retain only rows where the icd_code matches the sepsis_code list
diagnoses_sepsis <- diagnoses_icd %>%
  filter(str_detect(icd_code, paste0("^", sepsis_code, collapse = "|"))) %>%
  group_by(hadm_id) %>%
  slice(1) %>%
  ungroup()

### Step b: Join filtered diagnoses with admissions
# Join the filtered sepsis diagnoses (diagnoses_sepsis) with the admissions dataset using hadm_id
# Group by hadm_id to remove duplicate admissions and keep only the first occurrence for each admission
ds_base <- admissions %>%
  inner_join(diagnoses_sepsis, by = "hadm_id") %>%
  group_by(hadm_id) %>%
  slice(1) %>%
  ungroup()

### Step c: Add ICU stay information
# Join the ds_base dataset with icustays to retain only those patients with ICU stays
# Arrange by hadm_id and ICU admission time (intime) and keep only the first ICU stay per hadm_id
# inclusion criteria 1: los in icu > 3 days (5974 patients) | > 7 days (3252 pateints).  
ds_sepsis_base <- ds_base %>%
  inner_join(icustays, by = "hadm_id") %>%
  filter(los >= 3) %>%
  arrange(hadm_id, intime) %>%
  group_by(hadm_id) %>%
  slice(1) %>%
  ungroup()

### Step d: Add patient demographic information (age)
# Join the ds_sepsis_base dataset with patient demographic information
# The join is done on hadm_id and subject_id.x to match the patient data
# exclusion criteria 1: age > 18
ds_sepsis_base <- ds_sepsis_base %>%
  inner_join(patients, by = c("subject_id.x" = "subject_id")) %>%
  mutate(subject_id = subject_id.x) %>%
  filter(anchor_age > 18) %>%
  select(c(subject_id, hadm_id, admittime, dischtime, intime, outtime, deathtime, los, gender, anchor_age, race, admission_type))

##########################################
## Step 2. Define treatment groups
##########################################

### Step a: Define lab variable item IDs and corresponding names
tr_ids <- c(50821, 50885, 51277, 51265, 50882, 51006)
tr_names <- c("PaO2", "Bilirubin", "RDW", "Platelet", "Bicarbonate", "BUN")

## Create a named vector mapping lab item IDs to names
itemid_to_name <- setNames(tr_names, tr_ids)

### Step b: Filter the data for relevant lab variable IDs and clean it
ds_tr_filtered <- ds_sepsis_base %>%
  inner_join(labevents, by = c("hadm_id")) %>%
  filter(itemid %in% tr_ids) %>%                  # Keep only rows for specified lab item IDs
  mutate(tr_names = itemid_to_name[as.character(itemid)]) # Map itemid to lab_names

### Step c: Calculate worst values within 24 hours and add RDW3 and Platelet3
# inclusion criteria 2: both RDW and Platelet are available. And at least one lab results are available (remove subject if all 24 hours 
# lab results are missing). 
ds_tr_wide <- ds_tr_filtered %>%  
  filter(charttime >= intime & charttime <= intime + hours(24)) %>%
  filter(!is.na(valuenum) & valuenum > 0 & valuenum != 999999) %>%
  group_by(hadm_id, tr_names) %>%
  # Select the worst value within the 24-hour window for each lab variable, if available
  reframe(
    worst_value = case_when(
      tr_names %in% c("Bilirubin", "BUN") ~ ifelse(is.finite(max(valuenum, na.rm = TRUE)), max(valuenum, na.rm = TRUE), NA),
      tr_names %in% c("PaO2", "Bicarbonate") ~ ifelse(is.finite(min(valuenum, na.rm = TRUE)), min(valuenum, na.rm = TRUE), NA),
      tr_names %in% c("RDW", "Platelet") ~ first(valuenum[!is.na(valuenum)]) # First non-NA for RDW and Platelet
    )
  ) %>%
  group_by(hadm_id, tr_names) %>%
  slice(1) %>%  
  ungroup() %>%
  # Pivot the data from long to wide format to keep one record per hadm_id
  pivot_wider(names_from = tr_names, values_from = worst_value, values_fill = NA) %>%
  # Add RDW3 and Platelet3 at day 3 after ICU admission
  left_join(
    ds_tr_filtered %>%
      filter(charttime >= intime + days(3) & charttime < intime + days(4)) %>%
      filter(tr_names %in% c("RDW", "Platelet")) %>%
      group_by(hadm_id, tr_names) %>%
      reframe(
        first_value_3 = first(valuenum[!is.na(valuenum)]) # First non-NA for 3_Platelet and 3_RDW
      ) %>%
      pivot_wider(names_from = tr_names, values_from = first_value_3, names_prefix = "3_", values_fill = NA),
    by = "hadm_id"
  ) %>%
  rename(
    RDW0 = RDW,
    Platelet0 = Platelet,
    RDW3 = `3_RDW`,
    Platelet3 = `3_Platelet`
  ) %>%
  filter(!is.na(Platelet0) & !is.na(RDW0) & !is.na(RDW3) & !is.na(Platelet3))

## check missingness
colSums(is.na(ds_tr_wide))/nrow(ds_tr_wide)

# 64 due to baseline missing RPR, 338 due to missing on day 3

### Step d: Calculate treatment indicator
ds_treatment <- ds_tr_wide %>%
  mutate(
    RPR0 = RDW0 / Platelet0,
    RPR3 = RDW3 / Platelet3,
    RPR_change = abs((RPR3 - RPR0) / RPR0),
    Tr = ifelse(RPR_change >= 0.3, 1, 0)
  )

### Step e: Clean and finalize the dataset
ds_treatment_clean <- ds_sepsis_base %>%
  inner_join(ds_treatment, by = "hadm_id") %>%
  select(c(subject_id, hadm_id, admittime, dischtime, intime, outtime, deathtime, los, Tr, gender, 
           anchor_age, race, admission_type, Bilirubin, Bicarbonate, BUN, PaO2, Platelet0, RPR0)) %>%
  rename(Platelet = Platelet0)

##########################################
## Step 3. Construct more Lab Variables
##########################################

### Step a: Define lab variable item IDs and corresponding names
lab_ids <- c(220045, 220228, 220645, 227442, 220181, 225690, 220615, 
             220739, 223901, 223900, 220224, 223835, 220546)
lab_names <- c("Heart_rate", "Hgb", "Sodium", "Potassium", "MAP", "Bilirubin_lab", "Creatinine", 
               "GCSeye", "GCSmotor", "GCSverbal", "paO2_lab", "FiO2", "WBC")

## Create a named vector mapping lab item IDs to names
itemid_to_name <- setNames(lab_names, lab_ids)

### Step b: Filter the data for relevant lab variable IDs and clean it
ds_lab_filtered <- ds_treatment_clean %>%
  inner_join(chartevents, by = c("hadm_id")) %>%
  filter(itemid %in% lab_ids) %>%                  # Keep only rows for specified lab item IDs
  mutate(lab_names = itemid_to_name[as.character(itemid)]) # Map itemid to lab_names

ds_lab_wide <- ds_lab_filtered %>%  
  filter(charttime >= intime & charttime <= intime + hours(24)) %>%
  filter(valuenum > 0 & valuenum != 999999) %>%
  group_by(hadm_id, lab_names) %>%
  # Select the worst value within the 24-hour window for each lab variable, if available
  reframe(
    worst_value = case_when(
      lab_names %in% c("Heart_rate", "WBC", "Creatinine", "Sodium", "glucose", "Bilirubin_lab", "FiO2") ~ ifelse(is.finite(max(valuenum, na.rm = TRUE)), max(valuenum, na.rm = TRUE), NA),
      lab_names %in% c("Hgb", "MAP", "paO2_lab", "Potassium", "GCSeye", "GCSmotor", "GCSverbal") ~ ifelse(is.finite(min(valuenum, na.rm = TRUE)), min(valuenum, na.rm = TRUE), NA)
    )
  ) %>%
  group_by(hadm_id, lab_names) %>%
  slice(1) %>%  
  ungroup() %>%
  # Pivot the data from long to wide format to keep one record per hadm_id
  pivot_wider(names_from = lab_names, values_from = worst_value, values_fill = NA)

## check missingness 
colSums(is.na(ds_lab_wide))/nrow(ds_lab_wide)

### Step c: Clean and finalize the dataset
ds_lab_clean <- ds_treatment_clean %>%
  inner_join(ds_lab_wide, by = "hadm_id")

### Step d: Pivot the lab data to a wide format
ds_lab_clean <- ds_lab_clean %>%
  # Apply specific transformations to Bilirubin
  mutate(
    Bilirubin_combined = coalesce(Bilirubin, Bilirubin_lab),
    paO2_combined = coalesce(PaO2, paO2_lab),
    GCS = GCSeye + GCSmotor + GCSverbal
  ) %>%
  select(-c("GCSeye", "GCSmotor", "GCSverbal", "Bilirubin", "Bilirubin_lab", "PaO2", "paO2_lab")) %>%
  rename(Bilirubin = Bilirubin_combined,
         PaO2 = paO2_combined) %>%
  mutate(across(where(is.numeric), ~ ifelse(is.na(.), median(., na.rm = TRUE), .))) ## median imputation (a normal range imputation)

## check missingness 
colSums(is.na(ds_lab_clean))/nrow(ds_lab_clean) 
# percent missingness: PaO2 - 12.6%; FiO2 - 24.6%; Bilirubin - 23.4%, all the other less than 1 %. 

################################################
## Step 4. Construct Drug and Therapy Variables
################################################

# All labs vairbales are taken within 24 hours as the baseline characteristics and for the drugs and treatment, within 48 hours before 
# exposure are treated as baseline (early-stage ICU interventions!). However this will introduce possible residual confounding. 
# Maybe sensitivity analysis include longer treatment use. 

# ---------------------------------------
# Antiplatelets agents
# ---------------------------------------

### Step a: Define the list of anti-platelet drug names
anti_platelet_names <- c("Aspirin", "Clopidogrel", "Ticagrelor", "Prasugrel", 
                         "Cilostazol", "Dipyridamole")

### Step b: Join the prescriptions dataset with the lab dataset (ds_lab_clean) using hospital admission ID (hadm_id)
ds_antiplatelets <- ds_lab_clean %>%
  inner_join(prescriptions, by = c("hadm_id")) %>%
  mutate(anti_platelet = ifelse(
    starttime >= intime & starttime < intime + days(3) &
      str_detect(drug, regex(paste(anti_platelet_names, collapse = "|"), ignore_case = TRUE)), 
    1, 0)) %>%
  arrange(hadm_id, desc(anti_platelet)) %>%
  group_by(hadm_id) %>%
  slice(1) %>%
  ungroup() %>%
  select(-c(drug, starttime, stoptime, dose_val_rx))

# ---------------------------------------
# Anticoagulation agents
# ---------------------------------------

### Step a: Define the name patterns for Warfarin and NOAC drugs
warfarin_name <- "Warfarin|Coumadin"  # Warfarin or its brand name Coumadin
noac_names <- c("Apixaban", "Eliquis", "Dabigatran", "Pradaxa", 
                "Edoxaban", "Lixiana", "Rivaroxaban", "Xarelto")  # NOAC drugs

### Step b: Join the prescriptions dataset with the anti-platelet dataset (ds_antiplatelets) by hadm_id
ds_anticoagulants <- ds_antiplatelets %>%
  inner_join(prescriptions, by = c("hadm_id")) %>%
  mutate(
    warfarin = ifelse(starttime >= intime & starttime < intime + days(3) &
                        str_detect(drug, regex(warfarin_name, ignore_case = TRUE)), 1, 0),  # Warfarin indicator
    NOAC = ifelse(starttime >= intime & starttime < intime + days(3) &
                    str_detect(drug, regex(paste(noac_names, collapse = "|"), ignore_case = TRUE)), 1, 0)  # NOAC indicator
  ) %>%
  arrange(hadm_id, desc(warfarin), desc(NOAC)) %>%
  group_by(hadm_id) %>%
  slice(1) %>%
  ungroup() %>%
  select(-c(drug, starttime, stoptime, dose_val_rx))

# ---------------------------------------
# tPA
# ---------------------------------------

### Step a: Define the list of tPA drug names
tPA_names <- c("Alteplase", "Activase")

### Step b: Join the prescriptions dataset with the lab dataset (ds_lab_clean) using hospital admission ID (hadm_id)
ds_tPA <- ds_anticoagulants %>%
  inner_join(prescriptions, by = c("hadm_id")) %>%
  mutate(tPA = ifelse(
    starttime >= intime & starttime < intime + days(3) &
      str_detect(drug, regex(paste(tPA_names, collapse = "|"), ignore_case = TRUE)), 
    1, 0)) %>%
  arrange(hadm_id, desc(tPA)) %>%
  group_by(hadm_id) %>%
  slice(1) %>%
  ungroup() %>%
  select(-c(drug, starttime, stoptime, dose_val_rx))

# ---------------------------------------
# Vasopressor use (SOFA scores)
# ---------------------------------------

vaso_ids <- c(221289, 221906, 221662, 221653)
vaso_names <- c("Epinephrine", "Norepinephrine", "Dopamine", "Dobutamine")

## Create a named vector mapping lab item IDs to names
itemid_to_name <- setNames(vaso_names, vaso_ids)

## Filter the data for relevant lab variable IDs and clean it
ds_vaso_filtered <- ds_tPA %>%
  inner_join(inputevents, by = c("hadm_id")) %>%
  filter(itemid %in% vaso_ids) %>%                  # Keep only rows for specified lab item IDs
  mutate(vaso_names = itemid_to_name[as.character(itemid)]) # Map itemid to lab_names

aggregated_drugs <- ds_vaso_filtered %>%
  filter(starttime >= intime & starttime < intime + hours(24)) %>%
  group_by(hadm_id, itemid) %>%
  summarize(
    dose_ug_kg_min = max(rate, na.rm = TRUE)
  ) %>%
  ungroup() %>%
  pivot_wider(names_from = itemid, values_from = dose_ug_kg_min, values_fill = NA) %>%
  rename("Epinephrine" = "221289",
         "Norepinephrine" = "221906",
         "Dopamine" = "221662",
         "Dobutamine" = "221653")

ds_vaso_sofa <- ds_tPA %>%
  left_join(aggregated_drugs, by = c("hadm_id")) %>%
  mutate(across(c(Norepinephrine:Dobutamine), ~ replace_na(.x, 0)))

# ---------------------------------------
# Vasopressor use (Variable)
# ---------------------------------------

### Step a: Define the list of tPA drug names
Vaso_names <- c("Epinephrine", "Norepinephrine", "Dopamine", "Dobutamine", "Milrinone")

### Step b: Join the prescriptions dataset with the lab dataset (ds_lab_clean) using hospital admission ID (hadm_id)
ds_vaso <- ds_vaso_sofa %>%
  inner_join(prescriptions, by = c("hadm_id")) %>%
  filter(starttime >= intime & starttime < intime + days(3)) %>%
  mutate(vaso = ifelse(
    str_detect(drug, regex(paste(Vaso_names, collapse = "|"), ignore_case = TRUE)),
    1, 0)) %>%
  arrange(hadm_id, desc(vaso)) %>%
  group_by(hadm_id) %>%
  slice(1) %>%
  ungroup() %>%
  select(-c(drug, starttime, stoptime))

# ---------------------------------------------------------
# Renal Replacement Therapy (RRT) using Procedure ICD code
# --------------------------------------------------------

### Step a: Filter diagnoses for RRT based on specific procedure ICD codes
RRT_code <- c("5A1D90Z", "5A1D70Z")

# Filter the procedures_icd dataset to retain only rows where the icd_code matches the sepsis_code list
diagnoses_RRT <- procedures_icd %>%
  filter(str_detect(icd_code, paste0("^", RRT_code, collapse = "|"))) %>%
  group_by(hadm_id) %>%
  slice(1) %>%
  ungroup()

ds_RRT <- ds_Vaso %>%
  left_join(diagnoses_RRT, by = "hadm_id") %>%
  mutate(intime_date = as_date(intime),              
         cutoff_date = intime_date + days(2),
         RRT = ifelse(!is.na(icd_code) & chartdate >= intime_date & chartdate <= cutoff_date, 1, 0),
         subject_id = subject_id.x) %>%
  select(c(subject_id, hadm_id, admittime, dischtime, intime, outtime, deathtime, los, Tr, gender, anchor_age, race, admission_type, 
           Bicarbonate, BUN, Creatinine, Heart_rate, Hgb, MAP, Potassium, Sodium, FiO2, WBC, Bilirubin, PaO2, GCS, anti_platelet,
           warfarin, NOAC, tPA, vaso, Norepinephrine, Dopamine, Epinephrine, Dobutamine, RRT, Platelet, RPR0))
# Assuming Continuous Renal Replacement Therapy (CRRT) and Intermittent Hemodialysis (IHD) date and ICU admission are start at the time. 

##########################################
## Step 5. Construct Risk Scores
##########################################

#Here we use CCI scores to replace all comorbidty variables in the study. 
# Using comorbidity scores instead of individual variables provides a simplified, consolidated measure of disease burden, 
# which reduces model complexity and enhances interpretability, especially in complex ICU populations. Scores like 
# the Charlson Comorbidity Index (CCI) mitigate issues of multicollinearity by capturing correlated comorbidities in a single measure, 
# thus preserving statistical power and reducing overfitting. This approach leverages validated predictors of outcomes, which improves model 
# reliability and aligns with clinical standards, making findings more comparable to other studies. By summarizing overall health status 
# efficiently, comorbidity scores offer a robust and streamlined way to account for baseline risk in the association between RPR and survival 
# in sepsis.

# ---------------------------------------
# CCI score
# ---------------------------------------

### Step a: Define ICD codes for CCI score components
cci_icd_codes <- list(
  "Myocardial infarct" = c("410", "412", "I21", "I22", "I252"),
  "Congestive heart failure" = c("428", "39891", "40201", "40211", "40291", "40401", "40403", "40411", "40413", "40491", "40493", "4254", "4259", "I43", "I50", "I099", "I110", "I130", "I132", "I255", "I420", "I425", "I426", "I427", "I428", "I429", "P290"),
  "Peripheral vascular disease" = c("440", "441", "0930", "4373", "4471", "5571", "5579", "V434", "4431", "4439", "I70", "I71", "I731", "I738", "I739", "I771", "I790", "I792", "K551", "K558", "K559", "Z958", "Z959"),
  "Cerebrovascular disease" = c("430", "431", "432", "433", "434", "435", "436", "437", "438", "36234", "G45", "G46", "I60", "I61", "I62", "I63", "I64", "I65", "I66", "H340"),
  "Dementia" = c("290", "2941", "3312", "F00", "F01", "F02", "F03", "G30", "F051", "G311"),
  "Chronic pulmonary disease" = c("490", "491", "492", "493", "494", "495", "496", "500", "501", "502", "503", "504", "505", "4168", "4169", "5064", "5081", "5088", "J40", "J41", "J42", "J43", "J44", "J45", "J46", "J47", "J60", "J61", "J62", "J63", "J64", "J65", "J66", "J67", "I278", "I279", "J684", "J701", "J703"),
  "Rheumatic disease" = c("725", "4465", "7100", "7101", "7102", "7103", "7104", "7140", "7141", "7142", "7148", "M05", "M06", "M32", "M33", "M34", "M315", "M351", "M353", "M360"),
  "Peptic ulcer disease" = c("531", "532", "533", "534", "K25", "K26", "K27", "K28"),
  "Mild liver disease" = c("570", "571", "0706", "0709", "5733", "5734", "5738", "5739", "V427", "07022", "07023", "07032", "07033", "07044", "07054", "B18", "K73", "K74", "K700", "K701", "K702", "K703", "K709", "K713", "K714", "K715", "K717", "K760", "K762", "K763", "K764", "K768", "K769", "Z944"),
  "Diabetes without chronic complication" = c("2500", "2501", "2502", "2503", "2508", "2509", "E100", "E101", "E106", "E108", "E109", "E110", "E111", "E116", "E118", "E119", "E120", "E121", "E126", "E128", "E129", "E130", "E131", "E136", "E138", "E139", "E140", "E141", "E146", "E148", "E149"),
  "Diabetes with chronic complication" = c("2504", "2505", "2506", "2507", "E102", "E103", "E104", "E105", "E107", "E112", "E113", "E114", "E115", "E117", "E122", "E123", "E124", "E125", "E127", "E132", "E133", "E134", "E135", "E137", "E142", "E143", "E144", "E145"),
  "Paraplegia" = c("342", "343", "3341", "3440", "3441", "3442", "3443", "3444", "3445", "3446", "3449", "G81", "G82", "G041", "G114", "G801", "G802", "G830", "G831", "G832", "G833", "G834", "G835", "G839"),
  "Renal disease" = c("582", "585", "586", "V56", "5880", "V420", "V451", "40301", "40311", "40391", "40402", "40403", "40412", "40413", "40492", "40493", "5830", "5831", "5832", "5833", "5834", "5835", "5836", "5837", "N180", "N181", "N182", "N183", "N184", "N185", "N186", "I120", "I131", "N032", "N033", "N034", "N035", "N036", "N037", "N052", "N053", "N054", "N055", "N056", "N057", "N250", "Z490", "Z491", "Z492", "Z940", "Z992"),
  "Malignant cancer" = c("14", "15", "160", "161", "162", "163", "164", "165", "170", "171", "172", "173", "174", "175", "176", "179", "18", "190", "191", "192", "193", "194", "195", "20", "C0", "C1", "C2", "C3", "C4", "C5", "C6", "C71", "C72", "C73", "C74", "C75", "C76"),
  "Severe liver disease" = c("4560", "4561", "4562", "5722", "5723", "5724", "5728", "I850", "I859", "I864", "I982", "K704", "K711", "K721", "K729", "K765", "K766", "K767"),
  "Metastatic solid tumor" = c("196", "197", "198", "199", "C77", "C78", "C79", "C80"),
  "HIV/AIDS" = c("042", "043", "044", "B20", "B21", "B22", "B24")
)

# Function to map an ICD code to the corresponding disease
map_cci_disease <- function(icd_code) {
  for (disease in names(cci_icd_codes)) {
    if (any(startsWith(icd_code, cci_icd_codes[[disease]]))) {
      return(disease)
    }
  }
  return(NA)  # Return NA if no match
}

### Step b: Combine the data with diagnosis information and map CCI diseases
ds_combined <- ds_RRT %>%
  left_join(diagnoses_icd, by = "hadm_id")

# Apply the mapping function to create a new Disease column
ds_disease <- ds_combined %>%
  mutate(Disease = sapply(icd_code, map_cci_disease)) 

### Step c: Pivot the dataset to a wider format and create binary presence indicators
ds_disease_wide <- ds_disease %>%
  mutate(Presence = ifelse(!is.na(Disease), 1, 0)) %>%  
  pivot_wider(
    names_from = Disease,
    values_from = Presence,
    values_fill = list(Presence = 0)
  ) %>%
  group_by(hadm_id) %>%
  slice(1) %>%
  ungroup()

### Step d: Calculate the CCI score components
ds_cci <- ds_disease_wide %>%
  mutate(
    Myocardial_infarct_score = ifelse(`Myocardial infarct` == 1, 1, 0),
    Congestive_heart_failure_score = ifelse(`Congestive heart failure` == 1, 1, 0),
    Peripheral_vascular_disease_score = ifelse(`Peripheral vascular disease` == 1, 1, 0),
    Cerebrovascular_disease_score = ifelse(`Cerebrovascular disease` == 1, 1, 0),
    Dementia_score = ifelse(Dementia == 1, 1, 0),
    Chronic_pulmonary_disease_score = ifelse(`Chronic pulmonary disease` == 1, 1, 0),
    Rheumatic_disease_score = ifelse(`Rheumatic disease` == 1, 1, 0),
    Peptic_ulcer_disease_score = ifelse(`Peptic ulcer disease` == 1, 1, 0),
    Mild_liver_disease_score = ifelse(`Mild liver disease` == 1, 1, 0),
    Diabetes_without_chronic_complication_score = ifelse(`Diabetes without chronic complication` == 1, 1, 0),
    Diabetes_with_chronic_complication_score = ifelse(`Diabetes with chronic complication` == 1, 2, 0),
    Paraplegia_score = ifelse(Paraplegia == 1, 2, 0),
    Renal_disease_score = ifelse(`Renal disease` == 1, 2, 0),
    Malignant_cancer_score = ifelse(`Malignant cancer` == 1, 2, 0),
    Severe_liver_disease_score = ifelse(`Severe liver disease` == 1, 3, 0),
    Metastatic_solid_tumor_score = ifelse(`Metastatic solid tumor` == 1, 6, 0),
    HIV_AIDS_score = ifelse(`HIV/AIDS` == 1, 6, 0),
    Age_score = case_when(
      anchor_age >= 70 ~ 4,
      anchor_age >= 61 & anchor_age < 70 ~ 3,
      anchor_age >= 51 & anchor_age < 61 ~ 2,
      anchor_age >= 41 & anchor_age < 51 ~ 1,
      TRUE ~ 0
    )
  ) %>%
  rowwise() %>%
  mutate(CCI_score = sum(
    Myocardial_infarct_score, Congestive_heart_failure_score, Peripheral_vascular_disease_score, 
    Cerebrovascular_disease_score, Dementia_score, Chronic_pulmonary_disease_score, Rheumatic_disease_score, 
    Peptic_ulcer_disease_score, Mild_liver_disease_score, Diabetes_without_chronic_complication_score, 
    Diabetes_with_chronic_complication_score, Paraplegia_score, Renal_disease_score, Malignant_cancer_score, 
    Severe_liver_disease_score, Metastatic_solid_tumor_score, HIV_AIDS_score, Age_score
  )) %>%
  ungroup()

### Step e: Cleanup the dataset
ds_cci <- ds_cci %>%
  mutate(subject_id = subject_id.x) %>%
  select(c(subject_id, hadm_id, admittime, dischtime, intime, outtime, deathtime, los, Tr, gender, anchor_age, race, admission_type, 
           Bicarbonate, BUN, Creatinine, Heart_rate, Hgb, MAP, Potassium, Sodium, FiO2, WBC, Bilirubin, PaO2, GCS, anti_platelet,
           warfarin, NOAC, tPA, vaso, Norepinephrine, Dopamine, Epinephrine, Dobutamine, RRT, CCI_score, Platelet, RPR0))

# ---------------------------------------
# SOFA score
# ---------------------------------------

ds_sofa <- ds_cci %>%
  mutate(
    # Respiration (PaO2/FiO2)
    Respiration_Score = case_when(
      PaO2 / (FiO2/100) >= 400 ~ 0,
      PaO2 / (FiO2/100) < 400 & PaO2 / (FiO2/100) >= 300 ~ 1,
      PaO2 / (FiO2/100) < 300 & PaO2 / (FiO2/100) >= 200 ~ 2,
      PaO2 / (FiO2/100) < 200 & PaO2 / (FiO2/100) >= 100 ~ 3,
      PaO2 / (FiO2/100) < 100 ~ 4
    ),
    # Coagulation (Platelets)
    Coagulation_Score = case_when(
      Platelet >= 150 ~ 0,
      Platelet < 150 & Platelet >= 100 ~ 1,
      Platelet < 100 & Platelet >= 50 ~ 2,
      Platelet < 50 & Platelet >= 20 ~ 3,
      Platelet < 20 ~ 4
    ),
    # Liver (Bilirubin)
    Liver_Score = case_when(
      Bilirubin < 1.2 ~ 0,
      Bilirubin >= 1.2 & Bilirubin < 2.0 ~ 1,
      Bilirubin >= 2.0 & Bilirubin < 6.0 ~ 2,
      Bilirubin >= 6.0 & Bilirubin < 12.0 ~ 3,
      Bilirubin >= 12.0 ~ 4
    ),
    # Cardiovascular (MAP and Vasopressors)
    Cardiovascular_Score = case_when(
      MAP >= 70 ~ 0,
      MAP < 70 & (Dopamine <= 0 & Dobutamine <= 0 & Epinephrine <= 0 & Norepinephrine <= 0) ~ 1,  
      MAP < 70 & (Dopamine > 0 & Dopamine <= 5 | Dobutamine > 0) ~ 2, 
      MAP < 70 & (Dopamine > 5 & Dopamine <= 15 | Epinephrine <= 0.1 | Norepinephrine <= 0.1) ~ 3,  
      MAP < 70 & (Dopamine > 15 | Epinephrine > 0.1 | Norepinephrine > 0.1) ~ 4  
    ),
    # Central Nervous System (GCS)
    CNS_Score = case_when(
      GCS == 15 ~ 0,
      GCS >= 13 & GCS < 15 ~ 1,
      GCS >= 10 & GCS < 13 ~ 2,
      GCS >= 6 & GCS < 10 ~ 3,
      GCS < 6 ~ 4
    ),
    # Renal (Creatinine)
    Renal_Score = case_when(
      Creatinine < 1.2 ~ 0,
      Creatinine >= 1.2 & Creatinine < 2.0 ~ 1,
      Creatinine >= 2.0 & Creatinine < 3.5 ~ 2,
      Creatinine >= 3.5 & Creatinine < 5.0 ~ 3,
      Creatinine >= 5.0 ~ 4
    ),
    # Total SOFA Score
    sofa_score = Respiration_Score + Coagulation_Score + Liver_Score +
      Cardiovascular_Score + CNS_Score + Renal_Score
  ) %>%
  select(c(subject_id, hadm_id, admittime, dischtime, intime, outtime, deathtime, Tr, gender, anchor_age, race, admission_type, 
           Bicarbonate, BUN, Heart_rate, Hgb, Potassium, Sodium, WBC, anti_platelet, warfarin, NOAC, tPA, vaso, RRT, CCI_score, sofa_score, RPR0))

########################
## Step 6. Clean Data
########################

# Note here due to typographical error, some hospitalization discharge time/death time may happen before the ICU discharge time. 
# We prioritize ICU discharge time over hospital discharge time here, if the ICU discharge time is after the hospital discharge time, 
# it suggests the patient was still receiving critical care, so the ICU discharge time may be a more accurate indicator of the actual end of care.

# Patients with a length of stay exceeding 180 days were administratively censored at this time point to focus the analysis on clinically 
# meaningful outcomes within a typical ICU stay duration. Prolonged hospitalizations beyond 180 days represent rare, complex cases and could 
# skew results, given that the majority of ICU sepsis patients experience outcomes within this timeframe.

### Step a: Clean and process datetime variables, calculate survival and mortality information
# Outcomes: 28-day survival after ICU admission; In-hospital mortality; hospital length of stay counted from ICU admission. 
# inclusion criteria: SOFA >= 2 (No observation are removed)
ds_clean <- ds_sofa %>%
  filter(sofa_score >= 2) %>%
  mutate(
    # Adjust dischtime and death time to be equal to outtime if dischtime is before outtime
    dischtime = if_else(dischtime < outtime, outtime, dischtime),
    deathtime = if_else(!is.na(deathtime) & deathtime < outtime, outtime, deathtime),
    
    # Calculate length of stay (LOS) from ICU admission to discharge or death
    los = as.numeric(difftime(coalesce(deathtime, dischtime), intime, units = "days")),
    los = pmin(los, 180),
    
    # Define in-hospital mortality (1 if patient died during hospital stay, 0 if discharged alive)
    in_hospital_mortality = ifelse(!is.na(deathtime) & difftime(deathtime, intime, units = "days") <= 180, 1, 0),
    
    # Define 28-day outcome: Binary variable for death within 28 days
    death_within_28_days = ifelse(!is.na(deathtime) & difftime(deathtime, intime, units = "days") <= 28, 1, 0),
    
    # Define capped survival time at 28 days for 28-day survival analysis
    survival_time_28_day = pmin(los, 28)
  ) %>%
  mutate(race = ifelse(str_detect(race, regex("white", ignore_case = TRUE)), 1, 0),
         gender = ifelse(gender == "M", 1, 0),
         emergency_admission = case_when(
           admission_type %in% c('DIRECT EMER.', 'EW EMER.', 'URGENT') ~ 1,  # Emergency admissions
           admission_type %in% c('ELECTIVE', 'OBSERVATION ADMIT', 'SURGICAL SAME DAY ADMISSION') ~ 0,  # Non-emergency admissions
         )) %>%
  select(c(los, survival_time_28_day, death_within_28_days, in_hospital_mortality, Tr, 
           gender, anchor_age, race, emergency_admission, Bicarbonate, BUN, Heart_rate, Hgb, Potassium, 
           Sodium, WBC, anti_platelet, warfarin, NOAC, tPA, vaso, RRT, CCI_score, sofa_score, RPR0))

##########################################
## Step 7. Analysis of Data
##########################################

## load library
source("functions.R")
library(dplyr)
library(tidyr)
library(MASS)
library(ggplot2)
library(corrplot)
library(survival)
library(survminer)

### Understand the Structure of the Data
## read data
ds <- ds_clean

## View the first few rows
head(ds)

## Get the structure of the dataset
str(ds)

## Get summary statistics
summary(ds)

## assign names
cont_vars <- c("anchor_age", "Bicarbonate", "BUN", "Heart_rate", "Hgb", "Potassium", 
               "Sodium", "WBC", "CCI_score", "sofa_score", "RPR0") # 11 continous covariates
bin_vars <- c("gender", "race", "emergency_admission", "anti_platelet", "warfarin", "NOAC", "tPA", "vaso", "RRT") # 9 binary covariates

### Initial Inspection of Outcome Variables

# -------------------------
## continous outcome
# -------------------------

ggplot(ds, aes(x = los)) +
  geom_histogram(binwidth = 0.5, color = "blue") +
  ggtitle("Histogram of Continuous Outcome") +
  theme_minimal() # right skewed, one observation has 500+ hospitalization. For ICU settings, remove 
summary(ds$los)

# ds <- ds %>% mutate(los = log(los))

# QQ plot to assess normality
ggplot(ds, aes(sample = los)) +
  stat_qq() +
  stat_qq_line() +
  ggtitle("QQ Plot of Continuous Outcome") +
  theme_minimal()

## Outliers
ggplot(ds, aes(y = los)) +
  geom_boxplot() +
  ggtitle("Boxplot of Continuous Outcome") +
  theme_minimal()

# -------------------------
# bianry outcome 
# -------------------------

table(ds$in_hospital_mortality) 
prop.table(table(ds$in_hospital_mortality)) # class imbalance

# ------------------------------------------
# survival outcome (survival_time, death)
# ------------------------------------------

summary(ds$survival_time_28_day) # long tail, right skewed
table(ds$death_within_28_days) # nearly 57% censored observations, so mean survival time not available. 

# Fit a Kaplan-Meier model
km_fit <- survfit(Surv(survival_time_28_day, death_within_28_days) ~ Tr, data = ds)

# Plot the Kaplan-Meier curve
ggsurvplot(km_fit, data = ds, title = "Kaplan-Meier Survival Curve", xlab = "Time", 
           ylab = "Survival Probability", 
           conf.int = TRUE,
           size = 0.2) 

cox_fit <- coxph(Surv(survival_time_28_day, death_within_28_days) ~ Tr, data = ds)
cox.zph(cox_fit) # not satisfied, maybe use time dependent covariates 
plot(cox.zph(cox_fit))

cox_fit_time_dep <- coxph(Surv(survival_time_28_day, death_within_28_days) ~ Tr + tt(Tr),
                          data = ds,
                          tt = function(x, t, ...) x * t)
summary(cox_fit_time_dep)

### Initial Inspection of Continous Variables
## Boxplots for continuous variables
for (var in cont_vars) {
  p <- ggplot(ds, aes_string(y = var)) +
    geom_boxplot() +
    ggtitle(paste("Boxplot of", var)) +
    theme_minimal() +
    theme(plot.title = element_text(hjust = 0.5)) 
  
  print(p)
  
}

## Density plot for continuous variables
for (var in cont_vars) {
  p <- ggplot(ds, aes_string(x = var)) +
    geom_density(fill = "blue", alpha = 0.4) +  # Density plot with transparent fill
    ggtitle(paste("Density Plot of", var)) +
    theme_minimal() +
    theme(plot.title = element_text(hjust = 0.5))  # Center the title
  print(p)
} # WBC, BUN right skewed. 

## Create summary statistics, stratified by the treatment variable 'Tr'
ds %>%
  tbl_summary(by = Tr,  # Stratify by Tr variable
              statistic = list(all_continuous() ~ "{median} ({sd})", 
                               all_categorical() ~ "{n} ({p}%)"),
              digits = list(all_continuous() ~ 2))

## raw GSD
apply(ds[6:25], 2, function(x) GSD_wt(x, ds$Tr, 1))

ds <- ds %>%
  rename(EPR0 = RPR0)

## save data
write.csv(ds, "MIMIC_EPR.csv", row.names = FALSE)

# -----------------------------------------------------------------

## read data
ds <- read.csv("MIMIC_EPR.csv", header = TRUE)
ds <- ds %>%
  mutate(los = log(los))

bin_vars <- c("gender", "race", "emergency_admission", "anti_platelet", "warfarin", "NOAC", "tPA", "vaso", "RRT") # 9 binary covariates
prop_bin <- sapply(ds[, bin_vars], function(x) mean(x))
cor_bin <- cor(ds[, bin_vars]) ## check correlation --- no high correlations

cont_vars <- c("anchor_age", "Bicarbonate", "BUN", "Heart_rate", "Hgb", "Potassium", 
               "Sodium", "WBC", "CCI_score", "sofa_score", "EPR0") # 11 continous covariates

for (var in cont_vars) {
  p <- ggplot(ds, aes_string(x = var)) +
    geom_density(fill = "blue", alpha = 0.4) +  # Density plot with transparent fill
    ggtitle(paste("Density Plot of", var)) +
    theme_minimal() +
    theme(plot.title = element_text(hjust = 0.5))  # Center the title
  print(p)
} # BUN, WBC, RPR0 has skewness

summary_cont <- sapply(ds[, cont_vars], function(x) {
  
  c(mean = mean(x), sd = sd(x))
  
}) # age, heart rate, BUN, WBC have large variance

cor_cont <- cor(ds[, cont_vars])
cor_high <- as.data.frame(as.table(cor_cont)) %>%
  filter(Var1 != Var2, abs(Freq) > 0.5) ## CCI_scores and age have high correlation in between (>0.5)

## Fit the propensity score model using standardized the continuous variable
ds_ps <- cbind(Tr = ds$Tr, ds[, cont_vars], ds[, bin_vars])
ps_model_fit <- glm(Tr ~., data = ds_ps, family = binomial)
summary(ps_model_fit)
ps_model_coef <- coef(ps_model_fit)

## test for heterogeneous effect
## Fit the model with interactions between Tr and all covariates
ds_temp <- ds %>% dplyr::select(-c(survival_time_28_day, death_within_28_days, in_hospital_mortality))
out_het_model <- lm(los ~ Tr * ., data = ds_temp)
summary(out_het_model)
coefficients_het <- summary(out_het_model)$coefficients
interaction_rows <- grep("Tr:", rownames(coefficients_het))
interaction_p_values <- coefficients_het[interaction_rows, 4]
p_adjusted <- p.adjust(interaction_p_values, method = "fdr")
round(p_adjusted, 4) # no heterogeneous effect detected after adjust for multiplicity.
# Tr:Bicarbonate < 0.05, heterogeneous effect exist without considering multiplicity.

## Fit the outcome model
out_model_fit <- lm(los ~ ., data = ds_temp)
summary(out_model_fit)
out_model_coef <- coef(out_model_fit)
r_square <- summary(out_model_fit)$r.squared # 0.11
var_tr <- var(ds$Tr) # 0.24
X_out <- as.matrix(cbind(Intercept = 1, ds[, !(colnames(ds) %in% c("Tr", "los", "survival_time_28_day", "death_within_28_days", "in_hospital_mortality"))]))
beta_coef <- out_model_coef[-2]
var_cov <- var(X_out %*% beta_coef) # 0.025 
var_residuals <- var(residuals(out_model_fit)) # 0.48
var_los <- var(ds$los) # 0.51
## Sigma ratio
sigma_ratio_tr <- var_tr/var_residuals # 0.51
sigma_ratio_cov <- var_cov/var_residuals # 0.05

## Non-linearity
library(ggplot2)
library(patchwork)
library(dplyr)
library(mgcv)

# List of variables to plot (selected variables for illustration purpose)
variables <- c("Hgb", "Potassium", "WBC", "EPR0")

# Initialize an empty list to store plots
plot_list <- list()

ds0 <- ds
# Loop through the variables and generate individual logit plots
for (var in variables) {
  ds0[[var]] <- sqrt(ds0[[var]])
  
  # Fit the GAM model on the log-odds scale
  formula <- as.formula(paste("Tr ~ s(", var, ", bs = 'cs')"))
  gam_model <- gam(formula, data = ds0, family = binomial(link = "logit"))
  
  # Create new data for predictions
  new_data <- data.frame(
    x = seq(min(ds0[[var]], na.rm = TRUE), max(ds0[[var]], na.rm = TRUE), length.out = 200)
  )
  colnames(new_data) <- var  # Ensure correct column name
  
  # Predict log-odds and confidence intervals
  preds <- predict(gam_model, newdata = new_data, type = "link", se.fit = TRUE)
  
  # Add predictions to the new data
  new_data$log_odds <- preds$fit
  new_data$upper <- preds$fit + 1.96 * preds$se.fit  # Upper CI
  new_data$lower <- preds$fit - 1.96 * preds$se.fit  # Lower CI
  
  # Create binned data for log-odds
  binned_data <- ds0 %>%
    mutate(bin = ntile(!!sym(var), 10)) %>%  # Create 10 bins
    group_by(bin) %>%
    summarize(
      mean_var = mean(!!sym(var), na.rm = TRUE),  # Mean value of the variable in each bin
      prop = mean(Tr, na.rm = TRUE)  # Proportion of Tr = 1 in each bin
    ) %>%
    filter(prop > 0 & prop < 1) %>%  # Remove bins with proportions of 0 or 1
    mutate(logit = log(prop / (1 - prop)))  # Compute logit (log-odds)
  
  # Plot the log-odds with confidence intervals and binned points
  p <- ggplot(new_data, aes_string(x = var, y = "log_odds")) +
    geom_line(color = "blue", size = 1) +  # Smooth log-odds curve
    geom_ribbon(aes(ymin = lower, ymax = upper), fill = "blue", alpha = 0.2) +  # Confidence intervals
    geom_point(
      data = binned_data,
      aes(x = mean_var, y = logit), 
      color = "black", 
      size = 2
    ) +  # Add binned points
    labs(
      x = paste("sqrt(", var, ")", sep = ""),
      y = "Log-Odds"
    ) +
    theme_minimal() +
    theme(plot.title = element_text(hjust = 0.5))
  
  # Add the plot to the list
  plot_list[[var]] <- p
}

# Combine the plots into a 2x2 grid using patchwork
combined_plot <- (plot_list[["Hgb"]] + plot_list[["Potassium"]]) /
  (plot_list[["WBC"]] + plot_list[["RPR0"]])  & 
  theme(
    axis.title = element_text(size = 20),
    axis.text = element_text(size = 20),
    text = element_text(size = 20) 
  )

# Display the combined plot
print(combined_plot)

ggsave("mimic_log_plot_figure.pdf", plot = combined_plot, width = 12, height = 8, device = "pdf", family = "Times")

