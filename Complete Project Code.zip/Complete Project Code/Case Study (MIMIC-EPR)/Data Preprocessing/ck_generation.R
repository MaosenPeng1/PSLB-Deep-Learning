ds <- read.csv("MIMIC_EPR.csv", header = TRUE)
source('functions.R')

## data simulation
log.fit <-  glm(Tr~., data = ds[,5:25], family = 'binomial')
ps <- log.fit$fitted.values
rho <- 0.15
ck <- seq(0.01, 0.99, 0.01)
h <- span_to_bandwidth(rho, ck, ps)
input <- data.frame(ck=ck, h=h)
write.csv(input, paste0("ck_h.csv"), row.names = FALSE)
