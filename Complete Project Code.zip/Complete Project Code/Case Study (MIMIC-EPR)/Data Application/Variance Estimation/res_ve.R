## LBC_Net
library(dplyr)
library(pracma)
library(survival)
library(survminer)
source("functions.R")

## load data
s <- 1:500
file <- paste0("data", s, ".csv")
data_list <- lapply(file, read.csv, header = TRUE)
p <- 20
n <- length(s)

file_ps <- paste0("ps_lbc_net_", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_lbc_net <- do.call(cbind, ps_list)

file_ps <- paste0("ps_nn", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_nn <- do.call(cbind, ps_list)

file_wt <- paste0("wt_cbipm", s, ".csv")
wt_list <- lapply(file_wt, read.csv, header = FALSE, skip = 1)
wt_cbipm <- do.call(cbind, wt_list)

other_methods <- readRDS("other_methods_ve.rds")

## Variance estimation
lbc_net_sd <- Model_based_ve(ps_lbc_net)
nn_sd <- Model_based_ve(ps_nn)
cbipm_sd <- Weight_based_ve(wt_cbipm, 1)

res <- data.frame(logistic = c(other_methods$logistic_sd$los_sd, other_methods$logistic_sd$in_hospital_mortality_sd, other_methods$logistic_sd$HR_sd),
                  cbipm = c(cbipm_sd$los_sd, cbipm_sd$in_hospital_mortality_sd, cbipm_sd$HR_sd),
                  sbw = c(other_methods$sbw_sd$los_sd, other_methods$sbw_sd$in_hospital_mortality_sd, other_methods$sbw_sd$HR_sd),
                  cbps = c(other_methods$cbps_sd$los_sd, other_methods$cbps_sd$in_hospital_mortality_sd, other_methods$cbps_sd$HR_sd),
                  nn = c(nn_sd$los_sd, nn_sd$in_hospital_mortality_sd, nn_sd$HR_sd),
                  lbc_net = c(lbc_net_sd$los_sd, lbc_net_sd$in_hospital_mortality_sd, lbc_net_sd$HR_sd))

saveRDS(res, "ve.rds")
