ds <- read.csv("MIMIC_EPR.csv", header = TRUE)
source('functions.R')

set.seed(100)
n_bootstraps <- 500

# Bootstrap loop
for (i in 1:n_bootstraps) {
  
  # Sample with replacement from 'ds
  ds_boots <- ds[sample(nrow(ds), replace = TRUE), ]
  
  ## data simulation
  log.fit =  glm(Tr~., data = ds_boots[,5:25], family = 'binomial')
  ps = log.fit$fitted.values
  
  ## ck and adaptive h
  rho <- 0.15
  ck <- seq(0.01, 0.99, 0.01)
  h <- span_to_bandwidth(rho, ck, ps)
  input <- data.frame(ck=ck, h=h)
  write.csv(input, paste0("ck_h", i, ".csv"), row.names = FALSE)
  
  file_name <- paste0("data", i, ".csv")
  write.csv(ds_boots, file_name, row.names = FALSE)
  
}



