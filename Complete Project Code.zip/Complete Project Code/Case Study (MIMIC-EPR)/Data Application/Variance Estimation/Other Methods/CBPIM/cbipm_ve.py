import numpy as np
import pandas as pd
import random
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import StandardScaler
import sys, os

from functions_cbipm import * 

import argparse
parser = argparse.ArgumentParser(description='PyTorch Covariate Balancing IPM for the ATE')

### for dataset 
parser.add_argument('--seed', type=int, default= 1000, help='the number of seeds')

### for w modeling
parser.add_argument('--model', type=str, default= 'Nonpara', choices=['Linear', 'Nonpara'], help='Model for weights')

### for IPM
parser.add_argument('--IPM', type=str, default= 'MMD', choices=['WASS', 'SIPM', 'MMD'], help='IPM class')

### for training
parser.add_argument('--gpu', default=0, type=int, help='id(s) for CUDA_VISIBLE_DEVICES')
parser.add_argument('--epoch', type=int, default= 1000)
parser.add_argument('--lr', default=0.03, type=float, help='initial learning rate for w')

parser.add_argument('--optim_adv', type=str, default= 'Adam', choices=['SGD', 'Adam'], help='optimizer for adv')
parser.add_argument('--epoch_adv', type=int, default= 5)
parser.add_argument('--lr_adv', default=0.3, type=float, help='initial learning rate for sipm')

# Only for WASS distance
parser.add_argument('--tau', type=float, default= 0.3, help='tau for gradient penalty of WASS')
parser.add_argument('--R', type=int, default= 100, help='number of samples for interpolate points')
parser.add_argument('--cutoff', type=float, default= 0.1, help='cutoff for WASS')

# Only for SIPM
parser.add_argument('--n_SIPM', type=int, default= 100, help='the number of sigmoid functions')

args = parser.parse_args()
print(args)
seed = args.seed
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
if torch.cuda.is_available():
    torch.cuda.set_device(args.gpu)

def main():    
    
    ATE_0_list = []
    
    np.random.seed(seed)
    random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(100) 
        torch.cuda.manual_seed_all(100)
        torch.backends.cudnn.deterministic = True

############################data upload###############################
    ## load data
    filename = f"data{seed}.csv"
    df = pd.read_csv(filename, delimiter=',')

    X = np.array(df)[:,5:]
    std = StandardScaler()
    X_std = std.fit_transform(X)
    n, d= X.shape

    treatment = np.array(df)[:,4]
    idx = np.where(treatment==1)[0]
    y_0 = np.array(df)[:,0]

    X_all = torch.tensor(X_std).float()
    X_c = torch.tensor(np.delete(X_std,idx,axis=0)).float()
    X_t = torch.tensor(X_std[idx,:]).float()
    n_0, n_1 = len(X_c), len(X_t)
    weight = np.empty(len(X_std))

##################################################################    
    if args.model=='Nonpara':
        v = wNonpara_(n_1)
        w = wNonpara_(n_0)           
    elif args.model=='Linear':
        v = wlinear_ATE_(d,n,n_1) ## treatment
        w = wlinear_ATE_(d,n,n_0) ## control
        
    if args.IPM == "WASS":
        adv_v =  WASS_(d)
        adv_w =  WASS_(d)
        clipper = weightConstraint(args.cutoff)
    elif args.IPM == "SIPM":
        adv_v = para_sigmoid_(d,args.n_SIPM)
        adv_w = para_sigmoid_(d,args.n_SIPM)
    elif args.IPM == "MMD":
        adv_v = None
        adv_w = None            
        
    optimizer_v = optim.Adam(v.parameters(), lr=args.lr)
    optimizer_w = optim.Adam(w.parameters(), lr=args.lr)

    if args.IPM != "MMD":
        if args.optim_adv == "SGD":
            optimizer_adv_v = optim.SGD(adv_v.parameters(), lr=args.lr_adv, momentum=0.9, weight_decay=5e-4)
            optimizer_adv_w = optim.SGD(adv_w.parameters(), lr=args.lr_adv, momentum=0.9, weight_decay=5e-4)
        elif args.optim_adv == "Adam":    
            optimizer_adv_v = optim.Adam(adv_v.parameters(), lr=args.lr_adv)
            optimizer_adv_w = optim.Adam(adv_w.parameters(), lr=args.lr_adv)

    for epoch in range(args.epoch):
        if args.IPM != "MMD":   
            for epoch_adv in range(args.epoch_adv):
                loss_adv = -loss_adv_(args.IPM, X_t, X_all, v, adv_v)
                optimizer_adv_v.zero_grad()
                loss_adv.backward()
                optimizer_adv_v.step()
                if args.IPM == "WASS":
                    adv_v.apply(clipper)
                
        loss = loss_(args.IPM, X_t, X_all, v, adv_v)
        optimizer_v.zero_grad()
        loss.backward()
        optimizer_v.step()            
    v_IPM = v.weight(X_t).detach().cpu().numpy()
        
    for epoch in range(args.epoch):
        if args.IPM != "MMD":   
            for epoch_adv in range(args.epoch_adv):
                loss_adv = -loss_adv_(args.IPM, X_c, X_all, w, adv_w)
                optimizer_adv_w.zero_grad()
                loss_adv.backward()
                optimizer_adv_w.step()
                if args.IPM == "WASS":
                    adv_w.apply(clipper)
                
        loss = loss_(args.IPM, X_c, X_all, w, adv_w)
        optimizer_w.zero_grad()
        loss.backward()
        optimizer_w.step()
    w_IPM = w.weight(X_c).detach().cpu().numpy()    

    weight[idx] = v_IPM   
    weight[np.delete(np.arange(len(X_std)),idx)] = w_IPM
    
    pd.DataFrame(weight).to_csv(f"wt_cbipm{seed}.csv" , index=False) 
 
if __name__ == '__main__':
    main()
