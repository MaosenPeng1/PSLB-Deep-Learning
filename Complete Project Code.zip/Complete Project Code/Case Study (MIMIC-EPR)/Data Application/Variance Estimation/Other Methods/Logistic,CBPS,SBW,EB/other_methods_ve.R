library(CBPS)
library(ebal)
library(sbw)
library(dplyr)
library(foreach)
library(doParallel)
library(pracma)
library(survival)
library(survminer)
source("functions.R")

s <- 1:500
file <- paste0("data", s, ".csv")
data_list <- lapply(file, read.csv, header = TRUE)
p <- 20
n <- length(s)
registerDoParallel(cores = detectCores())

###################################
## Logistic regression
###################################
logistic_model <- function(data){
  
  logistic.fit <- glm(Tr~., data = data[,5:25], family = 'binomial')
  return(logistic.fit$fitted.values)
  
}

ps_log <- foreach(data = data_list, .combine = cbind) %dopar% {
  
  logistic_model(data)
  
}

#####################################
## CBPS
#####################################
CBPS_model <- function(data){
  
  cbps.fit <- CBPS(Tr~., data = data[,5:25], method = 'exact', ATT = 0, twostep = FALSE)
  return(cbps.fit$fitted.values)
  
}

# Run the CBPS models in parallel
ps_cbps <- foreach(data = data_list, .combine = cbind) %dopar% {
  
  CBPS_model(data)
  
}

#####################################
## EB
#####################################
eb_model_att <- function(data, Y){
  
  X <- data[,6:25]
  Z <- data[,5]
  wt_att <- rep(NA, nrow(data))
  
  eb.att.fit <- ebalance(Treatment=Z,
                         X=X)
  wt_att[Z==1] <- rep(1, sum(Z))
  wt_att[Z==0] <- eb.att.fit$w
  
  return(wt_att)
  
}

wt_att <- foreach(data = data_list, .combine = cbind) %dopar% {
  
  eb_model_att(data, data[,1])
  
}

eb_model_atc <- function(data, Y){
  
  X <- data[,6:25]
  Z <- data[,5]
  wt_atc <- rep(NA, nrow(data))
  
  eb.atc.fit <- ebalance(Treatment=1-Z,
                         X=X)
  wt_atc[Z==0] <- rep(1, sum(1-Z))
  wt_atc[Z==1] <- eb.atc.fit$w
  
  return(wt_atc)
  
}

wt_atc <- foreach(data = data_list, .combine = cbind) %dopar% {
  
  eb_model_atc(data, data[,1])
  
}

wt_eb <- list(wt_att = wt_att, wt_atc = wt_atc)

#####################################
## SBW
#####################################
sbw_model <- function(data){
  
  ds_cont <- data %>% 
    select(-c(survival_time_28_day, death_within_28_days, in_hospital_mortality))
  
  bal <- list()
  bal$bal_cov <- colnames(ds_cont[,3:22])
  bal$bal_tol <- 0.02
  bal$bal_std <- "group"
  
  sbw.fit <- sbw(ds_cont, 
                 ind = "Tr",
                 out = "los",
                 bal = bal,
                 sol = list(sol_nam = "quadprog"),
                 par = list(par_est = "ate"), 
                 mes = FALSE)
  return(sbw.fit$dat_weights$sbw_weights)
  
}

wt_sbw <- foreach(data = data_list, .combine = cbind, .packages = c('dplyr', 'sbw')) %dopar% {
  
  sbw_model(data)
  
}


res_sd <- list(logistic_sd = Model_based_ve(ps_log),
               cbps_sd = Model_based_ve(ps_cbps),
               eb_sd = Weight_based_ve(wt_eb, 2),
               sbw_sd = Weight_based_ve(wt_sbw, 1))

saveRDS(res_sd, "other_methods_ve.rds")









