import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import pandas as pd
import argparse
import time

parser = argparse.ArgumentParser(description='NN Estimation')

## for model
parser.add_argument('--seed', type=int, default=1)
parser.add_argument('--hidden_dim', type=int, default=10, help='hidden dimension (default: 10)')
parser.add_argument('--epochs', type=int, default=150, help='number of epochs to train (default: 150)')
parser.add_argument('--lr', type=float, default=0.05, help='learning rate (default: 0.01)')

args = parser.parse_args()
print(args)

class PropensityNetwork(nn.Module):
    def __init__(self, input_dim, hidden_dim):
        super(PropensityNetwork, self).__init__()
        self.layer1 = nn.Linear(input_dim, hidden_dim)
        self.relu = nn.ReLU()
        self.layer2 = nn.Linear(hidden_dim, 1)
        self.sigmoid = nn.Sigmoid()
    
    def forward(self, x):
        x = self.layer1(x)
        x = self.relu(x)
        x = self.layer2(x)
        x = self.sigmoid(x) 
        return x

def main():
    start_time = time.time()
    ## load data
    filename = f"data{args.seed}.csv"
    data = pd.read_csv(filename, delimiter=',')

    ## set seed
    torch.manual_seed(100)  ## Choose any number you prefer, here we use 100

    Z = data.iloc[:, 5:].values ## correctly spesified proepnsity score covariates
    T = data.iloc[:, 4].values
    n, p = Z.shape
    
    Z_norm = (Z - Z.mean(axis=0)) / Z.std(axis=0) ## Normalization
    Z_norm = torch.tensor(Z_norm, dtype=torch.float32)
    T = torch.tensor(T, dtype=torch.float32)

    ps_model = PropensityNetwork(p, args.hidden_dim)
    criterion = nn.BCELoss()
    optimizer = optim.Adam(ps_model.parameters(), lr=args.lr, weight_decay=1e-5)
    
    best_loss = float('inf')
    patience = 10  # Number of epochs to wait for improvement
    min_delta = 1e-4  # Minimum change in loss to qualify as improvement
    wait = 0  # Counter for epochs without significant improvement
    for epoch in range(args.epochs):
        
        ps_model.train()
        optimizer.zero_grad()
        outputs = ps_model(Z_norm).squeeze()
        loss = criterion(outputs, T)
        loss.backward()
        optimizer.step()

        # Check for improvement
        if loss.item() < best_loss - min_delta:
            best_loss = loss.item()
            wait = 0  # Reset the patience counter
        else:
            wait += 1  # Increment the counter
        
        print(f"Epoch {epoch + 1}/{args.epochs}, Loss: {loss.item():.4f}")
    
        if wait >= patience:
            print("Convergence detected. Stopping training.")
            break

    ps_model.eval()   
    with torch.no_grad():  # Disable gradient computation for inference
        ps = ps_model(Z_norm).squeeze().detach().cpu().numpy()  
    df = pd.DataFrame(data=ps)
    df.to_csv(f"ps_nn{args.seed}.csv", index=False, header=False)

    end_time = time.time()
    execution_time = end_time - start_time
    print(f"Execution time is: {execution_time} seconds")

if __name__ == "__main__":
    main()


