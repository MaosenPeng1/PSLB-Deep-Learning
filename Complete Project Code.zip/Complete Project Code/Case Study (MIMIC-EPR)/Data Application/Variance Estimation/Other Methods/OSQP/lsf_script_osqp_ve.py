import os

def create_lsf_content():
    content = f"""#BSUB -J osqp_job
#BSUB -W 3:00
#BSUB -o /path/to/log/osqp.out
#BSUB -e /path/to/log/osqp.err
#BSUB -cwd /path/to/working_directory
#BSUB -q e80short
#BSUB -u your_email@example.com
#BSUB -n 28
#BSUB -M 40
#BSUB -R rusage[mem=40]

module load R 

Rscript /path/to/working_directory/osqp_ve.R 
"""
    return content

output_dir = '/path/to/working_directory'

lsf_content = create_lsf_content()
with open(os.path.join(output_dir, f'osqp.lsf'), 'w') as lsf_file:
    lsf_file.write(lsf_content)

