import os

def create_lsf_content(seed, queue_name, model, IPM, gpu, epoch, lr, optim_adv, epoch_adv, lr_adv, tau, R, cutoff, n_SIPM):
    content = f"""#BSUB -J cbipm_job
#BSUB -W 3:00
#BSUB -o /path/to/log/cbipm.out
#BSUB -e /path/to/log/cbipm.err
#BSUB -cwd /path/to/working_directory
#BSUB -q {queue_name}
#BSUB -u your_email@example.com
#BSUB -n 1
#BSUB -M 6
#BSUB -R rusage[mem=6]

module load python

python /path/to/working_directory/cbipm.py --seed {seed} --model {model} --IPM {IPM} --gpu {gpu} --epoch {epoch} --lr {lr} --optim_adv {optim_adv} --epoch_adv {epoch_adv} --lr_adv {lr_adv} --tau {tau} --R {R} --cutoff {cutoff} --n_SIPM {n_SIPM} 

"""
    return content

# Set the arguments for the Python script
output_dir = '/path/to/working_directory'

model = 'Nonpara' ## ['Linear', 'Nonpara']
IPM = 'WASS' ## ['WASS', 'SIPM', 'MMD']
gpu = 0
epoch = 1000
lr = 0.03
optim_adv = 'Adam' ## ['SGD', 'Adam']
epoch_adv = 5
lr_adv = 0.3
tau = 0.3
R = 100
cutoff = 0.1
n_SIPM = 100
seed = 100
queue_name = "short"

lsf_content = create_lsf_content(seed, queue_name, model, IPM, gpu, epoch, lr, optim_adv, epoch_adv, lr_adv, tau, R, cutoff, n_SIPM)
with open(os.path.join(output_dir, f'cbipm_job.lsf'), 'w') as lsf_file:
    lsf_file.write(lsf_content)
