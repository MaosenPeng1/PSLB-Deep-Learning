library(CBPS)
library(ebal)
library(sbw)
library(dplyr)
source("functions.R")
file <- paste0("MIMIC_EPR.csv")
ds <- read.csv(file, header = TRUE)
X <- ds[,6:25]
Z <- ds[,5]

###################################
## Logistic regression
###################################
logistic.fit <- glm(Tr~., data = ds[,5:25], family = 'binomial')
ps_log <- logistic.fit$fitted.values
write.csv(ps_log, file = "ps_log.csv", row.names = FALSE)

#####################################
## CBPS
#####################################
cbps.fit <- CBPS(Tr~., data = ds[,5:25], method = 'exact', ATT = 0, twostep = FALSE)
ps_cbps <- cbps.fit$fitted.values
write.csv(ps_cbps, file = "ps_cbps.csv", row.names = FALSE)  

#####################################
## EB
#####################################
wt_att <- wt_atc <- rep(NA, nrow(ds))
eb.att.fit <- ebalance(Treatment=Z,
                       X=X)
wt_att[Z==1] <- rep(1, sum(Z))
wt_att[Z==0] <- eb.att.fit$w

eb.atc.fit <- ebalance(Treatment=1-Z,
                       X=X)
wt_atc[Z==0] <- rep(1, sum(1-Z))
wt_atc[Z==1] <- eb.atc.fit$w

wt_eb <- data.frame(wt_att = wt_att, wt_atc = wt_atc)
write.csv(wt_eb, file = "wt_eb.csv", row.names = FALSE)

#####################################
## SBW
#####################################
ds_cont <- ds %>% select(-c(survival_time_28_day, death_within_28_days, in_hospital_mortality))

bal <- list()
bal$bal_cov <- colnames(ds_cont[,3:22])
bal$bal_tol <- 0.02
bal$bal_std <- "group"

sbw.fit <- sbw(ds_cont, 
               ind = "Tr",
               out = "los",
               bal = bal,
               sol = list(sol_nam = "quadprog"),
               par = list(par_est = "ate"), 
               mes = FALSE)
wt_sbw <- sbw.fit$dat_weights$sbw_weights
write.csv(wt_sbw, file = "wt_sbw.csv", row.names = FALSE)












