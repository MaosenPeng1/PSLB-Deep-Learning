import os

def create_lsf_content(lr, queue_name, hidden_dim, epochs):
    content = f"""#BSUB -J nn_job
#BSUB -W 3:00
#BSUB -o /path/to/log/nn.out
#BSUB -e /path/to/log/nn.err
#BSUB -cwd /path/to/working_directory
#BSUB -q {queue_name}
#BSUB -u your_email@example.com
#BSUB -n 1
#BSUB -M 6
#BSUB -R rusage[mem=6]

module load python

python /path/to/working_directory/nn.py --epochs {epochs} --lr {lr} --hidden_dim {hidden_dim}

"""
    return content

# Set the arguments for the Python script
output_dir = '/path/to/working_directory'
epochs = 250
lr = 0.01
hidden_dim = 10
queue_name = "short"

lsf_content = create_lsf_content(lr, queue_name, hidden_dim, epochs)
with open(os.path.join(output_dir, 'nn_job.lsf'), 'w') as lsf_file:
    lsf_file.write(lsf_content)
