#####################################################################################  
#        R function for fast OSQP-based kernel SBW with Nystrom approximation       #                
#        by Kwhangho Kim (kkim@hcp.med.harvard.edu)                                 #
#        https://arxiv.org/abs/2311.00568                                           #
#####################################################################################

library(Matrix)
library(MASS)
library(matrixStats)
library(osqp)
library(RSpectra)
library(RcppParallel)
library(Rcpp)
library(RcppArmadillo)
library(survival)
library(survminer)
library(dplyr)
library(pracma)

sourceCpp('RBF_kernel_C_parallel.cpp')
source("utils.R")

p <- 20

## n = 5000 -> c = 100, l=75, s=50
## n = 1000 -> c = 20, l=15, s=10
ds <- read.csv("MIMIC_EPR.csv", header = TRUE)

n <- nrow(ds)

opqs_model_att <- function(data){
  
  X <- data[,6:25]
  Z <- data[,5]
  Y <- data[,1]
  wt <- rep(NA, n)
  
  # X_ <- kernel.basis(X,Z,Y,
  #                    kernel.approximation=TRUE,
  #                    dim.reduction=TRUE,
  #                    c = 100, l=75, s=50)
  # 
  # high.acc.setting <- osqpSettings(alpha = 1.5, verbose = FALSE, 
  #                                  warm_start = TRUE, # use warm start when you iterate over multiple deltas
  #                                  polish=TRUE,# solution polishing  
  #                                  eps_abs = 5e-5, # use more strict absolute tolerance if needed
  #                                  eps_rel = 5e-5 # use more strict relative tolerance if needed
  # ) 
  # 
  # delta.v <- seq(0.0005, 0.01, by=0.0005)
  # opqs.fit <- osqp_kernel_sbw(X,Z,Y, 
  #                             delta.v=delta.v, X_=X_,
  #                             osqp.setting=high.acc.setting)
  opqs.fit <- osqp_kernel_sbw(X,Z,Y,
                         delta.v=1e-4,
                         dim.reduction=TRUE,
                         c = 100, l=75, s=50)
  wt[Z==1] <- rep(1, sum(Z))
  wt[Z==0] <- opqs.fit[[1]]$w
  wt[wt < 0] <- 0
  
  return(wt)
  
}

wt_att <- opqs_model_att(ds)

opqs_model_atc <- function(data){
  
  X <- data[,6:25]
  Z <- data[,5]
  Y <- data[,1]
  wt <- rep(NA, n)
  
  # X_ <- kernel.basis(X,1-Z,Y,
  #                    kernel.approximation=TRUE,
  #                    dim.reduction=TRUE,
  #                    c = 100, l=75, s=50)
  # 
  # high.acc.setting <- osqpSettings(alpha = 1.5, verbose = FALSE, 
  #                                  warm_start = TRUE, # use warm start when you iterate over multiple deltas
  #                                  polish=TRUE,# solution polishing  
  #                                  eps_abs = 5e-5, # use more strict absolute tolerance if needed
  #                                  eps_rel = 5e-5 # use more strict relative tolerance if needed
  # ) 
  # 
  # opqs.fit <- osqp_kernel_sbw(X,1-Z,Y, 
  #                             delta.v=1e-4, X_=X_,
  #                             osqp.setting=high.acc.setting,
  #                             dim.reduction=TRUE,
  #                             c = 100, l=75, s=50)
  opqs.fit <- osqp_kernel_sbw(X,1-Z,Y,
                              delta.v=1e-4,
                              dim.reduction=TRUE,
                              c = 100, l=75, s=50)
  wt[Z==0] <- rep(1, sum(1-Z))
  wt[Z==1] <- opqs.fit[[1]]$w
  wt[wt < 0] <- 0
  
  return(wt)
  
}

wt_atc <- opqs_model_atc(ds)

wt_osqp <- data.frame(wt_att = wt_att, wt_atc = wt_atc)
write.csv(wt_osqp, file = "wt_osqp.csv", row.names = FALSE)  
