library(survival)
library(dplyr)
library(ggplot2)
library(splines)

source("functions.R")
file <- paste0("MIMIC_RPR.csv")
ds <- read.csv(file, header = TRUE)
ds <- ds %>% dplyr::select(-c(los, in_hospital_mortality))
sd_res <- readRDS("sd_beta.rds")

## load propensity scores
ps_temp <- read.csv("ps_lbc_net.csv", header = FALSE)
ps_lbc_net <- ps_temp[,1]

time <- seq(3, 28, by = 0.1)
knots <- c(6.5, 10, 15)

cox_fit_time_dep <- coxph(
  Surv(survival_time_28_day, death_within_28_days) ~ Tr + tt(Tr),
  data = ds,
  tt = function(x, t, ...) x * nsk(t, knots = knots, Boundary.knots = FALSE),  
  robust = TRUE
)

coef_all <- coef(cox_fit_time_dep)
coef_tr <- coef_all["Tr"]
coef_tt <- coef_all[-1]
spline_basis <- nsk(time, knots = knots, Boundary.knots = FALSE)
beta_t_unweighted <- coef_tr + rowSums(sweep(spline_basis, 2, coef_tt, FUN = "*"))

## Weighted by LBC-Net
wt <- ipw(ds$Tr, ps_lbc_net)
cox_fit_time_dep <- coxph(
  Surv(survival_time_28_day, death_within_28_days) ~ Tr + tt(Tr),
  data = ds,
  tt = function(x, t, ...) x * nsk(t, knots = knots, Boundary.knots = FALSE),  
  robust = TRUE,
  weight = wt
)

coef_all <- coef(cox_fit_time_dep)
coef_tr <- coef_all["Tr"]
coef_tt <- coef_all[-1]
spline_basis <- nsk(time, knots = knots, Boundary.knots = FALSE)
beta_t_weighted_lbc_net <- coef_tr + rowSums(sweep(spline_basis, 2, coef_tt, FUN = "*"))

# Combine into a data frame
# Extract standard deviations from the list
sd_unwt <- sd_res$sd_unwt
sd_wt_lbc_net <- sd_res$sd_wt_lbc_net

# Calculate confidence intervals for each method
HR_lower_unweighted <- exp(beta_t_unweighted - 1.96 * sd_unwt)
HR_upper_unweighted <- exp(beta_t_unweighted + 1.96 * sd_unwt)

HR_lower_weighted_lbc_net <- exp(beta_t_weighted_lbc_net - 1.96 * sd_wt_lbc_net)
HR_upper_weighted_lbc_net <- exp(beta_t_weighted_lbc_net + 1.96 * sd_wt_lbc_net)

# Create data frames for the hazard ratios and confidence intervals
df_estimates <- data.frame(
  Time = rep(time, 2),
  Hazard_Ratio = c(HR_t_unweighted, HR_t_weighted_lbc_net),
  Model = rep(c("Unweighted", "Weighted (LBC-Net)"), each = length(time))
)

df_ci <- data.frame(
  Time = rep(time, 2),
  Lower = c(HR_lower_unweighted, HR_lower_weighted_lbc_net),
  Upper = c(HR_upper_unweighted, HR_upper_weighted_lbc_net),
  Model = rep(c("Unweighted", "Weighted (LBC-Net)"), each = length(time))
)

p <- ggplot() +
  # Shaded confidence intervals
  geom_ribbon(data = df_ci, aes(x = Time, ymin = Lower, ymax = Upper, fill = Model), alpha = 0.2) +
  # Hazard ratio estimates with different line types
  geom_line(data = df_estimates, aes(x = Time, y = Hazard_Ratio, color = Model), size = 1) +
  labs(
    x = "Time (days)",
    y = "Hazard Ratio"
  ) +
  # Custom colors for lines and shaded areas
  scale_color_manual(values = c("#E69F00", "#56B4E9")) +
  scale_fill_manual(values = c("#E69F00", "#56B4E9")) +
  # Custom line types
  # scale_linetype_manual(values = c("solid", "dashed")) +
  scale_x_continuous(
    breaks = seq(3, 28, by = 5),  # Specify breaks from 3 to 28 in intervals of 5
    limits = c(3, 28)             # Ensure the x-axis range is constrained to 3–28
  ) +
  theme_bw(base_size = 20) +
  theme(
    legend.position = "bottom",
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.title = element_text(size = 20),
    axis.text = element_text(size = 20),
    legend.text = element_text(size = 20),
    legend.title = element_text(size = 20)
  )

library(gridExtra)
library(cowplot)
library(textables)
library(grid)

surv_obj <- survfit(Surv(survival_time_28_day, death_within_28_days) ~ 1, data = ds)
at_risk_unweighted <- surv_obj$n.risk  # Number of individuals at risk at each time point
time_points <- surv_obj$time           # Corresponding time points

# Create a custom risk table with a single "At Risk" column
risk_table <- data.frame(
  Time = time_points,
  At_Risk = at_risk_unweighted
)

quantiles <- quantile(risk_table$Time, probs = c(0, 0.1, 0.25, 0.5, 0.75, 1))
risk_table_filtered <- risk_table %>%
  slice(sapply(quantiles, function(q) which.min(abs(Time - q)))) %>%
  mutate(Time = round(Time)) 

tab <- TR("Time") %:% with(risk_table_filtered, TR(Time)) +
  midrule() +
  TR("Number at Risk") %:% with(risk_table_filtered, TR(At_Risk))  

# Print the table to a text variable
text_output <- capture.output(print(tab))

# Write the text output to a file
writeLines(text_output, "table_output.txt")

library(magick)
p_risk_table <- image_read("risk_table.PNG")
table_grob <- rasterGrob(as.raster(p_risk_table), interpolate = TRUE)

combined_plot <- plot_grid(
  p, table_grob,
  ncol = 1,
  rel_heights = c(5, 1)  # Adjust height ratio
)

ggsave("mimic_hr_figure.pdf", plot = combined_plot, width = 10, height = 8, device = "pdf", family = "Times")
