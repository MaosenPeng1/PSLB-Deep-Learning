library(survival)
library(dplyr)
library(ggplot2)
library(splines)
library(foreach)
library(doParallel)
source("functions.R")

s <- 1:500
file <- paste0("data", s, ".csv")
data_list <- lapply(file, read.csv, header = TRUE)
n <- length(s)

registerDoParallel(cores = detectCores())

file_ps <- paste0("ps_lbc_net_", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_lbc_net <- do.call(cbind, ps_list)

time <- seq(3, 28, by = 0.1)
knots <- c(6.5, 10, 15)

time_vaying_cox_model_unwt <- function(ds, time) {
  
  cox_fit <- coxph(
    Surv(survival_time_28_day, death_within_28_days) ~ Tr + tt(Tr),
    data = ds,
    tt = function(x, t, ...) x * nsk(t, knots = knots, Boundary.knots = FALSE),  
    robust = TRUE
  )
  
  coef_all <- coef(cox_fit)
  coef_tr <- coef_all["Tr"]
  coef_tt <- coef_all[-1]
  spline_basis <- nsk(time, knots = knots, Boundary.knots = FALSE)
  beta_t <- coef_tr + rowSums(sweep(spline_basis, 2, coef_tt, FUN = "*"))
  
  return(beta_t)  # Return hazard ratio for this bootstrap sample
  
}

beta_unwt <- foreach(data = data_list, .combine = cbind) %dopar% {
  
  time_vaying_cox_model_unwt(data, time)
  
}

time_varying_cox_model_wt <- function(ds, ps, time) {
  
  wt <- ipw(ds$Tr, ps)
  
  cox_fit <- coxph(
    Surv(survival_time_28_day, death_within_28_days) ~ Tr + tt(Tr),
    data = ds,
    tt = function(x, t, ...) x * nsk(t, knots = knots, Boundary.knots = FALSE),  
    robust = TRUE,
    weight = wt
  )
  
  coef_all <- coef(cox_fit)
  coef_tr <- coef_all["Tr"]
  coef_tt <- coef_all[-1]
  spline_basis <- nsk(time, knots = knots, Boundary.knots = FALSE)
  beta_t <- coef_tr + rowSums(sweep(spline_basis, 2, coef_tt, FUN = "*"))
  
  return(beta_t)  # Return hazard ratio for this bootstrap sample
}

beta_wt_lbc_net <- foreach(i = 1:n, .combine = cbind) %dopar% {
  
  data <- data_list[[i]]
  ps <- ps_lbc_net[, i]  
  time_varying_cox_model_wt(data, ps, time)
  
}

sd_unwt <- apply(beta_unwt, 1, sd)
sd_wt_lbc_net <- apply(beta_wt_lbc_net, 1, sd)

res <- list(sd_unwt = sd_unwt, sd_wt_lbc_net = sd_wt_lbc_net)
saveRDS(res, "sd_beta.rds")









