library(survival)
library(dplyr)
library(ggplot2)
library(splines)
library(foreach)
library(doParallel)
source("functions.R")

s <- 1:500
file <- paste0("data", s, ".csv")
data_list <- lapply(file, read.csv, header = TRUE)
n <- length(s)

registerDoParallel(cores = detectCores())

file_ps <- paste0("ps_lbc_net_", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_lbc_net <- do.call(cbind, ps_list)

logistic_model <- function(data){
  
  logistic.fit <- glm(Tr~., data = data[,5:25], family = 'binomial')
  return(logistic.fit$fitted.values)
  
}

ps_log <- foreach(data = data_list, .combine = cbind) %dopar% {
  
  logistic_model(data)
  
}

time <- seq(3, 28, by = 1)
df <- 4
time_vaying_cox_model_unwt <- function(data, time, df) {

  ds <- data %>% dplyr::select(-c(los, in_hospital_mortality))
  
  # Fit the Cox model to the bootstrap sample
  cox_fit <- coxph(Surv(survival_time_28_day, death_within_28_days) ~ Tr + tt(Tr),
                   data = ds,
                   tt = function(x, t, ...) x * pspline(t, df = df),
                   robust = TRUE)
  
  # Extract coefficients
  coef_all <- coef(cox_fit)
  coef_tr <- coef_all["Tr"]
  coef_tt <- coef_all[2:(df + 3)]  # Adjust for number of basis functions
  
  # Compute spline basis and hazard ratios
  spline_basis <- ns(time, df = (df + 2))
  basis_matrix <- as.matrix(spline_basis)
  beta_t <- coef_tr + rowSums(sweep(basis_matrix, 2, coef_tt, FUN = "*"))
  # HR_t <- exp(beta_t)
  
  return(beta_t)  # Return hazard ratio for this bootstrap sample
  
}

beta_unwt <- foreach(data = data_list, .combine = cbind) %dopar% {
  
  time_vaying_cox_model_unwt(data, time, df)
  
}

time_varying_cox_model_wt <- function(data, ps, time, df) {
  
  ds <- data %>% dplyr::select(-c(los, in_hospital_mortality))
  wt <- ipw(ds$Tr, ps)
  
  # Fit the Cox model to the weighted dataset
  cox_fit <- coxph(Surv(survival_time_28_day, death_within_28_days) ~ Tr + tt(Tr),
                   data = ds,
                   tt = function(x, t, ...) x * pspline(t, df = df),
                   weights = wt,
                   robust = TRUE)
  
  # Extract coefficients
  coef_all <- coef(cox_fit)
  coef_tr <- coef_all["Tr"]
  coef_tt <- coef_all[2:(df + 1)]  # Adjust for number of basis functions
  
  # Compute spline basis and hazard ratios
  spline_basis <- ns(time, df = df)
  basis_matrix <- as.matrix(spline_basis)
  beta_t <- coef_tr + rowSums(sweep(basis_matrix, 2, coef_tt, FUN = "*"))
  # HR_t <- exp(beta_t)
  
  return(beta_t)  # Return hazard ratio for this bootstrap sample
}

beta_wt_lbc_net <- foreach(i = 1:n, .combine = cbind) %dopar% {
                                 
  data <- data_list[[i]]
  ps <- ps_lbc_net[, i]  
  time_varying_cox_model_wt(data, ps, time, df)
  
}

beta_wt_log <- foreach(i = 1:n, .combine = cbind) %dopar% {
  
  data <- data_list[[i]]
  ps <- ps_log[, i]  
  time_varying_cox_model_wt(data, ps, time, df)
  
}

sd_unwt <- apply(beta_unwt, 1, sd)
sd_wt_lbc_net <- apply(beta_wt_lbc_net, 1, sd)
sd_wt_log <- apply(beta_wt_log, 1, sd)

res <- list(sd_unwt = sd_unwt, sd_wt_lbc_net = sd_wt_lbc_net, sd_wt_log = sd_wt_log)
saveRDS(res, "sd_beta.rds")









