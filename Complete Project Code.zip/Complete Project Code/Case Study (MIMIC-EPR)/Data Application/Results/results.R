library(survival)
library(survminer)
library(dplyr)
library(pracma)
library(patchwork)
library(tidyr)
library(textables)
library(ggplot2)
library(grid)

## load data
source("functions.R")
file <- paste0("MIMIC_EPR.csv")
ds <- read.csv(file, header = TRUE)
X <- ds[,6:25]
Z <- ds[,5]
los <- ds[,1]
in_hospital_mortality <- ds[,2]
p <- ncol(X) 

# load ck_h
file_ck <- paste0("ck_h.csv")
ck_list <- read.csv(file_ck, header = TRUE)
ck <- ck_list$ck
h <- ck_list$h

###################################
## LBC-Net
###################################

## load propensity scores
ps_temp <- read.csv("ps_lbc_net.csv", header = FALSE)
ps_lbc_net <- ps_temp[,1]

## calculate estimates
lbc_net <- Model_based_estimates(ps_lbc_net)

###################################
## Other Model Based Methods
###################################

## load propensity scores
ps_temp <- read.csv("ps_nn.csv", header = FALSE)
ps_nn <- ps_temp[,1]
ps_temp <- read.csv("ps_log.csv", header = FALSE, skip = 1)
ps_log <- ps_temp[,1]
ps_temp <- read.csv("ps_cbps.csv", header = FALSE, skip = 1)
ps_cbps <- ps_temp[,1]

## calculate estimates
nn <- Model_based_estimates(ps_nn)
logit <- Model_based_estimates(ps_log)
cbps <- Model_based_estimates(ps_cbps)

###################################
## Weight Based Methods
###################################

## load weights
wt_temp <- read.csv("wt_cbipm.csv", header = FALSE, skip = 1)
wt_cbipm <- wt_temp[,1]
wt_temp <- read.csv("wt_sbw.csv", header = FALSE, skip = 1)
wt_sbw <- wt_temp[,1]
wt_temp <- read.csv("wt_eb.csv", header = TRUE)
wt_eb <- wt_temp
wt_temp <- read.csv("wt_osqp.csv", header = TRUE)
wt_osqp <- wt_temp

# sum(wt_cbipm[which(ds$Tr==0)])
# sum(wt_osqp$wt_att[which(ds$Tr==0)])
## calculate estimates
cbipm <- Weight_based_estimates(wt_cbipm, 1)
sbw <- Weight_based_estimates(wt_sbw, 1)
eb <- Weight_based_estimates(wt_eb, 2)
osqp <- Weight_based_estimates(wt_osqp, 2) 

# ----------------------------------
## Evalue
# ----------------------------------
## binary
RR <- exp(0.91*lbc_net$ATE_in_hospital_mortality/sd_res$lbc_net[2])
Evalue <- RR + sqrt(RR*(RR-1)) ## 11.5
ci_lower <- exp(0.91*lbc_net$ATE_in_hospital_mortality/sd_res$lbc_net[2]-1.78*sd_res$lbc_net[2])
ci_upper <- exp(0.91*lbc_net$ATE_in_hospital_mortality/sd_res$lbc_net[2]+1.78*sd_res$lbc_net[2])
# (3.92, 9.23)

## continuous
RR <- exp(0.91*lbc_net$ATE_los/sd_res$lbc_net[1])
Evalue <- RR + sqrt(RR*(RR-1)) ## 6.527
ci_lower <- exp(0.91*lbc_net$ATE_los/sd_res$lbc_net[1]-1.78*sd_res$lbc_net[1])
ci_upper <- exp(0.91*lbc_net$ATE_los/sd_res$lbc_net[1]+1.78*sd_res$lbc_net[1])
# (1.37,9.07)

## survival
RR <- (1-0.5^sqrt(lbc_net$HR))/(1-0.5^sqrt(1/lbc_net$HR))
Evalue <- RR + sqrt(RR*(RR-1)) ## 1.464
ci_lower_hr <- lbc_net$HR-1.96*sd_res$lbc_net[3]
ci_upper_hr <- lbc_net$HR+1.96*sd_res$lbc_net[3]
hr_lower<- (1-0.5^sqrt(ci_lower_hr))/(1-0.5^sqrt(1/ci_lower_hr))
hr_upper <- (1-0.5^sqrt(ci_upper_hr))/(1-0.5^sqrt(1/ci_upper_hr))
ci_lower <- hr_lower + sqrt(hr_lower*(hr_lower-1))
ci_upper <- hr_upper + sqrt(hr_upper*(hr_upper-1))
# (1.21,1.66)

###################################################################
##################### Figures and Tables ##########################
###################################################################

# ---------------------------------
##  KM Plot
# ---------------------------------

wt <- ipw(Z, ps_lbc_net)
ds_surv <- ds %>% dplyr::select(-c(los, in_hospital_mortality))
# Fit Kaplan-Meier survival curves for Tr = 1 (treated) and Tr = 0 (control)
km_unweighted <- survfit(Surv(survival_time_28_day, death_within_28_days) ~ Tr, data = ds_surv )

# Fit weighted Kaplan-Meier survival curves for Tr = 1 (treated) and Tr = 0 (control)
km_weighted <- survfit(Surv(survival_time_28_day, death_within_28_days) ~ Tr, data = ds_surv, weights = wt)

# Unweighted Kaplan-Meier plot
plot_unweighted <- ggsurvplot(
  km_unweighted,
  data = ds_surv,
  conf.int = TRUE,            # Confidence intervals
  pval = FALSE,               # Show p-value
  risk.table = FALSE,         # Add risk table
  ggtheme = theme_minimal(),   # Minimal theme
  title = "Kaplan-Meier Survival Curve (Unweighted)",
  xlab = "Time (days)",
  ylab = "Survival Probability",
  legend.title = "Group",
  legend.labs = c("Control (Tr=0)", "Treated (Tr=1)"),
  ylim = c(0.5, 1),
  xlim = c(3, NA),
  palette = c("black", "grey"), # Black and grey for easy distinction
  linetype = c("solid", "dashed"), # Different line types for groups
  censor.size = 2              # Adjust censoring point size
)

plot_weighted <- ggsurvplot(
  km_weighted,
  data = ds_surv,
  conf.int = TRUE,            # Confidence intervals
  pval = FALSE,               # Show p-value
  risk.table = FALSE,         # Add risk table
  ggtheme = theme_minimal(),   # Minimal theme
  title = "Kaplan-Meier Survival Curve (Weighted)",
  xlab = "Time (days)",
  ylab = "Survival Probability",
  legend.title = "Group",
  legend.labs = c("Control (Tr=0)", "Treated (Tr=1)"),
  ylim = c(0.5, 1),
  xlim = c(3, NA),
  palette = c("black", "grey"), # Black and grey for easy distinction
  linetype = c("solid", "dashed"), # Different line types for groups
  censor.size = 2              # Adjust censoring point size
)

unweighted_plot <- plot_unweighted$plot +
  scale_x_continuous(breaks = seq(3, max(ds_surv$survival_time_28_day), by = 5)) +
  theme(legend.position = "none", 
        axis.title = element_text(size = 20),
        axis.text = element_text(size = 20),
        text = element_text(size = 20)) 
weighted_plot <- plot_weighted$plot + 
  scale_x_continuous(breaks = seq(3, max(ds_surv$survival_time_28_day), by = 5)) +
  theme(legend.position = "bottom", 
        axis.title = element_text(size = 20),
        axis.text = element_text(size = 20),
        text = element_text(size = 20)) 
combined_plot <- unweighted_plot + weighted_plot + plot_layout(ncol = 1)
ggsave("mimic_km_figure.pdf", plot = combined_plot, width = 8, height = 8, device = "pdf", family = "Times")

# ----------------------------------
## HL Plot
# ----------------------------------

hl.plot <- function(ps, Z, color = "black", line_type = "solid", breaks = 10, label = NULL){
  
  ps_group <- cut(ps, breaks = breaks, include.lowest = TRUE)
  group_data <- data.frame(ps0 = ps, Z, ps_group) %>%
    group_by(ps_group) %>%
    summarise(avg_ps = mean(ps0), prop_Z = mean(Z))
  
  p <- group_data %>%
    ggplot(aes(x = avg_ps, y = prop_Z)) +
    geom_point(color = color) +
    geom_line(color = color, linetype = line_type) +
    geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "red") +
    labs(x = "Average Estimated Propensity Score", y = "Observed Proportion of Z = 1") +
    theme_bw(base_size = 20) +
    theme( panel.grid.major = element_blank(),  # Removes major grid lines
           panel.grid.minor = element_blank(),
           axis.title = element_text(size = 20),
           axis.text = element_text(size = 20),
           text = element_text(size = 20))
  
  # Add the label in the upper left corner
  if (!is.null(label)) {
    p <- p + annotate("text", x = 0.1, y = 0.9, label = label, color = color, 
                      hjust = 0, vjust = 1, size = 4, fontface = "bold")
  }
  
  return(p)
  
}

p.lbc_net_hl <- hl.plot(ps_lbc_net, Z, color = "#9467bd", line_type = "solid", label = "LBC-Net")
p.log_hl <- hl.plot(ps_log, Z, color = "#ff7f0e", line_type = "dashed", label = "Logistic")
p.cbps_hl <- hl.plot(ps_cbps, Z, color = "#2ca02c", line_type = "dotted", label = "CBPS")
p.nn_hl <- hl.plot(ps_nn, Z, color = "#1f77b4", line_type = "dotdash", label = "NN")

combined_plot <- p.lbc_net_hl + 
  p.log_hl + 
  p.cbps_hl + 
  p.nn_hl + 
  plot_layout(ncol = 2, guides = "collect", axis_titles = 'collect')

# Save the combined plot
ggsave("mimic_hl_figure.pdf", plot = combined_plot, width = 8, height = 8, device = "pdf", family = "Times")

# ----------------------------------
## Mirror Histogram
# ----------------------------------
p <- mirror_plot(ps_lbc_net, Z)
ggsave("mimic_mh_figure.pdf", plot = p, width = 8, height = 8, device = "pdf", family = "Times")

# ----------------------------------
## ATE Table
# ----------------------------------

ate_table <- data.frame(methods = c("Logistic", "OSQP", "CBIPM", "SBW", "EB", "CBPS", "NN", "LBC-net"),
                        ATE_los = c(logit$ATE_los, osqp$ATE_los, cbipm$ATE_los, sbw$ATE_los, eb$ATE_los, cbps$ATE_los, nn$ATE_los, lbc_net$ATE_los),
                        ATE_in_hospital_mortality = c(logit$ATE_in_hospital_mortality, osqp$ATE_in_hospital_mortality, cbipm$ATE_in_hospital_mortality, sbw$ATE_in_hospital_mortality, eb$ATE_in_hospital_mortality, cbps$ATE_in_hospital_mortality, nn$ATE_in_hospital_mortality, lbc_net$ATE_in_hospital_mortality),
                        HR = c(logit$HR, osqp$HR, cbipm$HR, sbw$HR, eb$HR, cbps$HR, nn$HR, lbc_net$HR))
sd_res <- readRDS("ve.rds")

ate_table_new <- ate_table %>%
  mutate(ATE_los_sd = as.numeric(sd_res[1,]),
         ATE_in_hospital_mortality_sd = as.numeric(sd_res[2,]),
         HR_sd = as.numeric(sd_res[3,])) %>%
  mutate(
    CI_95_ATE_los = paste0("[", round(ATE_los - 1.96 * ATE_los_sd, 2), ", ", round(ATE_los + 1.96 * ATE_los_sd, 2), "]"),
    CI_95_ATE_in_hospital_mortality = paste0("[", round(ATE_in_hospital_mortality - 1.96 * ATE_in_hospital_mortality_sd, 2), ", ", round(ATE_in_hospital_mortality + 1.96 * ATE_in_hospital_mortality_sd, 2), "]"),
    CI_95_HR = paste0("[", round(HR - 1.96 * HR_sd, 2), ", ", round(HR + 1.96 * HR_sd, 2), "]")
  ) %>%
  mutate(
    ATE_los = round(ATE_los, 2),
    ATE_in_hospital_mortality = round(ATE_in_hospital_mortality, 2),
    HR = round(HR, 2),
    ATE_los_sd = round(ATE_los_sd, 2),
    ATE_in_hospital_mortality_sd = round(ATE_in_hospital_mortality_sd, 2),
    HR_sd = round(HR_sd, 2)
  ) %>%
  mutate(
    ATE_los_combined = paste0(ATE_los, " (", ATE_los_sd, ")"),
    ATE_in_hospital_mortality_combined = paste0(ATE_in_hospital_mortality, " (", ATE_in_hospital_mortality_sd, ")"),
    HR_combined = paste0(HR, " (", HR_sd, ")")
  )

ate_long <- ate_table_new %>%
  dplyr::select(c(methods, ATE_los_combined, CI_95_ATE_los, ATE_in_hospital_mortality_combined, CI_95_ATE_in_hospital_mortality, HR_combined, CI_95_HR)) %>%
  pivot_longer(cols = c(ATE_los_combined, CI_95_ATE_los, ATE_in_hospital_mortality_combined, CI_95_ATE_in_hospital_mortality, HR_combined, CI_95_HR),
               names_to = "measure",
               values_to = "value")

ate_transposed <- ate_long %>%
  pivot_wider(names_from = methods, values_from = value) %>%
  mutate(
    measure = case_when(
      measure %in% c("ATE_los_combined", "ATE_in_hospital_mortality_combined", "HR_combined") ~ "Estimate (SD)",
      measure %in% c("CI_95_ATE_los", "CI_95_ATE_in_hospital_mortality", "CI_95_HR") ~ "95% CI",
      TRUE ~ measure  # This handles any cases that don't match the above conditions
    )
  )

tab <- TR(c("","ATE (LOS)","ATE (In-Hospital Mortality)","HR"),cspan=c(1,2,2,2)) +
  midrulep(list(c(2,3), c(4,5), c(6,7))) +
  TR("Methods") %:% with(ate_transposed, TR(measure)) +
  midrule() +
  TR("SBW") %:% with(ate_transposed, TR(SBW)) +
  TR("EB") %:% with(ate_transposed, TR(EB)) +
  TR("OSQP") %:% with(ate_transposed, TR(OSQP)) +
  TR("CBIPM") %:% with(ate_transposed, TR(CBIPM)) +
  TR("Logistic") %:% with(ate_transposed, TR(Logistic)) +
  TR("CBPS") %:% with(ate_transposed, TR(CBPS)) +
  TR("NN") %:% with(ate_transposed, TR(NN)) +
  TR("LBC-Net") %:% with(ate_transposed, TR(`LBC-net`))


# Print the table to a text variable
text_output <- capture.output(print(tab))

# Write the text output to a file
writeLines(text_output, "mimic_table.txt")

# ----------------------------------
## GSD Table
# ----------------------------------
library(xtable)
gsd_table <- cbind(logit$GSD, osqp$GSD, cbipm$GSD, sbw$GSD, eb$GSD, cbps$GSD, nn$GSD, lbc_net$GSD)
colnames(gsd_table) <- c("Logistic", "OSQP", "CBIPM", "SBW", "EB", "CBPS", "NN", "LBC-net")
gsd_table <- round(gsd_table, 3)
gsd_table

latex_table <- xtable(gsd_table)

# Print the table to a text variable
text_output <- capture.output(print(latex_table, type = "latex"))

# Write the text output to a file
writeLines(text_output, "mimic_table_gsd.txt")
  

# ----------------------------------
## LSD Figure
# ----------------------------------

GSD_list <- list(logit$GSD, cbps$GSD, nn$GSD, lbc_net$GSD)
TLSD <- list(logit$TLSD, cbps$TLSD, nn$TLSD, lbc_net$TLSD)
names(TLSD) <- c("LOGISTIC", "CBPS", "NN", "LBC-NET")
names(GSD_list) <- c("LOGISTIC", "CBPS", "NN", "LBC-NET")

vdata <- lapply(TLSD, f1_colmean <- function(mat){
  
  mean_matrix <- do.call(rbind, mat)
  
  return(mean_matrix)
  
})

violin_points_list <- list(
  LOGISTIC = seq(0.05, 0.92, by = 0.1),
  CBPS = seq(0.06, 0.93, by = 0.1),
  NN = seq(0.07, 0.94, by = 0.1),
  'LBC-NET' = seq(0.08, 0.95, by = 0.1)
)

vdata_long <- data.frame()
for (i in names(vdata)) {
  mat <- vdata[[i]]
  mat_long <- as.data.frame(vdata[[i]]) %>%
    pivot_longer(cols = everything(), names_to = "CK", values_to = "LSD") %>%
    mutate(Method = i,
           CK = rep(sprintf("%.2f", seq(0.01, 0.99, by = 0.01)), 20)) %>%
    filter(CK %in% violin_points_list[[i]])
  
  vdata_long <- rbind(vdata_long, mat_long)
  
}
vdata <- vdata_long

ggsave("mimic_lsd_figure.pdf", plot = LSD_balance_plot(TLSD), width = 10, height = 8, device = "pdf", family = "Times")






