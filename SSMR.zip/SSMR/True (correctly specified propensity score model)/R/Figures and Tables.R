library(knitr)
library(kableExtra)
library(ggplot2)
library(dplyr)
library(tidyr)

source('Methods.R')

########################################################################
################ All Simulations Results ###############################
########################################################################

load('Other_Methods.RData')
seed.values <- read.csv('sim_seed.csv', header = FALSE)
s <- seed.values[, 1]
file <- paste0(path, "ssmr_data_seed", s, ".csv")
data_list <- lapply(file, read.csv, header = TRUE)

################ Correctlty specified propensity score model ###################

## load ck_h
file_ck <- paste0(path, "ck_h", s, ".csv")
ck_list <- lapply(file_ck, read.csv, header = TRUE)

## load propensity score
file_ps <- paste0("ssmr", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_list <- lapply(ps_list, function(df) df[1:15000,])
ps_dl <- do.call(cbind, ps_list)
ps_dl <- apply(ps_dl, 2, as.numeric)
## check if file exists
#sapply(file_ps, file.exists)

# load bce ps
file_ps <- paste0("ssmr_bce", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_list <- lapply(ps_list, function(df) df[1:15000,])
ps_bce <- do.call(cbind, ps_list)
ps_bce <- apply(ps_bce, 2, as.numeric)

## ATE and LSD calculation
n <- length(s)
p <- length(ck_list[[1]]$ck)
M <- rep(NA, n)
N <- list(global = M, local = M)
L <- matrix(nrow = n, ncol = p)

variable_names <- paste("X", 1:84, sep = "")
Lt <- setNames(lapply(variable_names, function(x) L), variable_names)

ATE <- list(logistic = M, cbps = M, bce = M, PSLBdl = M)
Balance <- list(logistic = N, cbps = N, bce = N, PSLBdl = N)

## Whole LSD values
TLSD <- list(logistic = Lt, cbps = Lt, bce = Lt, PSLBdl = Lt)

for(i in 1:n) {
  
  ds <- data_list[[i]]
  
  ## IPW
  wt_logistic <- ipw(Z = ds[,2], ssmrOther$logistic[,i])
  wt_cbps <- ipw(Z = ds[,2], ps = ssmrOther$CBPS[,i])
  wt_dl <- ipw(Z = ds[,2], ps = ps_dl[,i])
  wt_bce <- ipw(Z = ds[,2], ps = ps_bce[,i])
  
  ## ATE estimate
  ATE$logistic[i] <- ATE_infer(ds[,1], wt_logistic, ds[,2])
  ATE$cbps[i] <- ATE_infer(ds[,1], wt_cbps, ds[,2])
  ATE$PSLBdl[i] <- ATE_infer(ds[,1], wt_dl, ds[,2])
  ATE$bce[i] <- ATE_infer(ds[,1], wt_bce, ds[,2])
  
  ## balance 
  ck <- ck_list[[i]]$ck
  h <- ck_list[[i]]$h
  
  ## PSLB DL
  PSLBdl <- apply(ds[,3:86], 2, function(x) LSD(x, ds[,2], ps_dl[,i], 
                                                ck, h, gaussian_kernel)) 
  for (j in 1:84) {
    
    var_name <- paste("X", j, sep = "")
    TLSD$PSLBdl[[var_name]][i, ] <- PSLBdl[[var_name]]$LSD
    
  }
  
  mean_LSD <- unlist(lapply(PSLBdl, function(x) x$LSD_mean))
  GSD <- unlist(lapply(PSLBdl, function(x) x$GSD))
  Balance$PSLBdl$local[i] <- mean(mean_LSD)
  Balance$PSLBdl$global[i] <- mean(abs(GSD))
  
  ## BCE
  bce <- apply(ds[,3:86], 2, function(x) LSD(x, ds[,2], ps_bce[,i], 
                                             ck, h, gaussian_kernel)) 
  for (j in 1:84) {
    
    var_name <- paste("X", j, sep = "")
    TLSD$bce[[var_name]][i, ] <- bce[[var_name]]$LSD
    
  }
  
  mean_LSD <- unlist(lapply(bce, function(x) x$LSD_mean))
  GSD <- unlist(lapply(bce, function(x) x$GSD))
  Balance$bce$local[i] <- mean(mean_LSD)
  Balance$bce$global[i] <- mean(abs(GSD))
  
  ## logistic regression
  logistic <- apply(ds[,3:86], 2, function(x) LSD(x, ds[,2], ssmrOther$logistic[,i], 
                                                  ck, h, gaussian_kernel)) 
  for (j in 1:84) {
    
    var_name <- paste("X", j, sep = "")
    TLSD$logistic[[var_name]][i, ] <- logistic[[var_name]]$LSD
    
  }
  
  mean_LSD <- unlist(lapply(logistic, function(x) x$LSD_mean))
  GSD <- unlist(lapply(logistic, function(x) x$GSD))
  Balance$logistic$local[i] <- mean(mean_LSD)
  Balance$logistic$global[i] <- mean(abs(GSD))
  
  ## CBPS
  cbps <- apply(ds[,3:86], 2, function(x) LSD(x, ds[,2], ssmrOther$CBPS[,i], 
                                              ck, h, gaussian_kernel)) 
  
  for (j in 1:84) {
    
    var_name <- paste("X", j, sep = "")
    TLSD$cbps[[var_name]][i, ] <- cbps[[var_name]]$LSD
    
  }
  
  mean_LSD <- unlist(lapply(cbps, function(x) x$LSD_mean))
  GSD <- unlist(lapply(cbps, function(x) x$GSD))
  Balance$cbps$local[i] <- mean(mean_LSD)
  Balance$cbps$global[i] <- mean(abs(GSD))
  
}
res <- list(ATE, Balance, TLSD)
saveRDS(res, "ssmrtrue_res.rds")

################ plot 1 ###################

res <- readRDS("ssmrtrue_res.rds")
ATE_true <- res[[1]]
Balance <- res[[2]]
TLSD <- res[[3]]
names(TLSD) <- c("LOGISTIC", "CBPS", "BCE", "LBC-NET")
names(Balance) <- c("LOGISTIC", "CBPS", "BCE", "LBC-NET")

vdata <- lapply(TLSD, f1_colmean <- function(mat){
  
  mean_list <- lapply(mat, colMeans)
  mean_matrix <- do.call(rbind, mean_list)
  
  return(mean_matrix)
  
})

violin_points_list <- list(
  LOGISTIC = seq(0.05, 0.92, by = 0.2),
  CBPS = seq(0.06, 0.93, by = 0.2),
  BCE = seq(0.07, 0.94, by = 0.2),
  'LBC-NET' = seq(0.08, 0.95, by = 0.2)
)

vdata_long <- data.frame()
for (i in names(vdata)) {
  mat <- vdata[[i]]
  mat_long <- as.data.frame(vdata[[i]]) %>%
    pivot_longer(cols = everything(), names_to = "CK", values_to = "LSD") %>%
    mutate(Method = i,
           CK = rep(sprintf("%.2f", seq(0.01, 0.99, by = 0.01)), 84)) %>%
    filter(CK %in% violin_points_list[[i]])
  
  vdata_long <- rbind(vdata_long, mat_long)
  
}

#violin_points <- seq(0.05, 0.95, by = 0.1) 
#vdata <- subset(vdata_long, CK %in% violin_points) 
vdata <- vdata_long

gsd <- lapply(Balance, function(x) abs(mean(x$global)))
gsd <- stack(gsd)
names(gsd) <- c("GSD", "Method")
gsd$CK <- c('0.89', '0.90', '0.91', '0.92')
gsd$Method <- factor(gsd$Method, levels = c("LOGISTIC", "CBPS", "BCE", "LBC-NET"))
scaling_factor <- 2  
gsd$ScaledGSD <- gsd$GSD * scaling_factor

p1 <- LSD_true_plot(TLSD)

################ Mis-specified propensity score mdoel ###################

################ Plot 2 ###################

res <- readRDS("ssmrmis_res.rds")
ATE_mis <- res[[1]]
Balance <- res[[2]]
TLSD <- res[[3]]
names(TLSD) <- c("LOGISTIC", "CBPS", "BCE", "LBC-NET")
names(Balance) <- c("LOGISTIC", "CBPS", "BCE", "LBC-NET")
## GSD
# gsd <- lapply(Balance, function(x) abs(colMeans(x$global)))
# gsd <- stack(gsd)
# names(gsd) <- c("GSD", "Method")
# gsd$Covariate <- rep(c("X1", "X2", "X3", "X4"), times = length(gsd))
# gsd$CK <- c(rep('0.88', 4), rep('0.90', 4), rep('0.92', 4), rep('0.94', 4))
# gsd$Method <- factor(gsd$Method, levels = c("logistic", "cbps", "bce", "PSLBdl"))
vdata <- lapply(TLSD, f1_colmean <- function(mat){
  
  mean_list <- lapply(mat, colMeans)
  mean_matrix <- do.call(rbind, mean_list)
  
  return(mean_matrix)
  
})

violin_points_list <- list(
  LOGISTIC = seq(0.05, 0.92, by = 0.2),
  CBPS = seq(0.06, 0.93, by = 0.2),
  BCE = seq(0.07, 0.94, by = 0.2),
  'LBC-NET' = seq(0.08, 0.95, by = 0.2)
)

vdata_long <- data.frame()
for (i in names(vdata)) {
  mat <- vdata[[i]]
  mat_long <- as.data.frame(vdata[[i]]) %>%
    pivot_longer(cols = everything(), names_to = "CK", values_to = "LSD") %>%
    mutate(Method = i,
           CK = rep(sprintf("%.2f", seq(0.01, 0.99, by = 0.01)), 84)) %>%
    filter(CK %in% violin_points_list[[i]])
  
  vdata_long <- rbind(vdata_long, mat_long)
  
}

#violin_points <- seq(0.05, 0.95, by = 0.1) 
#vdata <- subset(vdata_long, CK %in% violin_points) 
vdata <- vdata_long

gsd <- lapply(Balance, function(x) abs(mean(x$global)))
gsd <- stack(gsd)
names(gsd) <- c("GSD", "Method")
gsd$CK <- c('0.89', '0.90', '0.91', '0.92')
gsd$Method <- factor(gsd$Method, levels = c("LOGISTIC", "CBPS", "BCE", "LBC-NET"))
scaling_factor <- 2  
gsd$ScaledGSD <- gsd$GSD * scaling_factor

p2 <- LSD_mis_plot(TLSD)

################ Figure For this Simuation (S6) ###################

p1n <- p1 
p2n <- p2 + theme(legend.position = "none")
combined_plot <- p1n + p2n + plot_layout(ncol = 2, guides = "collect", axis_titles = 'collect_x') & theme(legend.position = "bottom")

ggsave("SSMR LSD Figure.pdf", plot = combined_plot, width = 16, height = 8, device = "pdf", family = "Times")

################ Table For this Simuation (S3) ###################

ATE_summary <- rbind('true logistic' = Col_bias_variance_rmse(ATE_true$logistic, 1),
                     'true CBPS' = Col_bias_variance_rmse(ATE_true$cbps, 1), 'true bce' = Col_bias_variance_rmse(ATE_true$bce, 1), 'true PSLB DL' = Col_bias_variance_rmse(ATE_true$PSLBdl, 1) ,
                     'mis logistic' = Col_bias_variance_rmse(ATE_mis$logistic, 1), 'mis CBPS' = Col_bias_variance_rmse(ATE_mis$cbps, 1), 'mis bce' = Col_bias_variance_rmse(ATE_mis$bce, 1),
                     'mis PSLB DL' = Col_bias_variance_rmse(ATE_mis$PSLBdl, 1))
ATE_summary <- as.data.frame(ATE_summary)
ATE_summary$Method <- rep(c("Logistic", "CBPS", "BCE", "PSLBDL"), 2)
ATE_summary$Type <- c(rep("Correctly Specified Model", 4), rep("Mis-specified Model", 4))
ATE_summary <- ATE_summary %>%
  mutate(Bias = round(Bias, 4),
         RMSE = round(RMSE, 4),
         Var = round(Var, 4))
#dput(Y_summary)
data_wide <- ATE_summary %>%
  pivot_wider(names_from = Type, values_from = c(Bias, RMSE, Var)) %>%
  dplyr::select(Method, `Bias_Correctly Specified Model`, `RMSE_Correctly Specified Model`, `Var_Correctly Specified Model`, `Bias_Mis-specified Model`, `RMSE_Mis-specified Model`, `Var_Mis-specified Model`) %>%
  mutate(across(everything(), ~ ifelse(is.na(.), '-', .)))

table <- kable(data_wide, format = "latex", booktabs = TRUE, align = 'c', 
               col.names = c("", rep("", ncol(data_wide)-1))) %>%
  kable_styling(latex_options = c("striped", "scale_down")) %>%
  add_header_above(c("Method" = 1, "Bias%" = 1, "RMSE" = 1, "Var" = 1, "Bias%" = 1, "RMSE" = 1, "Var" = 1)) %>%
  add_header_above(c(" " = 1, "Correctly Specified Model" = 3, "Mis-specified Model" = 3)) 
table_latex <- as.character(table)
table_latex <- gsub("\\\\midrule\\n", "\\\\midrule\\n\\noalign{}", table_latex)
writeLines(table_latex, "SSMR_ATEtable.tex")

library(dplyr)
library(ggplot2)
library(patchwork)
dstrue <- PS_simulation_new(n = 15000, 0.5, K = K, beta = matrix(c(bg,betaK[1,]), ncol = 1), 
                            alpha = matrix(c(ak, alphaK), ncol = 1), delta = 1, Homo = 0, 
                            delta_function, seeds = 12)
dsmis <- PS_simulation_new(n = 15000, 0.5, K = K, beta = matrix(c(bg_mis,betaK[1,]), ncol = 1), 
                           alpha = matrix(c(ak, alphaK), ncol = 1), delta = 1, Homo = 0, 
                           delta_function, seeds = 12)
ps_true <- read.csv('ssmr12.csv', header = FALSE)
ps_mis <- read.csv('ssmrmis12.csv', header = FALSE)
Ztrue <- dstrue$Data[,2]
Zmis <- dsmis$Data[,2]

################ Figure Hosmer Lemeshow (S7) ###################
ps_group <- cut(ps_true[,1], breaks = 10, include.lowest = TRUE)
group_data <- data.frame(ps = ps_true[,1], Ztrue, ps_group) %>%
  group_by(ps_group) %>%
  summarise(avg_ps = mean(ps), prop_Z = mean(Ztrue)) 

p1 <- group_data %>%
  ggplot(aes(x = avg_ps, y = prop_Z)) + 
  geom_point() +
  geom_line() +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "red") +
  labs(x = "Average Estimated Propensity Score",
       y = "Observed Proportion of Z = 1") +
  theme_bw(base_size = 12) + 
  theme( panel.grid.major = element_blank(),  # Removes major grid lines
         panel.grid.minor = element_blank(),
         axis.title = element_text(size = 12),
         axis.text = element_text(size = 12))

ps_group <- cut(ps_mis[,1], breaks = 10, include.lowest = TRUE)
group_data <- data.frame(ps = ps_mis[,1], Zmis, ps_group) %>%
  group_by(ps_group) %>%
  summarise(avg_ps = mean(ps), prop_Z = mean(Zmis)) 

p2 <- group_data %>%
  ggplot(aes(x = avg_ps, y = prop_Z)) + 
  geom_point() +
  geom_line() +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "red") +
  labs(x = "Average Estimated Propensity Score", y = "") +
  theme_bw(base_size = 12) + 
  theme( panel.grid.major = element_blank(),  # Removes major grid lines
         panel.grid.minor = element_blank(),
         axis.title = element_text(size = 12),
         axis.text = element_text(size = 12))

combined_plot <- p1 + p2 + plot_layout(ncol = 2, guides = "collect", axis_titles = 'collect_x') 
combined_plot
ggsave("SSMR HL Figure.pdf", plot = combined_plot, width = 16, height = 8, device = "pdf", family = "Times")






