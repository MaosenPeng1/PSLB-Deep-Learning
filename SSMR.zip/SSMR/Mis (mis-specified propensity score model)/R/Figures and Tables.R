library(knitr)
library(kableExtra)
library(ggplot2)
library(dplyr)
library(tidyr)

source('Methods.R')

########################################################################
################ All Simulations Results ###############################
########################################################################

load('Other_Methods.RData')
seed.values <- read.csv('sim_seed.csv', header = FALSE)
s <- seed.values[, 1]
file <- paste0(path, "ssmr_data_seed", s, ".csv")
data_list <- lapply(file, read.csv, header = TRUE)

################ Mis-specified propensity score model ###################

## load ck_h
file_ck <- paste0(path, "ck_h", s, ".csv")
ck_list <- lapply(file_ck, read.csv, header = TRUE)

## load propensity score
file_ps <- paste0("ssmr", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_list <- lapply(ps_list, function(df) df[1:15000,])
ps_dl <- do.call(cbind, ps_list)
ps_dl <- apply(ps_dl, 2, as.numeric)
## check if file exists
#sapply(file_ps, file.exists)

# load bce ps
file_ps <- paste0("ssmr_bce", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_list <- lapply(ps_list, function(df) df[1:15000,])
ps_bce <- do.call(cbind, ps_list)
ps_bce <- apply(ps_bce, 2, as.numeric)

## ATE and LSD calculation
n <- length(s)
p <- length(ck_list[[1]]$ck)
M <- rep(NA, n)
N <- list(global = M, local = M)
L <- matrix(nrow = n, ncol = p)

variable_names <- paste("X", 1:84, sep = "")
Lt <- setNames(lapply(variable_names, function(x) L), variable_names)

ATE <- list(logistic = M, cbps = M, bce = M, PSLBdl = M)
Balance <- list(logistic = N, cbps = N, bce = N, PSLBdl = N)

## Whole LSD values
TLSD <- list(logistic = Lt, cbps = Lt, bce = Lt, PSLBdl = Lt)

for(i in 1:n) {
  
  ds <- data_list[[i]]
  
  ## IPW
  wt_logistic <- ipw(Z = ds[,2], ssmrOther$logistic[,i])
  wt_cbps <- ipw(Z = ds[,2], ps = ssmrOther$CBPS[,i])
  wt_dl <- ipw(Z = ds[,2], ps = ps_dl[,i])
  wt_bce <- ipw(Z = ds[,2], ps = ps_bce[,i])
  
  ## ATE estimate
  ATE$logistic[i] <- ATE_infer(ds[,1], wt_logistic, ds[,2])
  ATE$cbps[i] <- ATE_infer(ds[,1], wt_cbps, ds[,2])
  ATE$PSLBdl[i] <- ATE_infer(ds[,1], wt_dl, ds[,2])
  ATE$bce[i] <- ATE_infer(ds[,1], wt_bce, ds[,2])
  
  ## balance 
  ck <- ck_list[[i]]$ck
  h <- ck_list[[i]]$h
  
  ## PSLB DL
  PSLBdl <- apply(ds[,3:86], 2, function(x) LSD(x, ds[,2], ps_dl[,i], 
                                                ck, h, gaussian_kernel)) 
  for (j in 1:84) {
    
    var_name <- paste("X", j, sep = "")
    TLSD$PSLBdl[[var_name]][i, ] <- PSLBdl[[var_name]]$LSD
    
  }
  
  mean_LSD <- unlist(lapply(PSLBdl, function(x) x$LSD_mean))
  GSD <- unlist(lapply(PSLBdl, function(x) x$GSD))
  Balance$PSLBdl$local[i] <- mean(mean_LSD)
  Balance$PSLBdl$global[i] <- mean(abs(GSD))
  
  ## BCE
  bce <- apply(ds[,3:86], 2, function(x) LSD(x, ds[,2], ps_bce[,i], 
                                             ck, h, gaussian_kernel)) 
  for (j in 1:84) {
    
    var_name <- paste("X", j, sep = "")
    TLSD$bce[[var_name]][i, ] <- bce[[var_name]]$LSD
    
  }
  
  mean_LSD <- unlist(lapply(bce, function(x) x$LSD_mean))
  GSD <- unlist(lapply(bce, function(x) x$GSD))
  Balance$bce$local[i] <- mean(mean_LSD)
  Balance$bce$global[i] <- mean(abs(GSD))
  
  ## logistic regression
  logistic <- apply(ds[,3:86], 2, function(x) LSD(x, ds[,2], ssmrOther$logistic[,i], 
                                                  ck, h, gaussian_kernel)) 
  for (j in 1:84) {
    
    var_name <- paste("X", j, sep = "")
    TLSD$logistic[[var_name]][i, ] <- logistic[[var_name]]$LSD
    
  }
  
  mean_LSD <- unlist(lapply(logistic, function(x) x$LSD_mean))
  GSD <- unlist(lapply(logistic, function(x) x$GSD))
  Balance$logistic$local[i] <- mean(mean_LSD)
  Balance$logistic$global[i] <- mean(abs(GSD))
  
  ## CBPS
  cbps <- apply(ds[,3:86], 2, function(x) LSD(x, ds[,2], ssmrOther$CBPS[,i], 
                                              ck, h, gaussian_kernel)) 
  
  for (j in 1:84) {
    
    var_name <- paste("X", j, sep = "")
    TLSD$cbps[[var_name]][i, ] <- cbps[[var_name]]$LSD
    
  }
  
  mean_LSD <- unlist(lapply(cbps, function(x) x$LSD_mean))
  GSD <- unlist(lapply(cbps, function(x) x$GSD))
  Balance$cbps$local[i] <- mean(mean_LSD)
  Balance$cbps$global[i] <- mean(abs(GSD))
  
}
res <- list(ATE, Balance, TLSD)
saveRDS(res, "ssmrmis_res.rds")










