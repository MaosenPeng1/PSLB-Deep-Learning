library(foreach)
library(doParallel)
library(CBPS)

## load seeds
seed.values <- read.csv('sim_seed.csv', header = FALSE)
s <- seed.values[, 1]

## load ck_h
file <- paste0("ssmr_data_seed", s, ".csv")
data_list <- lapply(file, read.csv, header = TRUE)

registerDoParallel(cores = detectCores())
obj <- list()

logistic_model <- function(data){
  
  logistic.fit <- glm(Tr~.-Y, data = data, family = 'binomial')
  return(logistic.fit$fitted.values)
  
}

logistic_res <- foreach(data = data_list, .combine = cbind) %dopar% {
  
  logistic_model(data)
  
}
obj$logistic <- logistic_res

CBPS_model <- function(data){
  
  cbps.fit <- CBPS(Tr~.-Y, data = data, method = 'exact', ATT = 0, twostep = FALSE)
  return(cbps.fit$fitted.values)
  
}

# Run the CBPS models in parallel
cbps_res <- foreach(data = data_list, .combine = cbind) %dopar% {
  
  CBPS_model(data)
  
}
obj$CBPS <- cbps_res
print(head(cbps_res))
ssmrOther <- obj
save(ssmrOther, file = 'Other_Methods.RData')
