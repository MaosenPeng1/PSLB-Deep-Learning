source(Methods.R)

# 84 covariates scenarios
K = 80
bg = c(-1.5,0.5,-0.75,2,-0.5, rep(0,12)) # good overlap
bg_mis = c(-1.5,0.5,-0.75,2,-0.5, 0.1, rep(0,5), 0.2, 0.2,rep(0,4)) # mis-specified
bb = c(-1,0.4,-1.5,2,-1.5, rep(0,12)) # poor overlap
ak = c(0.5,1,0.6,2.2,-1.2, rep(0,12))
betaK = rbind(rep(c(rep(-0.1,K/8),rep(0.15,K/8),rep(0,K/4)),2),
              rep(c(rep(-0.3,K/8),rep(0.5,K/8),rep(0,K/4)),2)) 

alphaK = rep(c(rep(1,K/8),rep(0,K/8),rep(-1,K/8),rep(0,K/8)),2)

seed_file <- read.csv('sim_seed.csv', header = FALSE)
seed_values <- seed_file[,1]
rho <- 0.1 ## span
ck <- seq(0.01, 0.99, 0.01)

for (i in seq_along(seed_values)){
  
  seed = seed_values[i]
  DM = PS_simulation_new(n = 15000, 0.5, K = K, beta = matrix(c(bg,betaK[1,]), ncol = 1), 
                         alpha = matrix(c(ak, alphaK), ncol = 1), delta = 1, Homo = 0, 
                         delta_function, seeds = seed)
  ds = DM$Data[,c(1,2,4:7,20:99)]
  N = c("Y","Tr",paste0("X",seq(1,84)))
  colnames(ds) = N
  
  ## data simulation
  X = ds[,3:86]
  treatment = ds[,2]
  Y = ds[,1]
  log.fit = glm(treatment~X, family = binomial) 
  ps = log.fit$fitted.values
  data = cbind(Y, "Tr" = treatment, X)
  write.csv(data, paste0("ssmr_data_seed", seed, ".csv"), row.names = FALSE)
  
  ## ck and adaptive h
  h <- span_to_bandwidth(rho, ck, ps)
  input <- data.frame(ck=ck, h=h)
  write.csv(input, paste0("ck_h", seed, ".csv"), row.names = FALSE)
  
}








