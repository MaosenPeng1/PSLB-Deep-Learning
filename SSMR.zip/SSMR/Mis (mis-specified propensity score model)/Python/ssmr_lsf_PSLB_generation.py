import os
import csv

def create_lsf_content(seed, queue_name):
    content = f"""#BSUB -J ssmrjob_{seed}
#BSUB -W 24:00
#BSUB -o /rsrch6/home/biostatistics/mpeng1/log/ssmrjob_{seed}.out
#BSUB -e /rsrch6/home/biostatistics/mpeng1/log/ssmrjob_{seed}.err
#BSUB -cwd /rsrch6/home/biostatistics/mpeng1/PSLB/python/ssmr
#BSUB -q {queue_name}
#BSUB -u mpeng1@mdanderson.org
#BSUB -n 1
#BSUB -M 8
#BSUB -R rusage[mem=8]

module load python

python /rsrch6/home/biostatistics/mpeng1/PSLB/python/ssmr/ssmr.py --seed {seed}
"""
    return content

seed_values = []
queue_names = ["e40medium", "medium", "e80medium"]
with open("sim_seed.csv", "r") as csv_file:
    csv_reader = csv.reader(csv_file)
    for row in csv_reader:
        seed_values.append(int(row[0]))

output_dir = '/rsrch6/home/biostatistics/mpeng1/PSLB/python/ssmr'

for seed in seed_values:
    lsf_content = create_lsf_content(seed, queue_names[seed % 3])
    with open(os.path.join(output_dir, f'ssmrk{seed}.lsf'), 'w') as lsf_file:
        lsf_file.write(lsf_content)


## for file in *.lsf; do 
## > bsub < $file 
## > done


