library(ggplot2)
library(dplyr)
library(tidyr)

load('Other_Methods.RData')
source("Methods.R")

## load seeds
s <- 1:100

## load data
path <- "C:/Users/mpeng1/Desktop/GRA/Simulations/eqls/bootstrap/data/"
file_data<- paste0(path, "eqls_data", s, ".csv")
data_list <- lapply(file_data, read.csv, header = TRUE)

## load propensity score
file_ps <- paste0("eqls_res", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_dl <- do.call(cbind, ps_list)
ps_dl <- apply(ps_dl, 2, as.numeric)
## check if file exists
#sapply(file_ps, file.exists)

# load bce ps
file_ps <- paste0("eqls_logistic", s, ".csv")
ps_list <- lapply(file_ps, read.csv, header = FALSE)
ps_bce <- do.call(cbind, ps_list)
ps_bce <- apply(ps_bce, 2, as.numeric)

n <- length(s)
p <- length(ck_list[[1]]$ck)
M <- rep(NA, n)

ATE <- list(logistic = M, cbps = M, bce = M, PSLBdl = M)

for(i in 1:n) {
  
  ds <- data_list[[i]]
  
  ## IPW
  wt_logistic <- ipw(Z = ds[,2], ssmrOther$logistic[,i])
  wt_cbps <- ipw(Z = ds[,2], ps = ssmrOther$CBPS[,i])
  wt_dl <- ipw(Z = ds[,2], ps = ps_dl[,i])
  wt_bce <- ipw(Z = ds[,2], ps = ps_bce[,i])
  
  ## ATE estimate
  ATE$logistic[i] <- ATE_infer(ds[,1], wt_logistic, ds[,2])
  ATE$cbps[i] <- ATE_infer(ds[,1], wt_cbps, ds[,2])
  ATE$PSLBdl[i] <- ATE_infer(ds[,1], wt_dl, ds[,2])
  ATE$bce[i] <- ATE_infer(ds[,1], wt_bce, ds[,2])
  
  
  
}

saveRDS(ATE, "ate_res.rds")

## calcluate bootstrap standard deviation
lapply(ATE, function(x) sd(x))

