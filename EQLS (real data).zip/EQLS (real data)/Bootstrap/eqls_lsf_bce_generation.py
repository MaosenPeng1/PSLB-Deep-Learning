import os

def create_lsf_content(seed, queue_name):
    content = f"""#BSUB -J eqls_logjob_{seed}
#BSUB -W 24:00
#BSUB -o /rsrch6/home/biostatistics/mpeng1/log/eqls_logjob_{seed}.out
#BSUB -e /rsrch6/home/biostatistics/mpeng1/log/eqls_logjob_{seed}.err
#BSUB -cwd /rsrch6/home/biostatistics/mpeng1/PSLB/python/eqlsb
#BSUB -q {queue_name}
#BSUB -u mpeng1@mdanderson.org
#BSUB -n 1
#BSUB -M 8
#BSUB -R rusage[mem=8]

module load python

python /rsrch6/home/biostatistics/mpeng1/PSLB/python/eqlsb/EQLS (BCE) Code.py --seed {seed}
"""
    return content

seed_values = list(range(1, 101))
queue_names = ["e40medium", "medium", "e80medium"]

output_dir = '/rsrch6/home/biostatistics/mpeng1/PSLB/python/eqlsb'

for seed in seed_values:
    lsf_content = create_lsf_content(seed, queue_names[seed % 3])
    with open(os.path.join(output_dir, f'eqls_log{seed}.lsf'), 'w') as lsf_file:
        lsf_file.write(lsf_content)
## for file in *.lsf; do 
## > bsub < $file 
## > done


