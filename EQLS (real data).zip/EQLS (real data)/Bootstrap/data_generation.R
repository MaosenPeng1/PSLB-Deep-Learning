load('eqlsData.RData')
source('Methods.R')

n_bootstraps <- 100
# Bootstrap loop
for (i in 1:n_bootstraps) {
  
  # Sample with replacement from 'ds
  eqls_boots <- eqls[sample(nrow(eqls), replace = TRUE), ]
  
  ## data simulation
  X = eqls_boots[,3:ncol(eqls_boots)]
  treatment = eqls_boots[,2]
  Y = eqls_boots[,1]
  log.fit = glm(treatment~X, family = binomial) 
  ps = log.fit$fitted.values
  
  ## ck and adaptive h
  rho = 0.1
  ck <- seq(0.01, 0.99, 0.01)
  h <- span_to_bandwidth(rho, ck, ps)
  input <- data.frame(ck=ck, h=h)
  write.csv(input, paste0("ck_h", i, ".csv"), row.names = FALSE)
  
  file_name <- paste0("eqls_data", i, ".csv")
  write.csv(eqls_boots, file_name, row.names = FALSE)
  
}



