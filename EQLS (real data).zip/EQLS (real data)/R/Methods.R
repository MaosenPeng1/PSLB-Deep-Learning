uniform_kernel <- function(x){
  ## Purpose: uniform kernel function
  ## Input: 
  ##    x -- single value or a vector
  ## Output:
  ##    single value or a vector under uniform kernel
  K_x <- 0.5 * as.numeric(abs(x) <= 1)
  
  return(K_x)
  
}

gaussian_kernel <- function(x){
  ## Purpose: gaussian kernel function
  ## Input: 
  ##    x -- single value or a vector
  ## Output:
  ##    single value or a vector under gaussian kernel
  K_x <- 1/sqrt(2*pi) * exp(-x^2/2)
  
  return(K_x)
  
}

epanechnikov_kernel <- function(x){
  ## Purpose: epanechnikov kernel function
  ## Input: 
  ##    x -- single value or a vector
  ## Output:
  ##    single value or a vector under epanechnikov kernel
  K_x <- 0.75 * (1 - x^2) * as.numeric(abs(x) <= 1)
  
  return(K_x)
  
}

span_to_bandwidth <- function(rho, ck, p){
  ## Purpose: transform span to bandwidth
  ## Input: 
  ##    rho -- span
  ##    ck -- pre-specified points range from 0 to 1
  ##    p -- propensity score
  ## Output:
  ##    a vector of bandwidth for each ck
  N <- length(p)
  h <- numeric(length(ck))
  
  for (i in seq_along(ck)){
    
    d <- abs(ck[i] - p)
    d_sort <- sort(d)
    h[i] <- d_sort[ceiling(N * rho)]
    
  }
  
  return(h)
  
}

LSD <- function(X, Z, p, ck, h, kernel_function){
  ## Purpose: LSD and GSD estimation
  ## Input: 
  ##    X -- covariate 
  ##    Z -- treatment variable
  ##    p -- propensity score
  ##    ck -- pre-specified points range from 0 to 1
  ##    h -- a vector of bandwidths 
  ##    kernel_function -- kernel function
  ## Output:
  ##    a list containing absolute value of LSD, mean of LSD, and GSD
  N <- length(p)
  LSD <- numeric(length(ck))
  
  for (i in seq_along(ck)){
    
    ## Estimating Local Standardized Differences (LSD)
    w <- 1/h[i] * kernel_function( (ck[i] - p) / h[i])
    
    W <- w / (Z * p + (1-Z) * (1-p))
    
    mu1 <- sum(Z * W * X) / sum(Z * W)
    mu0 <- sum((1-Z) * W * X) / sum((1-Z) * W)
    v1 <- sum(Z * W * (X - mu1)^2) / sum(Z * W)
    v0 <- sum((1-Z) * W * (X - mu0)^2) / sum((1-Z) * W)
    
    ess1 <- (sum(Z * W))^2 / sum(Z * W^2)
    ess0 <- (sum((1-Z) * W))^2 / sum((1-Z) * W^2)
    LSD[i] <- 100 * (mu1 - mu0) / sqrt((ess1 * v1 + ess0 * v0) / (ess1 + ess0))
    
    
  }
  
  LSD_mean <- mean(abs(LSD))
  
  ## Estimating Global Standardized Differences (GSD)
  w <- 1
  W <- w / (Z * p + (1-Z) * (1-p))
  mu1 <- sum(Z * W * X) / sum(Z * W)
  mu0 <- sum((1-Z) * W * X) / sum((1-Z) * W)
  v1 <- sum(Z * W * (X - mu1)^2) / sum(Z * W)
  v0 <- sum((1-Z) * W * (X - mu0)^2) / sum((1-Z) * W)
  ess1 <- (sum(Z * W))^2 / sum(Z * W^2)
  ess0 <- (sum((1-Z) * W))^2 / sum((1-Z) * W^2)
  
  GSD <- 100 * (mu1 - mu0) / sqrt((ess1 * v1 + ess0 * v0) / (ess1 + ess0))
  
  return(list(LSD=abs(LSD), LSD_mean = LSD_mean, GSD=GSD))
  
}

ipw <- function(Z, p){
  ## Purpose: inverse probability weighting
  ## Input: 
  ##    Z -- treatment variable
  ##    ps -- propensity score
  ## Output:
  ##    a vector of inverse probability weights
  weight <- Z/p + (1-Z)/(1-p)
  
  return(weight)
  
}

ATE_infer= function(Y, wt, Z) {
  ## Purpose: calculate estimated ATE (treatment effect)
  ## Input: 
  ##    Y -- observed outcome
  ##    Z -- treatment variable
  ##    wt -- inverse probability weights
  ## Output:
  ##    single value of ATE
  ATE_case = sum(Z * wt * Y) / sum(Z * wt)
  ATE_control = sum((1-Z) * wt * Y) / sum((1-Z) * wt)
  ATE_after = ATE_case - ATE_control
  
  return(ATE_after)
  
}

Y_infer = function(Y, wt, Z) {
  ## Purpose: calculate estimated average outcome
  ## Input: 
  ##    Y -- observed outcome
  ##    Z -- treatment variable
  ##    wt -- inverse probability weights
  ## Output:
  ##    a vector of estimated average outcome
  mu_ipw = sum(Z * wt * Y) / sum(Z * wt)
  
  return(mu_ipw)
}

Col_bias_variance_rmse <-  function(Est, True) {
  ## Purpose: calculate estimated average outcome
  ## Input: 
  ##    Y -- observed outcome
  ##    Z -- treatment variable
  ##    wt -- inverse probability weights
  ## Output:
  ##    a vector of estimated average outcome
  percent_bias <- 100*(mean(Est, na.rm = T) - True)/True
  variance <- var(Est, na.rm = T)
  rmse <- sqrt(mean((Est - True)^2, na.rm = T))
  out <- c(percent_bias, rmse, variance)
  names(out) = c("bias", "RMSE", "Var")
  
  return(out)
  
}

mirror_plot <- function(ps, Z){
  ## Purpose: mirror histogram
  ## Input: 
  ##    ps -- propensity score
  ##    Z -- treatment variable
  ## Output:
  ##    mirror histogram 
  data <- data.frame(ps=ps, Z=Z)
  plot <- data %>%
    ggplot(aes(x = ps)) +
    geom_histogram(aes(y = after_stat(count)), 
                   fill = "white",
                   color = 'black',
                   data = ~ subset(., Z == 0), 
                   bins = 70) +
    geom_histogram(aes(y = -after_stat(count)), 
                   data = ~ subset(., Z == 1),
                   bins = 70,
                   fill = "white",
                   color = 'black') +
    geom_hline(yintercept = 0) +
    labs(x = "Propensity Score",
         y = "Frequency") +
    theme(panel.background = element_blank(),
          axis.line = element_line(colour = "black")) +
    scale_y_continuous(breaks = c(-50, 0, 50, 100, 150, 200),
                       label = c(50, 0, 50, 100, 150, 200)) +
    annotate("text", 
             label = "Z=0",
             x = 0.93,
             y = 100,
             size = unit(3, "pt")) +
    annotate("text", 
             label = "Z=1",
             x = 0.93,
             y = -60,
             size = unit(3, "pt"))
  
  return(plot)
  
}

LSD_balance_plot <- function(ds){
  ## Purpose: Figure 3
  ## Input: 
  ##    ds -- Balance Results
  ## Output:
  ##    Figure 3
  f1_colmean <- function(mat){
    
    mean_matrix <- do.call(rbind, mat)
    
    return(colMeans(mean_matrix))
    
  }
  
  ds <- lapply(ds, f1_colmean)
  
  ds_new <- do.call(rbind, lapply(1:length(ds), function(i){
    
    data.frame(CK = 1:length(ds[[i]]),
               Mean = ds[[i]],
               Method = names(ds)[i])
    
  }))
  numeric_labels <- rep(sprintf("%.2f", seq(0.01, 0.99, by = 0.01)), length(ds))
  ds_new$CK <- numeric_labels
  
  custom_colors <- c("logistic" = "#d62728", "cbps" = "#2ca02c", "bce" = "#1f77b4", "PSLBdl" = "#9467bd")
  
  pt <- ggplot(ds_new, aes(x = CK, y = Mean, color = Method)) +
    geom_point(size = 0.7) +
    scale_x_discrete(breaks = c(0.01, 0.11, 0.21, 0.31, 0.41, 0.51, 0.61, 0.71, 0.81, 0.91, 0.99), labels = c(0.01, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.99)) +
    theme_bw(base_size = 20) + 
    theme(legend.position = "bottom",
          panel.grid.major = element_blank(),  # Removes major grid lines
          panel.grid.minor = element_blank(),
          axis.title = element_text(size = 20),
          axis.text = element_text(size = 20),
          legend.text = element_text(size = 20),
          legend.title = element_text(size = 20)) +
    labs(x = "Propensity Score", y = "LSD") +
    scale_color_manual(values = custom_colors) +
    guides(color = guide_legend(override.aes = list(shape = 16)))
  
  for (i in unique(ds_new$Method)){
    
    ds_sub <- subset(vdata, Method == i)
    pt <- pt + geom_boxplot(data = ds_sub, 
                            aes(x = CK, y = LSD, fill = Method), outlier.shape = NA, 
                            width = 0.5, 
                            position = position_dodge(width = 0.5)) +
      stat_boxplot(data = ds_sub, 
                   aes(x = CK, y = LSD, color = Method, group = interaction(CK, Method)),
                   geom = "errorbar",  
                   width = 1.4, 
                   position = position_dodge(width = 0.5)) 
    
  }
  
  pt <- pt + scale_fill_manual(values = custom_colors) +
    guides(fill = "none") 
  
  
  for (i in 1:nrow(gsd)) {
    
    pt <- pt + geom_point(data = gsd[i, ], aes(x = CK, y = ScaledGSD, color = Method), shape = 17, size = 2) 
    
  }
  
  pt <- pt + scale_y_continuous(limits = c(0, 12),
                                sec.axis = sec_axis(~ . / scaling_factor, name = "GSD"))
  
  return(pt)
  
}