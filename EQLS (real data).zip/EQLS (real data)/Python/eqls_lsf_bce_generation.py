import os

def create_lsf_content():
    content = f"""#BSUB -J eqls_log
#BSUB -W 24:00
#BSUB -o /rsrch6/home/biostatistics/mpeng1/log/eqls_log.out
#BSUB -e /rsrch6/home/biostatistics/mpeng1/log/eqls_log.err
#BSUB -cwd /rsrch6/home/biostatistics/mpeng1/PSLB/python/eqls
#BSUB -q "e40medium"
#BSUB -u mpeng1@mdanderson.org
#BSUB -n 1
#BSUB -M 8
#BSUB -R rusage[mem=8]

module load python/3.9.7-anaconda

python /rsrch6/home/biostatistics/mpeng1/PSLB/python/eqls/eqls_logistic.py
"""
    return content

output_dir = '/rsrch6/home/biostatistics/mpeng1/PSLB/python/eqls'

lsf_content = create_lsf_content()
with open(os.path.join(output_dir, f'eqls_log.lsf'), 'w') as lsf_file:
    lsf_file.write(lsf_content)

## for file in *.lsf; do 
## > bsub < $file 
## > done


