import os
import csv

def create_lsf_content():
    content = f"""#BSUB -J eqls
#BSUB -W 24:00
#BSUB -o /rsrch6/home/biostatistics/mpeng1/log/eqls.out
#BSUB -e /rsrch6/home/biostatistics/mpeng1/log/eqls.err
#BSUB -cwd /rsrch6/home/biostatistics/mpeng1/PSLB/python/eqls
#BSUB -q gpu
#BSUB -gpu num=1:gmem=8 
#BSUB -u mpeng1@mdanderson.org
#BSUB -n 16
#BSUB -M 6
#BSUB -R rusage[mem=6]

module load cuda10.0/toolkit/10.0.130
module load python/3.9.7-anaconda

python /rsrch6/home/biostatistics/mpeng1/PSLB/python/eqls/eqls.py 
"""
    return content

output_dir = '/rsrch6/home/biostatistics/mpeng1/PSLB/python/eqls/'

lsf_content = create_lsf_content()
with open(os.path.join(output_dir, f'eqls.lsf'), 'w') as lsf_file:
    lsf_file.write(lsf_content)




