load('eqlsData.RData')
source('Methods.R')

## data simulation
X = eqls[,3:ncol(eqls)]
treatment = eqls[,2]
Y = eqls[,1]
log.fit = glm(treatment~X, family = binomial) 
ps = log.fit$fitted.values

## ck and adaptive h
rho <- 0.1 ## span
ck <- seq(0.01, 0.99, 0.01)
h <- span_to_bandwidth(rho, ck, ps) ## adaptive bandwidth
input <- data.frame(ck=ck, h=h)
write.csv(input, "ck_h.csv", row.names = FALSE)
write.csv(eqls, "eqls_data.csv", row.names = FALSE)
