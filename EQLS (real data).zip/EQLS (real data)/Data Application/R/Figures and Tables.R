library(knitr)
library(kableExtra)
library(ggplot2)
library(dplyr)
library(tidyr)
library(CBPS)

source('Methods.R')

ds <- read.csv('eqls_data.csv', header = TRUE)
ck_h <- read.csv('ck_h.csv', header = TRUE)
ck <- ck_h$ck
h <- ck_h$h
ps_dl <- read.csv('eqls_res.csv', header = FALSE) ## read estimated propensity score from PSLB-DL method
ps_dl <- ps[1:nrow(ds),1]

## Hosmer-Lemshow plot
ps_group <- cut(ps_dl, breaks = 10, include.lowest = TRUE)
group_data <- data.frame(ps = ps_dl, Z, ps_group) %>%
  group_by(ps_group) %>%
  summarise(avg_ps = mean(ps), prop_Z = mean(Z)) 

p <- group_data %>%
  ggplot(aes(x = avg_ps, y = prop_Z)) + 
  geom_point() +
  geom_line() +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "red") +
  labs(x = "Average Propensity Score",
       y = "Proportion of Z = 1") +
  theme_bw(base_size = 12) + 
  theme( panel.grid.major = element_blank(),  # Removes major grid lines
         panel.grid.minor = element_blank(),
         axis.title = element_text(size = 12),
         axis.text = element_text(size = 12))

ggsave("KS HL Figure.pdf", plot = p, width = 8, height = 8, device = "pdf", family = "Times")

## Mirror plot
mirror_plot(ps_dl, Z = ds[,2])

########################################################################
################ Comparison Results ###############################
########################################################################

## other methods
## logistic regression
log.fit <- glm(Tr~.-Y, data = ds, family = 'binomial')
ps_log <- log.fit$fitted.values

## CBPS
cbps.fit <- CBPS(Tr~.-Y, data = ds, method = 'exact', ATT = 0, twostep = FALSE)
cbps.fit <- CBPS(eqls[,2]~eqls[,3:75], method = 'exact', ATT = 0)
ps_cbps <- cbpsfit$fitted.values

## BCE
ps_bce <- read.csv('eqls_bce.csv', header = FALSE)

## ATE and LSD calculation
p <- length(ck)
N <- list(global = NA, local = NA)
L <- rep(NA, p)
K <- NA
Var_name <- names(X)
Lt <- setNames(lapply(Var_name, function(x) L), Var_name)
Balance <- list(logistic = N, cbps = N, bce = N, PSLBdl = N)
TLSD <- list(logistic = Lt, cbps = Lt, bce = Lt, PSLBdl = Lt)
ATE <- list(logistic = K, cbps = K, bce = K, PSLBdl = K)

## IPW
wt_logistic <- ipw(Z = ds[,2], ps = ps_log)
wt_cbps <- ipw(Z = ds[,2], ps = ps_cbps)
wt_dl <- ipw(Z = ds[,2], ps = ps_dl)
wt_bce <- ipw(Z = ds[,2], ps = ps_bce)

## ATE estimate
ATE$logistic <- ATE_infer(ds[,1], wt_logistic, ds[,2])
ATE$cbps <- ATE_infer(ds[,1], wt_cbps, ds[,2])
ATE$PSLBdl <- ATE_infer(ds[,1], wt_dl, ds[,2]) 
ATE$bce <- ATE_infer(ds[,1], wt_bce, ds[,2])

## PSLB DL
PSLBdl <- apply(X, 2, function(x) LSD(x, ds[,2], ps_dl, ck, h, gaussian_kernel)) 
for (j in 1:70) {
  
  TLSD$PSLBdl[[Var_name[j]]] <- PSLBdl[[Var_name[j]]]$LSD
  
}

mean_LSD <- unlist(lapply(PSLBdl, function(x) x$LSD_mean))
GSD <- unlist(lapply(PSLBdl, function(x) x$GSD))
Balance$PSLBdl$local <- mean(mean_LSD)
Balance$PSLBdl$global <- mean(abs(GSD))

## BCE
bce <- apply(X, 2, function(x) LSD(x, ds[,2], ps_bce, ck, h, gaussian_kernel)) 
for (j in 1:70) {
  
  TLSD$bce[[Var_name[j]]] <- bce[[Var_name[j]]]$LSD
  
}

mean_LSD <- unlist(lapply(bce, function(x) x$LSD_mean))
GSD <- unlist(lapply(bce, function(x) x$GSD))
Balance$bce$local <- mean(mean_LSD)
Balance$bce$global <- mean(abs(GSD))

## logistic regression
logistic <- apply(X, 2, function(x) LSD(x, ds[,2], ps_log, ck, h, gaussian_kernel)) 
for (j in 1:70) {
  
  TLSD$logistic[[Var_name[j]]] <- logistic[[Var_name[j]]]$LSD
  
}

mean_LSD <- unlist(lapply(logistic, function(x) x$LSD_mean))
GSD <- unlist(lapply(logistic, function(x) x$GSD))
Balance$logistic$local <- mean(mean_LSD)
Balance$logistic$global <- mean(abs(GSD))

## CBPS
cbps <- apply(X, 2, function(x) LSD(x, ds[,2], ps_cbps, ck, h, gaussian_kernel)) 
for (j in 1:70) {
  
  TLSD$cbps[[Var_name[j]]] <- cbps[[Var_name[j]]]$LSD
  
}

mean_LSD <- unlist(lapply(cbps, function(x) x$LSD_mean))
GSD <- unlist(lapply(cbps, function(x) x$GSD))
Balance$cbps$local <- mean(mean_LSD)
Balance$cbps$global <- mean(abs(GSD))

res <- list(ATE = ATE, Balance = Balance, TLSD = TLSD)
saveRDS(res, "eqls_res.rds")

################ Figure 3 ###################

res <- readRDS("eqls_res.rds")
ATE_true <- res[[1]]
Balance <- res[[2]]
TLSD <- res[[3]]
names(TLSD) <- c("LOGISTIC", "CBPS", "BCE", "LBC-NET")
names(Balance) <- c("LOGISTIC", "CBPS", "BCE", "LBC-NET")

vdata <- lapply(TLSD, f1_colmean <- function(mat){
  
  mean_matrix <- do.call(rbind, mat)
  
  return(mean_matrix)
  
})

violin_points_list <- list(
  LOGISTIC = seq(0.05, 0.92, by = 0.1),
  CBPS = seq(0.06, 0.93, by = 0.1),
  BCE = seq(0.07, 0.94, by = 0.1),
  'LBC-NET' = seq(0.08, 0.95, by = 0.1)
)

vdata_long <- data.frame()
for (i in names(vdata)) {
  mat <- vdata[[i]]
  mat_long <- as.data.frame(vdata[[i]]) %>%
    pivot_longer(cols = everything(), names_to = "CK", values_to = "LSD") %>%
    mutate(Method = i,
           CK = rep(sprintf("%.2f", seq(0.01, 0.99, by = 0.01)), 70)) %>%
    filter(CK %in% violin_points_list[[i]])
  
  vdata_long <- rbind(vdata_long, mat_long)
  
}

#violin_points <- seq(0.05, 0.95, by = 0.1) 
#vdata <- subset(vdata_long, CK %in% violin_points) 
vdata <- vdata_long

gsd <- lapply(Balance, function(x) abs(x$global))
gsd <- stack(gsd)
names(gsd) <- c("GSD", "Method")
gsd$CK <- c('0.89', '0.90', '0.91', '0.92')
gsd$Method <- factor(gsd$Method, levels = c("LOGISTIC", "CBPS", "BCE", "LBC-NET"))
scaling_factor <- 5  
gsd$ScaledGSD <- gsd$GSD * scaling_factor

ggsave("EQLS Figure.pdf", plot = LSD_balance_plot(TLSD), width = 10, height = 8, device = "pdf", family = "Times")


## ATE estimate
ATE_true

################ Figure S8 ###################

ps <- read.csv('eqls_res.csv', header = FALSE)

ps_group <- cut(ps[,1], breaks = 10, include.lowest = TRUE)
group_data <- data.frame(ps = ps[,1], Z, ps_group) %>%
  group_by(ps_group) %>%
  summarise(avg_ps = mean(ps), prop_Z = mean(Z)) 

p <- group_data %>%
  ggplot(aes(x = avg_ps, y = prop_Z)) + 
  geom_point() +
  geom_line() +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "red") +
  labs(x = "Average Propensity Score",
       y = "Proportion of Z = 1") +
  theme_bw(base_size = 12) + 
  theme( panel.grid.major = element_blank(),  # Removes major grid lines
         panel.grid.minor = element_blank(),
         axis.title = element_text(size = 12),
         axis.text = element_text(size = 12))

ggsave("KS HL Figure.pdf", plot = p, width = 8, height = 8, device = "pdf", family = "Times")



