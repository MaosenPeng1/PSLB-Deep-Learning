################################################################################
# Multilevel PS: Illustrative Data Example 
# using data from the European Quality of Life Survey (EQLS)
#
# This file explains how to access the EQLS data and how to form
# the sample used for illustration.
################################################################################


## Steps to obtain the EQLS data

# The EQLS datasets are stored with the UK Data Service (UKDS) in Essex, UK
# and can be obtained via their website, https://ukdataservice.ac.uk/.
# The EQLS data can be used free of charge for non-commercial purposes
# (see https://www.eurofound.europa.eu/surveys/about-eurofound-surveys/data-availability).

# For our analysis, we use the open access data from the European Quality of Life Survey 2011.
# To obtain the dataset, follow the steps below: 
# 1) Go to https://beta.ukdataservice.ac.uk/datacatalogue/studies/study?id=7724#!/access-data
# 2) Download the SPSS files and go to the spss19 file
# 3) Store the eqls_2011.sav datafile 

# The user guide "7724_eqls_2007-2011_user_guide_v2" in the mrdoc/pdf file
# provides detailed information regarding the EQLS study, in particular,
# regarding the derived variables (some of which we use in the analysis).
# The document "eqls_2011_ukda_data_dictionary" in the mrdoc/allissue file
# details all variables that were assessed in the study.


## Prepare the dataset used for analysis

#- Load the data
eqls <- foreign::read.spss("../csv/eqls_2007and2011.sav", to.data.frame=TRUE)
#eqls = read.csv("../csv/eqls_2007and2011.csv")
eqls = cbind(eqls, "SurveyYear" = c(rep(2007,35634),rep(2011,(79270 - 35634))))
# Treatment indicator is Y11_Strainbasedconflict (184): 
# Treatment: Work-life balance conflict:
#            1 = No or weak conflict; 2 Either work or home conflict; 
#            3 = Both work and home conflict
# Outcome variable is "Y11_MWIndex" (162): WHO-5 mental well being index
# Eliminate treatment NA subject
eqls = eqls[which(!is.na(eqls[,184])),]
eqls = eqls[which(!is.na(eqls[,162])),]

#- Get analytic sample of the full dataset

# names of variables that are used in the analysis
variableNames <- c(
  "Y11_Country",
  "Y11_Q31",	# Marital status
  "Y11_Q32", # Number of children
  "Y11_ISCEDsimple",	# Highest level of education
  "Y11_Agecategory", # Age (5 categories)
  "Y11_HH2a", # Gender of the respondent
  "Y11_HHsize", # Household size (incl. children)
  "Y11_HHstructure",	# Household structure
  "Y11_EmploymentStatus",	# Employment status (7 categories)
  "Y11_RuralUrban",	# Rural or urban area based on response to Y11_Q49
  "Y11_Q42", # Health condition
  "Y11_Q18", # Tenure (Own without mortgage (i.e.without any loans), Own with mortgage, Tenant, ...)
  "Y11_Accommproblems", # Number of problems with accommodation
  "Y11_SocExIndex", # Social Exclusion Index
  "Y11_Q58",	# Thinking of your households total monthly income: is your household able to make ends meet?
  "Y11_Deprindex",	# Deprivation index: Number of items household cannot afford
  "Y11_Q12a", # Come home from work too tired to do some of the household jobs
  "DV_Q43Q44", # Any limiting/not limiting chronic health problem?
  "Y11_Q41", # How happy are you? 1 to 10 from very unhappy to very happy
  "Y11_Q29a", # I am optimistic about the future: Strongly agree, agree, neither agree nor disagree, disagree, strongly disagree
  "Y11_Q30", # How satisfied with life these days?
  "Y11_Q40a", # How satisfied with education?
  "Y11_Q40b", # How satisfied with present job?
  "Y11_Q40c", # How satisfied with present standard of living?
  "Y11_Q40d", # How satisfied with accomondation?
  "Y11_Q40e", # How satisfied with family life?
  "Y11_Q40f", # How satisfied with health?
  "Y11_Q40g", # How satisfied with social life?
  "Y11_Q7", # How many hours work per week in 1st job?
  "Y11_Q24", # Can people be trusted? 1 to 10 from you can't be too careful to most people can be trusted
  "SurveyYear", # survey year: 2007 or 2011
  "Y11_Strainbasedconflict",	# Work-life balance conflict
  "Y11_MWIndex"	# Outcome variable: WHO-5 mental wellbeing index
)

#  "Y11_Incomequartiles_percapita", # Income quantiles
# "DV_Q8", # Preferred working hours? (3 groups)
# "DV_Q7", # DV: Total number of working hours

# Select subset of variables that are used in the analysis
daten <- eqls[, variableNames]

# Only use individuals that are employed
# (For the remaining, responses on occurrence of work-life balance conflict are missing)
daten <- daten[daten$Y11_EmploymentStatus == "Employed (includes on leave)", ]
daten$Y11_EmploymentStatus <- NULL

# For simplicity, exclude observations with missing data
nrow(na.omit(daten))
daten <- na.omit(daten)

# Create binary treatment variable: Work-life balance conflict 0 = No or weak conflict; 1 = Either work or home conflict + Both work and home conflict
# Outcome variable: WHO-5 mental wellbeing index
eqls = cbind("Y" = daten[,32], "Tr" = ifelse(daten[,31] == "No or weak conflict", 0, 1))

# Generate country  # Greece is the reference level
cc = names(table(daten[,1]))
country = ifelse(daten[,1] == cc[1], 1, 0)
for(i in 2:34) {
  country = cbind(country, ifelse(daten[,1] == cc[i], 1, 0))
}
eqls = cbind(eqls, country)
rm(country)
eqls = cbind(eqls, "marriage" = ifelse(daten[,2] == names(table(daten[,2]))[1], 1, 0),
             "NoChild" = daten[,3])
# reference education level primary or no education or not applicable
I1 = cbind("second_edu" = ifelse(daten[,4] == names(table(daten[,4]))[3] | daten[,4] == names(table(daten[,4]))[4], 1, 0),
           "post_edu" = ifelse(daten[,4] == names(table(daten[,4]))[5] | daten[,4] == names(table(daten[,4]))[6] | daten[,4] == names(table(daten[,4]))[7], 1, 0))
# age 65+ is reference (age1: 18-34; age2: 35-49; age3: 50-64)
I2 = cbind("age1" = ifelse(daten[,5] == names(table(daten[,5]))[1] | daten[,5] == names(table(daten[,5]))[2], 1, 0),
           "age2" = ifelse(daten[,5] == names(table(daten[,5]))[3], 1, 0),
           "age3" = ifelse(daten[,5] == names(table(daten[,5]))[4], 1, 0))
# male is reference level
eqls = cbind(eqls, I1, I2, "sex" = ifelse(daten[,6] == "Female", 1, 0))
rm(I1, I2)
# Household structure: reference level is Other (combine single parent and couple with children)
I1 = cbind("single" = ifelse(daten[,8] == "Single", 1, 0),
           "couple" = ifelse(daten[,8] == "Couple", 1, 0),
           "parent" = ifelse(daten[,8] == "Single parent" | daten[,8] == "Couple with children", 1, 0))
eqls = cbind(eqls, "HouseSize" = as.numeric(daten[,7]), I1,
             "city" = ifelse(daten[,9] == "Town or city", 1, 0), 
             "VeryGoodHealth" = ifelse(daten[,10] == names(table(daten[,10])[1]), 1, 0),
             "GoodHealth" = ifelse(daten[,10] == names(table(daten[,10])[2]), 1, 0))
# Accommodation is provided rent free + Other is reference level
# combine 
I1 = cbind("OwnNoMort" = ifelse(daten[,11] == names(table(daten[,11]))[1], 1, 0),
           "OwnMort" = ifelse(daten[,11] == names(table(daten[,11]))[2], 1, 0),
           "rent" = ifelse(daten[,11] == names(table(daten[,11]))[3] | daten[,11] == names(table(daten[,11]))[4], 1, 0))

eqls = cbind(eqls, I1, "AccomProblem" = daten[,12], "SocExIndex" = daten[,13])

# refrence: with great difficulty + with some difficulty + with difficulty; 
# very easily + easily + fairly easily
#eqls = cbind(eqls, I1, "DeprivatIndex" = daten[,15])
eqls = cbind(eqls, "Q58Easy" = ifelse(daten[,14] == names(table(daten[,14]))[1] | daten[,14] == names(table(daten[,14]))[2] | daten[,14] == names(table(daten[,14]))[3], 1, 0))

# reference: come home from work too tired to do household jobs as never (1 = several times a week + several times a month; 2 several times a year + less often/rarely)
#I1 = cbind("tired1" = ifelse(daten[,16] == names(table(daten[,16]))[1] | daten[,16] == names(table(daten[,16]))[2], 1, 0),
 #          "tired2" = ifelse(daten[,16] == names(table(daten[,16]))[3] | daten[,16] == names(table(daten[,16]))[4], 1, 0))

# no illness/disability is reference
# I am optimistic about the future: neither agree nor disagree as reference
eqls = cbind(eqls,
            "NotTired"  = ifelse(daten[,17] == names(table(daten[,17]))[3], 0, 1),
             "happyQ41" = as.numeric(daten[,18]),
             "optimistic_yes" = ifelse(daten[,19] == names(table(daten[,19]))[1] | daten[,19] == names(table(daten[,19]))[2], 1, 0),
             "optimistic_no" = ifelse(daten[,19] == names(table(daten[,19]))[4] | daten[,19] == names(table(daten[,19]))[5], 1, 0),
             "satisfy_lifeQ30" = as.numeric(daten[,20]), "satisfy_eduQ40a" = as.numeric(daten[,21]),
             "satisfy_jobQ40b" = as.numeric(daten[,22]), "satisfy_livingQ40c" = as.numeric(daten[,23]),
             "satisfy_accomondQ40d" = as.numeric(daten[,24]), "satisfy_familyQ40e" = as.numeric(daten[,25]),
             "satisfy_healthQ40f" = as.numeric(daten[,26]), "satisfy_socialQ40g" = as.numeric(daten[,27]),
             "workhour" = as.numeric(daten[,28]), "trust" = as.numeric(daten[,29]),
             "SurveyYear2011" = ifelse(daten[,30] == 2011, 1, 0))

colnames(eqls)[3:36] = paste0("country", seq(1,34))
rm(i,I1)
#- Save the dataset
write.table(eqls, "../eqlsData.txt")
save(eqls, file = "../eqlsData.RData")

require(CBPS)

logfit = glm(eqls[,2]~eqls[,3:72], family = binomial)
w = weight.calculate.ps(eqls[,2], logfit$fitted.values, standardize = TRUE)

cbpsfit = CBPS(eqls[,2]~eqls[,3:72], ATT = 0, method = "exact")

#ej = cbind(seq(0,0.8,0.1),seq(0.2,1,0.1))

logstd = Standardized_diff(DM = eqls, weight = w$weight, X_index = c(3:72), Z_index = 2, estimand = "ATE")
  
#Fitted.strata.diff(eqls[,3:77], eqls[,2], logfit$fitted.values, w$weight, ej = ej)

CBPSstd = Standardized_diff(DM = eqls, weight = cbpsfit$weights, X_index = c(3:72), Z_index = 2, estimand = "ATE")
rownames(logstd) = rownames(CBPSstd) = colnames(eqls)[3:72]

local.log = Fitted.strata.diff(eqls[,3:72], eqls[,2], logfit$fitted.values, w$weight, ej = ej)
local.cbps = Fitted.strata.diff(eqls[,3:72], eqls[,2], cbpsfit$fitted.values, cbpsfit$weights, ej = ej)

ATE_infer(DM = eqls, weight = rep(1,nrow(eqls)), X_index = 3:72, Z_index = 2, normalize = T)
ATE_infer(DM = eqls, weight = w$weight, X_index = 3:72, Z_index = 2, normalize = T)
ATE_infer(DM = eqls, weight = cbpsfit$weights, X_index = 3:72, Z_index = 2, normalize = T)

OutStd = cbind(logstd[,1:6], CBPSstd[,6])
colnames(OutStd)[6:7] = c("Logistic_Weighted_S/D","CBPS_Weighted_S/D")

write.csv(OutStd, "../OutStd.csv")
edu = rep("primary", nrow(eqls))
edu[which(eqls[,39] == 1)] = "secondary"
edu[which(eqls[,40] == 1)] = "Tertiary"

age = rep("65+", nrow(eqls))
age[which(eqls[,41] == 1)] = "18-34"
age[which(eqls[,42] == 1)] = "35-49"
age[which(eqls[,43] == 1)] = "50-64"

# Household structure: reference level is Other (combine single parent and couple with children)
hs = rep("Other", nrow(eqls))
hs[which(eqls[,46] == 1)] = "single"
hs[which(eqls[,47] == 1)] = "couple"
hs[which(eqls[,48] == 1)] = "SingleOrCoupleWithChildren"

health = rep("Poor", nrow(eqls))
health[which(eqls[,50] == 1)] = "Good"
health[which(eqls[,51] == 1)] = "VeryGood"

accomd = rep("RentFreeOther", nrow(eqls))
accomd[which(eqls[,52] == 1)] = "OwnNoMortgage"
accomd[which(eqls[,53] == 1)] = "OwnMortgage"
accomd[which(eqls[,54] == 1)] = "rent"

optI = rep("NeitherAgreeNorDisagree", nrow(eqls))
optI[which(eqls[,60] == 1)] = "Disagree"
optI[which(eqls[,61] == 1)] = "Aagree"

XZ = data.frame("Tr" = eqls[,2], "country" = daten[,1], "Marriage" = factor(eqls[,37], levels = c(0,1), labels = c("yes","no")), 
                "NumberChild" = eqls[,38], "Education" = edu, "Age" = age, "Gendar" = factor(eqls[,44], levels = c(0,1), labels = c("Male","Female")),
                "HouseSize" = eqls[,45], "HouseHoldStructure" = hs, "location" = daten[,9], "Health" = health,
                "accomondation" = accomd, "AccomProblem" = daten[,12], "SocExIndex" = daten[,13],
                "MakeEndsMeet" = factor(eqls[,57], levels = c(0,1), labels = c("difficult", "easy")),
                "illnes_diability" = factor(eqls[,58], levels = c(0,1), labels = c("yes", "no")),
                "HowHappyAreYou" = eqls[,59], "Y11_Q29aOptimistic" = optI,
                eqls[,62:71], "SurveyYear" = factor(eqls[,72], levels = c(0,1), labels = c("2007", "2011")))

#XZ[which(XZ[,2] == "31"),2] = "Iceland"
#XZ[which(XZ[,2] == "32"),2] = "Kosovo"
#XZ[which(XZ[,2] == "33"),2] = "Montenegro"
#XZ[which(XZ[,2] == "34"),2] = "Serbia"

XZ_sum = NewTableBy(data = XZ, trI = 1, varI = 2:29, trlevel = c(0,1), N = colnames(XZ)[-1])

write.csv(XZ_sum$stat_in_treat, "../EQLS_SummaryStat.csv")
